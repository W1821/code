/*
Navicat MySQL Data Transfer

Source Server         : localhost
Source Server Version : 50720
Source Host           : localhost:3306
Source Database       : base_admin_api

Target Server Type    : MYSQL
Target Server Version : 50720
File Encoding         : 65001

Date: 2019-12-09 11:30:09
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for button
-- ----------------------------
DROP TABLE IF EXISTS `button`;
CREATE TABLE `button` (
  `id` bigint(20) NOT NULL,
  `actions` varchar(255) DEFAULT NULL,
  `code` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `route_path` varchar(255) DEFAULT NULL,
  `menu_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKf63llkiy6dekuxkbbxxyawmxw` (`menu_id`),
  CONSTRAINT `FKf63llkiy6dekuxkbbxxyawmxw` FOREIGN KEY (`menu_id`) REFERENCES `menu` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of button
-- ----------------------------
INSERT INTO `button` VALUES ('0', '/menu/add', 'add', '添加', null, '3');
INSERT INTO `button` VALUES ('28', '/user/check/number/{phoneNumber},/user/add,/role/main/list', 'add', '增加', null, '5');
INSERT INTO `button` VALUES ('29', '/user/query/{id},/user/update,/user/check/number/{phoneNumber},/role/main/list', 'edit', '编辑', null, '5');
INSERT INTO `button` VALUES ('122', '/user/delete/{id}', 'delete', '删除', null, '5');
INSERT INTO `button` VALUES ('123', '', 'search', '查询', null, '5');
INSERT INTO `button` VALUES ('125', '/role/query/{id},/role/edit', 'edit', '编辑', null, '6');
INSERT INTO `button` VALUES ('126', '/role/add', 'add', '增加', null, '6');
INSERT INTO `button` VALUES ('127', '/role/delete/{id}', 'delete', '删除', null, '6');
INSERT INTO `button` VALUES ('128', '/role/list', 'search', '查询', null, '6');
INSERT INTO `button` VALUES ('129', '/menu/list', 'search', '查询', null, '3');
INSERT INTO `button` VALUES ('130', '/menu/query/{id},/menu/edit', 'edit', '编辑', null, '3');
INSERT INTO `button` VALUES ('131', '/menu/delete', 'delete', '删除', null, '3');
INSERT INTO `button` VALUES ('132', '/menu/add', 'addSub', '添加下级', null, '3');
INSERT INTO `button` VALUES ('158', 'aaa', 'search', '查询', null, '157');

-- ----------------------------
-- Table structure for hibernate_sequence
-- ----------------------------
DROP TABLE IF EXISTS `hibernate_sequence`;
CREATE TABLE `hibernate_sequence` (
  `next_val` bigint(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of hibernate_sequence
-- ----------------------------
INSERT INTO `hibernate_sequence` VALUES ('159');
INSERT INTO `hibernate_sequence` VALUES ('159');
INSERT INTO `hibernate_sequence` VALUES ('159');

-- ----------------------------
-- Table structure for menu
-- ----------------------------
DROP TABLE IF EXISTS `menu`;
CREATE TABLE `menu` (
  `id` bigint(20) NOT NULL,
  `actions` varchar(255) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `deleted` int(11) DEFAULT NULL,
  `icon` varchar(255) DEFAULT NULL,
  `menu_name` varchar(255) DEFAULT NULL,
  `pid` bigint(20) DEFAULT NULL,
  `pids` varchar(255) DEFAULT NULL,
  `rank` int(11) DEFAULT NULL,
  `router_urls` varchar(255) DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  `route_path` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of menu
-- ----------------------------
INSERT INTO `menu` VALUES ('1', '/file/upload/image,/file/ck/upload/image,/menu/main/list', '2018-05-17 16:00:28', '0', 'el-icon-setting', '系统', null, '', '1', '', '2019-12-09 03:22:26', '');
INSERT INTO `menu` VALUES ('2', '', '2017-09-29 15:36:29', '0', 'setting', '系统设置', '1', '1', '2', '', '2018-09-27 17:30:29', '');
INSERT INTO `menu` VALUES ('3', '', '2017-09-29 15:36:57', '0', '', '菜单管理', '2', '1,2', '3', '/main/system/menu/edit/:type/:id', '2019-11-11 03:46:55', '/main/system/menu/list');
INSERT INTO `menu` VALUES ('5', null, '2017-09-29 16:38:30', '0', '', '人员管理', '2', '1,2', '1', '/main/system/user/edit/:id', '2019-12-06 08:12:01', '/main/system/user/list');
INSERT INTO `menu` VALUES ('6', '', '2017-09-29 16:58:50', '0', '', '角色管理', '2', '1,2', '2', '/main/system/role/edit/:id', '2019-11-11 03:45:12', '/main/system/role/list');
INSERT INTO `menu` VALUES ('13', null, null, '0', 'el-icon-sugar', '我的', '1', '1', '1', null, '2019-12-09 03:24:49', null);
INSERT INTO `menu` VALUES ('15', '', '2018-09-27 18:55:05', '0', '', '欢迎页', '13', '1,13', null, '', '2018-09-28 09:45:46', '/main/welcome');
INSERT INTO `menu` VALUES ('133', null, '2019-11-11 09:21:04', '0', 'unordered-list', 'Demo', null, '', '2', null, '2019-11-11 09:43:32', null);
INSERT INTO `menu` VALUES ('134', null, '2019-11-11 09:21:27', '0', 'radar-chart', '经典', '133', '133', '1', null, '2019-12-04 09:36:12', null);
INSERT INTO `menu` VALUES ('135', null, '2019-11-11 09:21:36', '0', null, '地域管理', '134', '133,134', '1', null, '2019-11-11 09:53:00', '/main/demo/upload-img');
INSERT INTO `menu` VALUES ('155', null, '2019-11-29 09:14:07', '0', null, 'DemoTable', '134', '133,134', null, null, '2019-12-04 09:36:37', '/main/demo/table');
INSERT INTO `menu` VALUES ('156', null, '2019-11-29 09:32:46', '0', null, 'Demo2', '134', '133,134', null, null, null, null);
INSERT INTO `menu` VALUES ('157', null, '2019-12-04 07:36:53', '0', null, 'aaa', '134', '133,134', null, null, '2019-12-04 07:37:04', null);

-- ----------------------------
-- Table structure for role
-- ----------------------------
DROP TABLE IF EXISTS `role`;
CREATE TABLE `role` (
  `id` bigint(20) NOT NULL,
  `create_time` datetime DEFAULT NULL,
  `deleted` int(11) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `role_name` varchar(255) DEFAULT NULL,
  `role_status` int(11) DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of role
-- ----------------------------
INSERT INTO `role` VALUES ('1', '2018-06-01 16:30:01', '0', '管理员', '管理员', '0', '2019-11-18 01:18:54');
INSERT INTO `role` VALUES ('103', '2019-11-05 01:43:02', '1', '测试角色1', '测试角色1', '0', '2019-11-05 06:39:25');
INSERT INTO `role` VALUES ('124', '2019-11-08 08:33:25', '0', '人员权限角色', '人员权限角色', '0', '2019-12-06 02:39:04');
INSERT INTO `role` VALUES ('137', '2019-11-13 02:24:32', '0', '角色1', '角色1', '1', '2019-12-03 07:40:26');
INSERT INTO `role` VALUES ('138', '2019-11-13 02:24:40', '0', null, '角色2', '0', '2019-12-03 07:36:21');
INSERT INTO `role` VALUES ('139', '2019-11-13 02:24:46', '0', null, '角色3', '0', null);
INSERT INTO `role` VALUES ('140', '2019-11-13 02:24:55', '0', null, '角色4', '0', null);
INSERT INTO `role` VALUES ('141', '2019-11-13 02:25:09', '0', null, '角色5', '0', null);
INSERT INTO `role` VALUES ('142', '2019-11-13 02:25:27', '1', null, '角色6', '0', '2019-11-29 08:39:50');
INSERT INTO `role` VALUES ('143', '2019-11-13 02:25:36', '0', null, '角色7', '0', null);
INSERT INTO `role` VALUES ('144', '2019-11-13 02:25:44', '0', null, '角色8', '0', null);
INSERT INTO `role` VALUES ('145', '2019-11-13 02:25:55', '1', null, '角色9', '0', '2019-12-03 07:40:13');
INSERT INTO `role` VALUES ('146', '2019-11-13 02:26:14', '0', null, '角色10', '0', null);
INSERT INTO `role` VALUES ('147', '2019-11-13 03:02:04', '0', null, '角色11', '1', '2019-11-13 03:02:18');

-- ----------------------------
-- Table structure for role_button
-- ----------------------------
DROP TABLE IF EXISTS `role_button`;
CREATE TABLE `role_button` (
  `role_id` bigint(20) NOT NULL,
  `button_id` bigint(20) NOT NULL,
  PRIMARY KEY (`role_id`,`button_id`),
  KEY `FK6qydmhre4n7es8j89q4iorqvo` (`button_id`),
  CONSTRAINT `FK6qydmhre4n7es8j89q4iorqvo` FOREIGN KEY (`button_id`) REFERENCES `button` (`id`),
  CONSTRAINT `FKn7ciijco27l47o88he49nk068` FOREIGN KEY (`role_id`) REFERENCES `role` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of role_button
-- ----------------------------
INSERT INTO `role_button` VALUES ('1', '0');
INSERT INTO `role_button` VALUES ('103', '0');
INSERT INTO `role_button` VALUES ('1', '28');
INSERT INTO `role_button` VALUES ('103', '28');
INSERT INTO `role_button` VALUES ('1', '29');
INSERT INTO `role_button` VALUES ('103', '29');
INSERT INTO `role_button` VALUES ('124', '29');
INSERT INTO `role_button` VALUES ('1', '122');
INSERT INTO `role_button` VALUES ('124', '122');
INSERT INTO `role_button` VALUES ('1', '123');
INSERT INTO `role_button` VALUES ('124', '123');
INSERT INTO `role_button` VALUES ('1', '125');
INSERT INTO `role_button` VALUES ('1', '126');
INSERT INTO `role_button` VALUES ('124', '126');
INSERT INTO `role_button` VALUES ('137', '126');
INSERT INTO `role_button` VALUES ('1', '127');
INSERT INTO `role_button` VALUES ('1', '128');
INSERT INTO `role_button` VALUES ('124', '128');
INSERT INTO `role_button` VALUES ('137', '128');
INSERT INTO `role_button` VALUES ('1', '129');
INSERT INTO `role_button` VALUES ('124', '129');
INSERT INTO `role_button` VALUES ('1', '130');
INSERT INTO `role_button` VALUES ('1', '131');
INSERT INTO `role_button` VALUES ('1', '132');
INSERT INTO `role_button` VALUES ('124', '132');

-- ----------------------------
-- Table structure for role_menu
-- ----------------------------
DROP TABLE IF EXISTS `role_menu`;
CREATE TABLE `role_menu` (
  `role_id` bigint(20) NOT NULL,
  `menu_id` bigint(20) NOT NULL,
  KEY `FKfg4e2mb2318tph615gh44ll3` (`menu_id`) USING BTREE,
  KEY `FKqyvxw2gg2qk0wld3bqfcb58vq` (`role_id`) USING BTREE,
  CONSTRAINT `role_menu_ibfk_1` FOREIGN KEY (`menu_id`) REFERENCES `menu` (`id`),
  CONSTRAINT `role_menu_ibfk_2` FOREIGN KEY (`role_id`) REFERENCES `role` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of role_menu
-- ----------------------------
INSERT INTO `role_menu` VALUES ('103', '5');
INSERT INTO `role_menu` VALUES ('103', '6');
INSERT INTO `role_menu` VALUES ('103', '15');
INSERT INTO `role_menu` VALUES ('103', '3');
INSERT INTO `role_menu` VALUES ('1', '5');
INSERT INTO `role_menu` VALUES ('1', '6');
INSERT INTO `role_menu` VALUES ('1', '135');
INSERT INTO `role_menu` VALUES ('1', '15');
INSERT INTO `role_menu` VALUES ('1', '3');
INSERT INTO `role_menu` VALUES ('137', '6');
INSERT INTO `role_menu` VALUES ('137', '15');
INSERT INTO `role_menu` VALUES ('124', '5');
INSERT INTO `role_menu` VALUES ('124', '6');
INSERT INTO `role_menu` VALUES ('124', '3');

-- ----------------------------
-- Table structure for user
-- ----------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `id` bigint(20) NOT NULL,
  `account_status` int(11) DEFAULT NULL,
  `account_type` int(11) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `area_id` int(11) DEFAULT NULL,
  `area_name` varchar(255) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `deleted` int(11) DEFAULT NULL,
  `head_picture_url` varchar(255) DEFAULT NULL,
  `id_card` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `phone_number` varchar(255) DEFAULT NULL,
  `super_admin` int(11) DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  `user_name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of user
-- ----------------------------
INSERT INTO `user` VALUES ('0', '0', '0', null, null, null, '2018-05-17 15:06:49', '0', '/public/image/2019/12/4/c05086f5-fb4d-4879-bd77-31b5577e2408.png', null, '{bcrypt}$2a$10$TOIm2LvDuJr0.y7ePjE1pewvKn7gXB8rrdF29Kzd7dc08.M1QENR6', '15256639988', '1', '2019-12-04 02:53:45', '超级大boss');
INSERT INTO `user` VALUES ('102', '0', null, null, null, null, '2019-11-05 01:42:10', '0', '/public/image/2019/12/2/fb79f85f-195a-4a83-b520-d830a55a50ef.png', null, '{bcrypt}$2a$10$GGqDJC7glGOkNjO1Ol9cFuoScdIL7aEzqDa0cPugVZI6d0hd7HeLG', '18888888888', '0', '2019-12-02 08:35:52', '测试11');
INSERT INTO `user` VALUES ('148', '1', null, null, null, null, '2019-11-28 08:03:18', '0', null, null, '{bcrypt}$2a$10$1K3A84pHyTYcdc/W0i7w4uDKl8lUrx.LUqWFDb0r5tyaQzaV4qiCC', '18888889999', '0', '2019-12-02 02:36:39', '测试002');
INSERT INTO `user` VALUES ('149', '1', null, null, null, null, '2019-11-28 08:05:23', '0', '/public/image/2019/12/3/c054abea-e7bc-48cc-9063-aa3f36ce99ac.png', null, '{bcrypt}$2a$10$dwI4J22f9zqyBlFJh4Ju1.IRjO8QdHgIgB2ovJt9ZWpVLLYrrxwfK', '18888887777', '0', '2019-12-03 01:55:24', '测试003');
INSERT INTO `user` VALUES ('150', '0', null, null, null, null, '2019-11-28 08:05:36', '0', null, null, '{bcrypt}$2a$10$QyL/zeAiHQ4iicR.kcktBO8nrMZzpy2ykuMb8JvfbBcAgWcO3wIke', '18888886666', '0', '2019-12-03 08:58:31', '测试004a');
INSERT INTO `user` VALUES ('151', '0', null, null, null, null, '2019-11-28 08:05:48', '1', null, null, '{bcrypt}$2a$10$Y.DGLAbCfFDXUfq00gKBP.pMM7Bng2OmVAS1pyP/4kF7owleu./uG', '18888883333', '0', '2019-11-28 09:43:15', '测试005');
INSERT INTO `user` VALUES ('152', '0', null, null, null, null, '2019-11-28 08:06:01', '0', null, null, '{bcrypt}$2a$10$x92uQ3ISg7HjQlMDqkiQnu0Goe2QoCf4CeD.0eM9AbfCpy4AHBBum', '18888881111', '0', null, '测试006');
INSERT INTO `user` VALUES ('153', '0', null, null, null, null, '2019-11-28 08:06:28', '0', null, null, '{bcrypt}$2a$10$Y5YI/t7N6dIteHeBJIaNjeBIltzy8Z8nBC5cGNz0iBKT8V1meUnAa', '18888882222', '0', null, '测试007');
INSERT INTO `user` VALUES ('154', '0', null, null, null, null, '2019-11-29 03:48:44', '0', null, null, '{bcrypt}$2a$10$GGfiarZmWGQGewnbptDmautGZRL16Hearhb39hvqV/vd6ztIGw0Vq', '18822223333', '0', null, 'ceshi001');

-- ----------------------------
-- Table structure for user_role
-- ----------------------------
DROP TABLE IF EXISTS `user_role`;
CREATE TABLE `user_role` (
  `user_id` bigint(20) NOT NULL,
  `role_id` bigint(20) NOT NULL,
  KEY `FKa68196081fvovjhkek5m97n3y` (`role_id`) USING BTREE,
  KEY `FK859n2jvi8ivhui0rl0esws6o` (`user_id`) USING BTREE,
  CONSTRAINT `user_role_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`),
  CONSTRAINT `user_role_ibfk_2` FOREIGN KEY (`role_id`) REFERENCES `role` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of user_role
-- ----------------------------
INSERT INTO `user_role` VALUES ('148', '1');
INSERT INTO `user_role` VALUES ('102', '124');
INSERT INTO `user_role` VALUES ('149', '124');
INSERT INTO `user_role` VALUES ('149', '137');
INSERT INTO `user_role` VALUES ('0', '1');
