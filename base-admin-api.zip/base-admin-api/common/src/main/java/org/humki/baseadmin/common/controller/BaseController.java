package org.humki.baseadmin.common.controller;


/**
 * 基本控制器
 *
 * @author Kael
 */
public class BaseController {


}
