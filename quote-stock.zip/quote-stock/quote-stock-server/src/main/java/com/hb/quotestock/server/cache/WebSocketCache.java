package com.hb.quotestock.server.cache;

import com.google.common.cache.Cache;
import com.google.common.cache.CacheBuilder;

import java.util.concurrent.TimeUnit;

public class WebSocketCache {

    /**
     * 一个ip1分钟内登录请求次数缓存
     * key: ip
     * value: 次数
     */
    public static final Cache<String, Long> CLIENT_REQUEST_LIMIT_CACHE = CacheBuilder
            .newBuilder()
            .maximumSize(2 << 10)
            .expireAfterWrite(60, TimeUnit.SECONDS)
            .build();

}
