package com.hb.quotestock.server.pojo.vo;


import com.hb.quotestock.common.pojo.BaseBean;
import com.hb.quotestock.common.pojo.quote.ServerQuoteMessage;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.*;

import java.util.List;

/**
 * 行情Server端信息
 */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@ApiModel(value = "行情Server端信息")
public class ServerInfoVO extends BaseBean {

    @ApiModelProperty(value = "最后一笔行情")
    private ServerQuoteMessage lastQuoteMessage;

    @ApiModelProperty(value = "最后一笔行情接收时间", example = "2018-04-10 16:24:39")
    private String lastQuoteReceiveDate;

    @ApiModelProperty(value = "服务器的连接的列表信息")
    private List<WSClientInfoVO> connectList;
}
