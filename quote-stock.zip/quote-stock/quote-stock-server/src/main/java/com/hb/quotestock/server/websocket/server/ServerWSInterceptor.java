package com.hb.quotestock.server.websocket.server;

import com.google.common.cache.Cache;
import com.hb.quotestock.common.constant.WSAttributeConstant;
import com.hb.quotestock.common.pojo.po.AppInfoModel;
import com.hb.quotestock.common.repository.AppInfoRepository;
import com.hb.quotestock.common.util.IPUtil;
import com.hb.quotestock.common.util.MD5Util;
import com.hb.quotestock.common.util.StringUtil;
import com.hb.quotestock.common.websocket.server.WSClientSessionManager;
import com.hb.quotestock.common.websocket.server.WSHandshakeInterceptor;
import com.hb.quotestock.server.cache.WebSocketCache;
import com.hb.quotestock.server.config.ServerWSConnectionConfig;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.server.ServerHttpRequest;
import org.springframework.http.server.ServerHttpResponse;
import org.springframework.http.server.ServletServerHttpRequest;
import org.springframework.stereotype.Component;
import org.springframework.web.socket.WebSocketHandler;

import javax.servlet.http.HttpServletRequest;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * web socket 握手拦截器
 */
@Slf4j
@Component
public class ServerWSInterceptor extends WSHandshakeInterceptor {

    private final AppInfoRepository appInfoRepository;
    private final ServerWSConnectionConfig connectionConfig;

    @Autowired
    public ServerWSInterceptor(AppInfoRepository appInfoRepository, ServerWSConnectionConfig connectionConfig) {
        this.appInfoRepository = appInfoRepository;
        this.connectionConfig = connectionConfig;
    }

    /**
     * web socket 握手前拦截处理
     */
    @Override
    public boolean beforeHandshake(ServerHttpRequest request, ServerHttpResponse response, WebSocketHandler wsHandler, Map<String, Object> attributes) {

        ServletServerHttpRequest servletServerHttpRequest = (ServletServerHttpRequest) request;
        HttpServletRequest httpServletRequest = servletServerHttpRequest.getServletRequest();

        // 参数
        String appId = httpServletRequest.getParameter(WSAttributeConstant.APP_ID);
        String type = httpServletRequest.getParameter(WSAttributeConstant.TYPE);
        String timestamp = httpServletRequest.getParameter(WSAttributeConstant.TIMESTAMP);
        String sign = httpServletRequest.getParameter(WSAttributeConstant.SIGN);
        String ip = IPUtil.getClientIP(httpServletRequest);

        // 执行第一步验证操作
        if (!firstValidateSuccess(appId, type, timestamp, sign, ip)) {
            return false;
        }

        // 从数据库中读取
        AppInfoModel appInfo = appInfoRepository.findById(appId).orElse(null);
        if (appInfo == null) {
            log.error("校验失败-appId不存在, ip={}, appId={}", ip, appId);
            return false;
        }

        // 再次校验
        boolean validateSuccess = secondValidateSuccess(appInfo, type, timestamp, sign, ip);
        if (!validateSuccess) {
            return false;
        }

        // 向websocket session中增加参数
        attributes.put(WSAttributeConstant.APP_ID, appId);

        String appName = appInfo.getCustomerId();
        if (!StringUtil.isEmpty(appName)) {
            attributes.put(WSAttributeConstant.APP_NAME, appInfo.getCustomerId());
        }
        if (ip != null) {
            attributes.put(WSAttributeConstant.IP, ip);
        }

        log.info("校验成功-开始建立websocket连接");
        return true;
    }

    /**
     * 执行验证
     */
    private boolean firstValidateSuccess(String appId, String type, String timestamp, String sign, String ip) {
        // 校验参数
        if (!validateParams(appId, type, timestamp, sign)) {
            log.error("校验失败-参数缺失错误, ip={}, appId={}, type={}, timestamp={}, sign={}", ip, appId, type, timestamp, sign);
            return false;
        }
        // 开启了一个ip一个秘钥就校验 ip 和 appId是否已经连接了，如果建立了连接，只能有一个
        if (checkIpIsConnected(ip, appId)) {
            log.error("校验失败-此ip和appId已经建立了连接, ip={}, appId={}", ip, appId);
            return false;
        }
        // 检查1分钟内连接次数
        if (checkIpRequestLimit(appId, ip)) {
            log.error("校验失败-尝试连接次数太多, ip={}, appId={}", ip, appId);
            return false;
        }
        return true;
    }

    /**
     * 校验参数是否为空
     */
    private boolean validateParams(String... params) {
        for (String param : params) {
            if (StringUtil.isEmpty(param)) {
                return false;
            }
        }
        return true;
    }

    /**
     * 一个ip和一个appId只能建立一个连接
     */
    private boolean checkIpIsConnected(String ip, String appId) {
        if (!connectionConfig.isOpenOneIpOneKey()) {
            return false;
        }
        List<String> ipAppIds = WSClientSessionManager.getAllWebSocketClient()
                .stream()
                .map(clientSession -> (ServerWSClientSession) clientSession)
                .map(clientSession -> clientSession.getIp() + clientSession.getAppId())
                .collect(Collectors.toList());
        return ipAppIds.contains(ip + appId);
    }


    /**
     * 检查1分钟内连接次数
     */
    private boolean checkIpRequestLimit(String appId, String ip) {
        String clientKey = appId + ip;
        String keyTime = clientKey + "number";

        // 缓存对象
        Cache<String, Long> cache = WebSocketCache.CLIENT_REQUEST_LIMIT_CACHE;

        // 时间 大于 1分钟
        Long currentTime = System.currentTimeMillis();
        Long startConnectTime = cache.getIfPresent(keyTime);
        if (startConnectTime == null) {
            cache.put(clientKey, 1L);
            cache.put(keyTime, currentTime);
        } else if (currentTime - startConnectTime > 60 * 1000L) {
            // 清理缓存
            cache.put(clientKey, 1L);
            cache.put(keyTime, currentTime);
        }

        // 1分钟内的连接次数 小于 限制
        Long number = cache.getIfPresent(clientKey);
        number = number == null ? 1L : ++number;
        cache.put(clientKey, number);
        return connectionConfig.getConnectionLimitNumber() < number;
    }

    /**
     * 校验
     */
    private boolean secondValidateSuccess(AppInfoModel appInfo, String type, String timestamp, String sign, String ip) {
        String appId = appInfo.getAppKey();

        // 校验白名单
        if (!checkWhitelist(appInfo, ip)) {
            log.error("校验失败-IP不在白名单, ip={}, appId={}", ip, appId);
            return false;
        }

        // 校验秘钥是否过期
        if (checkOverTime(appInfo)) {
            log.error("校验失败-秘钥过期, ip={}, appId={}", ip, appId);
            return false;
        }

        String appSecret = appInfo.getAppSecret();
        if (StringUtil.isEmpty(appSecret)) {
            log.error("校验失败-秘钥不存在, ip={}, appId={}", ip, appId);
            return false;
        }

        if (!checkSign(appId, type, timestamp, appSecret, sign)) {
            log.error("校验失败-签名不正确, ip={}, appId={}, type={}, timestamp={}, sign={}", ip, appId, type, timestamp, sign);
            return false;
        }

        return true;
    }


    /**
     * 校验白名单
     */
    private boolean checkWhitelist(AppInfoModel appInfo, String ip) {
        // 未开启白名单机制，校验成功
        if (!connectionConfig.isOpenWhitelist()) {
            return true;
        }
        // 校验白名单
        String whitelist = appInfo.getWhitelist();
        // 没有配置白名单，校验成功
        if (whitelist == null) {
            return true;
        }
        // ip在白名单中，校验成功
        return whitelist.contains(ip);
    }

    /**
     * 判断秘钥是否过期
     */
    private boolean checkOverTime(AppInfoModel appInfo) {
        LocalDateTime overTime = appInfo.getOverTime();
        if (overTime == null) {
            return true;
        }
        // 判断过期时间是否在当前时间之前
        return overTime.isBefore(LocalDateTime.now());
    }

    /**
     * 验证签名
     */
    private boolean checkSign(String appId, String type, String timestamp, String appSecret, String sign) {
        String md5 = MD5Util.getMD5(appId + type + timestamp + appSecret);
        return StringUtil.equals(sign, md5);
    }

}
