package com.hb.quotestock.server.websocket.client;

import com.alibaba.fastjson.JSON;
import com.hb.quotestock.common.cache.QuoteCache;
import com.hb.quotestock.common.constant.QuoteTypeReference;
import com.hb.quotestock.common.pojo.quote.*;
import com.hb.quotestock.common.util.QuoteUtil;
import com.hb.quotestock.common.websocket.client.WSMessageHandler;
import com.hb.quotestock.server.cache.ServerQuoteCache;
import com.hb.quotestock.server.config.QuoteConfig;
import com.hb.quotestock.server.constant.ThreadPoolConstant;
import com.hb.quotestock.server.websocket.sender.ServerQuoteSender;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;

/**
 * 行情消息处理器
 */
@Component
@Slf4j
public class ServerWSClientMessageHandler extends WSMessageHandler {

    private final QuoteConfig quoteConfig;

    @Autowired
    public ServerWSClientMessageHandler(QuoteConfig quoteConfig) {
        this.quoteConfig = quoteConfig;
    }

    /**
     * 启用线程处理股票行情
     * 这个版本都支持科创板，不用去除科创板
     */
    public void handleStockMessage(String message) {
        ThreadPoolConstant.STOCK_HANDLE_POOL.execute(() -> {
            QuoteWrapper<StockQuote> quoteWrapper = JSON.parseObject(message, QuoteTypeReference.STOCK_DTO_TYPE_REFERENCE);
            if (quoteWrapper == null) {
                return;
            }
            StockQuote quote = quoteWrapper.getQuoteData();
            if (quote == null) {
                return;
            }

            // 保存最后一次股票行情记录
            ServerQuoteCache.lastReceiveTime = LocalDateTime.now();
            ServerQuoteCache.lastStockQuote = quote;
            // 兼容老版本，
            ServerQuoteCache.lastQuoteMessage = ServerQuoteMessage.builder().type(quoteWrapper.getQuoteType().getKey()).data(quote.toString()).build();

            // TODO 判断是否发送科创板行情，等全部升级支持，可以删除
            if (!quoteConfig.isSendKcb() && QuoteUtil.stockIsKCB(quote.getSd())) {
                return;
            }

            // 放入缓存中,如果不发送科创板，缓存中是没有的
            QuoteCache.STOCK.put(quote.getSd(), quoteWrapper);
            // 打印日志
            QuoteUtil.log(quoteWrapper);
            // 发送给所有客户端
            ServerQuoteSender.sendMsgToAll(quoteWrapper);
        });
    }

    /**
     * 启用线程处理指数行情
     */
    public void handleExponentMessage(String message) {
        ThreadPoolConstant.EXPONENT_HANDLE_POOL.execute(() -> {
            QuoteWrapper<ExponentQuote> quoteWrapper = JSON.parseObject(message, QuoteTypeReference.EXPONENT_DTO_TYPE_REFERENCE);
            if (quoteWrapper == null) {
                return;
            }
            ExponentQuote quote = quoteWrapper.getQuoteData();
            if (quote == null) {
                return;
            }
            // 放入缓存中
            QuoteCache.EXPONENT.put(quote.getSd(), quoteWrapper);
            // 发送给所有客户端
            ServerQuoteSender.sendMsgToAll(quoteWrapper);
        });
    }

    /**
     * 启用线程处理股票逐笔
     */
    public void handleTransactionMessage(String message) {
        ThreadPoolConstant.TRANSACTION_HANDLE_POOL.execute(() -> {
            QuoteWrapper<TransactionQuote> quoteWrapper = JSON.parseObject(message, QuoteTypeReference.TRANSACTION_DTO_TYPE_REFERENCE);
            if (quoteWrapper == null) {
                return;
            }
            TransactionQuote quote = quoteWrapper.getQuoteData();
            if (quote == null) {
                return;
            }
            // TODO 判断是否发送科创板行情，等全部升级支持，可以删除
            if (!quoteConfig.isSendKcb() && QuoteUtil.stockIsKCB(quote.getSd())) {
                return;
            }
            // 放入缓存中，如果不发送科创板，缓存中是没有的
            QuoteCache.TRANSACTION.put(quote.getSd(), quoteWrapper);
            // 打印日志
            QuoteUtil.log(quoteWrapper);
            // 发送给所有客户端
            ServerQuoteSender.sendMsgToAll(quoteWrapper);
        });
    }

    /**
     * 启用线程处理新浪行业行情
     */
    public void handleSinaIndustryMessage(String message) {
        ThreadPoolConstant.SINA_INDUSTRY_HANDLE_POOL.execute(() -> {
            QuoteWrapper<SinaIndustryQuote> quoteWrapper = JSON.parseObject(message, QuoteTypeReference.SINA_INDUSTRY_DTO_TYPE_REFERENCE);
            if (quoteWrapper == null) {
                return;
            }
            SinaIndustryQuote quote = quoteWrapper.getQuoteData();
            if (quote == null) {
                return;
            }
            // 放入缓存中
            QuoteCache.SINA_INDUSTRY.put(quote.getHydm(), quoteWrapper);
            // 发送给所有客户端
            ServerQuoteSender.sendMsgToAll(quoteWrapper);
        });
    }


}
