package com.hb.quotestock.server.websocket.server;

import com.hb.quotestock.common.cache.QuoteCache;
import com.hb.quotestock.common.websocket.server.WSMessageHandler;
import com.hb.quotestock.server.websocket.sender.ServerQuoteSender;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.web.socket.WebSocketSession;

import java.util.Objects;


@Component
@Slf4j
public class ServerWSServerMessageHandler extends WSMessageHandler {

    /**
     * 新连接打开
     */
    @Override
    public void afterConnectionEstablished(WebSocketSession session) {
        // 默认订阅了 股票，指数、新浪行业
        ServerWSClientSession clientSession = new ServerWSClientSession(session);
        putWSClientSessionToManager(clientSession);
        log.info("websocket connected, id={}, ip={}, appId={},appName={}", session.getId(), clientSession.getIp(), clientSession.getAppId(), clientSession.getAppName());

        // 发送缓存的行情
        sendQuote(clientSession);
    }


    private void sendQuote(ServerWSClientSession session) {
        // 股票
        sendStockQuote(session);
        // 指数行情
        sendExponentQuote(session);
        // 股票逐笔
        sendTransactionQuote(session);
        // 新浪行业行情缓存
        sendSinaIndustryQuote(session);
    }

    private void sendSinaIndustryQuote(ServerWSClientSession session) {
        QuoteCache.SINA_INDUSTRY.values()
                .stream()
                .filter(Objects::nonNull)
                .forEach(wrapper -> ServerQuoteSender.sendMsgToClient(session, wrapper));
    }

    private void sendExponentQuote(ServerWSClientSession session) {
        QuoteCache.EXPONENT.values()
                .stream()
                .filter(Objects::nonNull)
                .forEach(wrapper -> ServerQuoteSender.sendMsgToClient(session, wrapper));
    }

    private void sendTransactionQuote(ServerWSClientSession session) {
        QuoteCache.TRANSACTION.values()
                .stream()
                .filter(Objects::nonNull)
                .forEach(wrapper -> ServerQuoteSender.sendMsgToClient(session, wrapper));
    }

    private void sendStockQuote(ServerWSClientSession session) {
        QuoteCache.STOCK.values()
                .stream()
                .filter(Objects::nonNull)
                .forEach(wrapper -> ServerQuoteSender.sendMsgToClient(session, wrapper));
    }


}
