package com.hb.quotestock.server.constant;

import com.hb.quotestock.common.util.ThreadPoolUtil;
import lombok.extern.slf4j.Slf4j;

import java.util.concurrent.ThreadPoolExecutor;

/**
 * 使用@Scheduled方式进行定时器任务，由于默认单线程，所以需要使用线程池进行任务异步执行
 * 这是为了防止某个定时器任务出错或超时导致其他任务异常
 */
@Slf4j
public class ThreadPoolConstant {

    /**
     * 股票行情接收处理线程池，有序需要设置为单线程
     * 三秒一次，有3800多股票行情需要处理 队列大小冗余设置为 10000
     * 拒绝策略是 DiscardOldestPolicy
     */
    public static final ThreadPoolExecutor STOCK_HANDLE_POOL = ThreadPoolUtil.createSingleExecutorDiscardOldestPolicy("stock-msg-handle-thread", 10000);

    /**
     * 股票行情接收处理线程池，为了保证有序使用单线程池
     * 三秒一次，有36个指数行情需要处理 队列大小冗余设置为 100
     * 拒绝策略是 DiscardOldestPolicy
     */
    public static final ThreadPoolExecutor EXPONENT_HANDLE_POOL = ThreadPoolUtil.createSingleExecutorDiscardOldestPolicy("exponent-msg-handle-thread", 100);

    /**
     * TODO 注意！！！注意！！！注意！！！
     * TODO 新浪和通联的逐笔都是通过行情计算的 3秒一次。一个股票一条
     * TODO 如果是其他行情源可能是一个股票一次有多个逐笔，这里就需要升级大一点，50000比较适合
     * 股票逐笔接收处理线程池 为了保证有序使用单线程池
     * 三秒一次，有3800多股票行情需要处理 队列大小冗余设置为 10000
     * 拒绝策略是 DiscardOldestPolicy
     */
    public static final ThreadPoolExecutor TRANSACTION_HANDLE_POOL = ThreadPoolUtil.createSingleExecutorDiscardOldestPolicy("exponent-msg-handle-thread", 10000);

    /**
     * 新浪行业行情采集 开盘中1秒一次，为了保证有序使用单线程池
     * 一秒钟有49个新浪行情需要处理 队列大小冗余设置为 150
     * 拒绝策略是 DiscardOldestPolicy
     */
    public static final ThreadPoolExecutor SINA_INDUSTRY_HANDLE_POOL = ThreadPoolUtil.createSingleExecutorDiscardOldestPolicy("sina-industry-msg-handle-thread", 150);


}
