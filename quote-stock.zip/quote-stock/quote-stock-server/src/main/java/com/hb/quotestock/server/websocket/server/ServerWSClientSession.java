package com.hb.quotestock.server.websocket.server;

import com.hb.quotestock.common.constant.QuoteTypeEnum;
import com.hb.quotestock.common.constant.WSAttributeConstant;
import com.hb.quotestock.common.pojo.quote.QuoteSubscribeInfo;
import com.hb.quotestock.common.websocket.server.WSClientSession;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.socket.WebSocketSession;

import java.util.HashSet;
import java.util.Set;

/**
 * websocket建立连接保存对象
 */
@Slf4j
public class ServerWSClientSession extends WSClientSession {

    /**
     * 构造方法
     */
    ServerWSClientSession(WebSocketSession session) {
        super(session);
        // 初始化订阅信息
        this.quoteSubscribeInfo = new QuoteSubscribeInfo();
        // 默认客户端订阅股票、指数、新浪行业
        Set<String> all = new HashSet<>();
        all.add(QuoteSubscribeInfo.SUBSCRIBE_ALL);
        this.quoteSubscribeInfo.subscribeQuote(QuoteTypeEnum.STOCK, all);
        this.quoteSubscribeInfo.subscribeQuote(QuoteTypeEnum.EXPONENT, all);
        this.quoteSubscribeInfo.subscribeQuote(QuoteTypeEnum.SINA_INDUSTRY, all);
    }

    /**
     * 获取客户端发起的连接参数appId
     */
    public String getAppId() {
        if (session == null) {
            return UNKNOWN;
        }
        String appId = (String) session.getAttributes().get(WSAttributeConstant.APP_ID);
        return appId == null ? UNKNOWN : appId;
    }

    /**
     * 获取客户端发起的连接参数appName
     */
    public String getAppName() {
        if (session == null) {
            return UNKNOWN;
        }
        String appName = (String) session.getAttributes().get(WSAttributeConstant.APP_NAME);
        return appName == null ? UNKNOWN : appName;
    }


}
