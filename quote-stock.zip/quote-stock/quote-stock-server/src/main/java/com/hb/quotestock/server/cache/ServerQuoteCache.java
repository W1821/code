package com.hb.quotestock.server.cache;

import com.hb.quotestock.common.pojo.quote.ServerQuoteMessage;
import com.hb.quotestock.common.pojo.quote.StockQuote;

import java.time.LocalDateTime;

public class ServerQuoteCache {

    /**
     * 最后一笔行情接收的时间
     */
    public static LocalDateTime lastReceiveTime;

    /**
     * 最后一笔股票行情
     */
    public static StockQuote lastStockQuote;
    /**
     * 最后一笔股票行情
     */
    public static ServerQuoteMessage lastQuoteMessage;

}
