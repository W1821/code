package com.hb.quotestock.server.config;

import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

/**
 * 连接配置
 */
@Getter
@Setter
@Component
@ConfigurationProperties(prefix = "quote")
public class QuoteConfig {

    /**
     * 是否使用科创板行情
     */
    private boolean sendKcb;

    /**
     * 是否发送新浪行业行情
     */
    private boolean sendSinaIndustry;



}
