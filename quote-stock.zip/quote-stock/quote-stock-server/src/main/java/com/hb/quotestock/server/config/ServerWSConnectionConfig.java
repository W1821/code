package com.hb.quotestock.server.config;

import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

/**
 * 连接配置
 */
@Getter
@Setter
@Component
@ConfigurationProperties(prefix = "ws.connection")
public class ServerWSConnectionConfig {

    /**
     * 是否开启一个ip只能连接一个appkey
     */
    private boolean openOneIpOneKey;

    /**
     * 是否开启白名单
     */
    private boolean openWhitelist;

    /**
     * 一定时间内，客户端建立连接的限制次数
     */
    private long connectionLimitNumber = 10;



}
