package com.hb.quotestock.server.service;

import com.hb.quotestock.common.pojo.dto.ResponseMessage;
import com.hb.quotestock.common.util.LocalDateUtil;
import com.hb.quotestock.common.util.ResponseMessageUtil;
import com.hb.quotestock.common.websocket.server.WSClientSession;
import com.hb.quotestock.common.websocket.server.WSClientSessionManager;
import com.hb.quotestock.server.cache.ServerQuoteCache;
import com.hb.quotestock.server.pojo.vo.WSClientInfoVO;
import com.hb.quotestock.server.pojo.vo.ServerInfoVO;
import com.hb.quotestock.server.websocket.server.ServerWSClientSession;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Slf4j
@Service
public class ServerInfoService {

    /**
     * 获取系统信息
     */
    public ResponseMessage getServerInfo() {
        // 客户端集合
        List<WSClientInfoVO> connectList = WSClientSessionManager.getAllWebSocketClient()
                .stream()
                .map(this::buildClientInfoVO)
                .collect(Collectors.toList());

        ServerInfoVO serverInfoVO = ServerInfoVO.builder()
                .lastQuoteMessage(ServerQuoteCache.lastQuoteMessage)
                .lastQuoteReceiveDate(LocalDateUtil.formatDateTime(ServerQuoteCache.lastReceiveTime))
                .connectList(connectList)
                .build();

        return ResponseMessageUtil.success(serverInfoVO);
    }

    private WSClientInfoVO buildClientInfoVO(WSClientSession client) {
        ServerWSClientSession clientSession = (ServerWSClientSession) client;
        return WSClientInfoVO.builder()
                .appId(clientSession.getAppId())
                .ip(clientSession.getIp())
                .sessionId(clientSession.getSessionId())
                .connectDate(LocalDateUtil.formatDateTime(clientSession.getConnectionDateTime()))
                .build();
    }

}
