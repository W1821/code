package com.hb.quotestock.server.websocket.sender;

import com.hb.quotestock.common.constant.QuoteTypeEnum;
import com.hb.quotestock.common.pojo.quote.*;
import com.hb.quotestock.common.websocket.server.WSClientSession;
import com.hb.quotestock.common.websocket.server.WSClientSessionManager;

public class ServerQuoteSender {


    /**
     * 响应消息给所有客户端，有行情订阅判断，订阅了才发送
     */
    public static void sendMsgToAll(QuoteWrapper wrapper) {
        WSClientSessionManager.getAllWebSocketClient().forEach(clientSession -> sendMsgToClient(clientSession, wrapper));
    }

    /**
     * 响应消息给单个客户端，有行情订阅判断
     */
    public static void sendMsgToClient(WSClientSession clientSession, QuoteWrapper wrapper) {
        if (clientSession == null || wrapper == null) {
            return;
        }
        // 判断是否订阅了
        QuoteSubscribeInfo quoteSubscribeInfo = clientSession.getQuoteSubscribeInfo();
        if (quoteSubscribeInfo == null || quoteSubscribeInfo.isNotSubscribeCode(wrapper.getQuoteType(), getSubscribeCode(wrapper))) {
            return;
        }

        /*
         * TODO 兼容老版本，如果不需要，可以直接发送 wrapper.toString(),不用转换
         */
        String message = buildQuoteMessage(wrapper).toString();

        WSClientSessionManager.sendMsgToClient(clientSession, message);
    }

    /**
     * 兼容老版本，把行情对象转成QuoteMessage
     */
    private static ServerQuoteMessage buildQuoteMessage(QuoteWrapper quoteWrapper) {
        return ServerQuoteMessage.builder()
                .type(quoteWrapper.getQuoteType().getKey())
                .data(quoteWrapper.getQuoteData().toString())
                .build();
    }

    /**
     * 得到当前行情的主键
     */
    private static String getSubscribeCode(QuoteWrapper wrapper) {
        QuoteTypeEnum quoteType = wrapper.getQuoteType();
        if (quoteType == null) {
            return null;
        }
        switch (quoteType) {
            case STOCK:
                StockQuote stockQuote = (StockQuote) wrapper.getQuoteData();
                return stockQuote.getSd();
            case EXPONENT:
                ExponentQuote exponentQuote = (ExponentQuote) wrapper.getQuoteData();
                return exponentQuote.getSd();
            case TRANSACTION:
                TransactionQuote transactionQuote = (TransactionQuote) wrapper.getQuoteData();
                return transactionQuote.getSd();
            case SINA_INDUSTRY:
                SinaIndustryQuote sinaIndustryQuote = (SinaIndustryQuote) wrapper.getQuoteData();
                return sinaIndustryQuote.getHydm();
        }
        return null;
    }

}
