package com.hb.quotestock.server;

import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.web.socket.config.annotation.EnableWebSocket;

import javax.annotation.PostConstruct;

@SpringBootApplication
@Slf4j
@EntityScan(basePackages = {"com.hb.quotestock.common.pojo.po"})
@EnableJpaRepositories(basePackages = "com.hb.quotestock.common.repository")
@ComponentScan(basePackages = {"com.hb.quotestock"})
@EnableWebSocket
@EnableScheduling
public class ServerApplication {

    public static void main(String[] args) {
        SpringApplication.run(ServerApplication.class, args);
    }

    @PostConstruct
    public void init() {
        log.info("应用启动");
    }
}
