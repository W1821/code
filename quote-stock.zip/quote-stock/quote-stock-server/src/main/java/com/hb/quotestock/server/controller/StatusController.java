package com.hb.quotestock.server.controller;

import com.hb.quotestock.common.cache.QuoteCache;
import com.hb.quotestock.common.pojo.dto.ResponseMessage;
import com.hb.quotestock.common.pojo.quote.StockQuote;
import com.hb.quotestock.common.pojo.quote.QuoteWrapper;
import com.hb.quotestock.common.util.ResponseMessageUtil;
import com.hb.quotestock.server.service.ServerInfoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

/**
 * 应用状态
 * TODO 接口有变化，后台监控系统需要更新
 */
@RestController
public class StatusController {

    private final ServerInfoService serverInfoService;

    @Autowired
    public StatusController(ServerInfoService serverInfoService) {
        this.serverInfoService = serverInfoService;
    }

    /**
     * 获取股票行情Server信息
     * 提供给监控系统使用的
     */
    @RequestMapping(value = "/status", method = RequestMethod.GET)
    public ResponseMessage serverInfo() {
        return serverInfoService.getServerInfo();
    }

    /**
     * 获取最后一笔股票行情
     */
    @RequestMapping(value = "/lastQuoteMap", method = RequestMethod.GET)
    public ResponseMessage lastQuoteMap() {
        List<StockQuote> list = QuoteCache.STOCK.values().stream()
                .filter(Objects::nonNull)
                .map(QuoteWrapper::getQuoteData)
                .collect(Collectors.toList());
        return ResponseMessageUtil.success(list);
    }


}
