package com.hb.quotestock.server.websocket.client;

import com.hb.quotestock.common.config.WebSocketClientConfig;
import com.hb.quotestock.common.constant.WSAttributeConstant;
import com.hb.quotestock.common.websocket.client.WSClientEndpoint;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * web socket 客户端
 */
@Component
@Slf4j
public class ServerWSClientEndpoint extends WSClientEndpoint {

    @Autowired
    public ServerWSClientEndpoint(ServerWSClientMessageHandler serverWSClientMessageHandler, WebSocketClientConfig webSocketClientConfig) {
        super(serverWSClientMessageHandler, webSocketClientConfig);
        String serverUrl = webSocketClientConfig.getServerUrl();
        // 增加连接参数
        serverUrl = serverUrl + "?" + WSAttributeConstant.CLIENT_TYPE + "=server";
        webSocketClientConfig.setServerUrl(serverUrl);
    }
}
