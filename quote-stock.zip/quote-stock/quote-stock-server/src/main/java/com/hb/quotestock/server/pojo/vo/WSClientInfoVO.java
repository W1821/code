package com.hb.quotestock.server.pojo.vo;

import com.hb.quotestock.common.pojo.BaseBean;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.*;

/**
 * websocket客户端信息
 */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@ApiModel(value = "与行情Server端的连接信息")
public class WSClientInfoVO extends BaseBean {

    @ApiModelProperty(value = "客户的密钥KEY", example = "123fd9s80fskdj123jkl")
    private String appId;

    @ApiModelProperty(value = "客户机器的IP", example = "138.138.138")
    private String ip;

    @ApiModelProperty(value = "与服务端连接的Socket唯一标识", example = "1A")
    private String sessionId;

    @ApiModelProperty(value = "客户机器与行情Server连接的日期", example = "2018-04-10 16:24:39")
    private String connectDate;
}
