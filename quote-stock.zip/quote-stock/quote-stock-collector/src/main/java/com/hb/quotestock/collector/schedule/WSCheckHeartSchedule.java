package com.hb.quotestock.collector.schedule;

import com.hb.quotestock.common.config.WebSocketServerConfig;
import com.hb.quotestock.common.websocket.server.WSClientSession;
import com.hb.quotestock.common.websocket.server.WSClientSessionManager;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * 心跳超时关闭连接
 */
@Component
@Slf4j
public class WSCheckHeartSchedule {

    private final WebSocketServerConfig webSocketServerConfig;

    @Autowired
    public WSCheckHeartSchedule(WebSocketServerConfig webSocketServerConfig) {
        this.webSocketServerConfig = webSocketServerConfig;
    }

    /**
     * 检查心跳超时
     */
    @Scheduled(cron = "5 */1 * * * ?")
    public void checkHeartbeat() {
        long seconds = webSocketServerConfig.getHeartbeatTimeoutSeconds();
        WSClientSessionManager.checkHeartbeat(seconds);
    }

}
