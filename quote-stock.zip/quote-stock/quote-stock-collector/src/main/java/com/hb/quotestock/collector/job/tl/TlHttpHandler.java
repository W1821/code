package com.hb.quotestock.collector.job.tl;

import com.hb.quotestock.collector.cache.ApplicationCache;
import com.hb.quotestock.collector.config.TLConfig;
import com.hb.quotestock.collector.job.QuoteHandler;
import com.hb.quotestock.collector.pojo.tl.TlStockTicker;
import com.hb.quotestock.collector.util.TlHttpCollectUtil;
import com.hb.quotestock.common.util.FastJsonUtil;
import com.hb.quotestock.common.util.StringUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Objects;

@Slf4j
@Component
public class TlHttpHandler extends QuoteHandler {

    private final TLConfig tlConfig;

    @Autowired
    public TlHttpHandler(TLConfig tlConfig) {
        this.tlConfig = tlConfig;
    }

    /**
     * 调用通联http接口，获取盘后科创板行情
     */
    public void collectTlKcbQuoteAfterTrans() {
        String url = tlConfig.getHttpKcbQuoteUrl() + ApplicationCache.kcbStockCodeStr;
        String quoteBody = TlHttpCollectUtil.collect(url, tlConfig.getSecret());
        if (StringUtil.isEmpty(quoteBody)) {
            return;
        }
        // 闭市
        if (quoteBody.contains("ENDPT")) {
            return;
        }
        List<TlStockTicker> tlStockTickerList = FastJsonUtil.jsonToList(quoteBody, TlStockTicker.class);
        if (tlStockTickerList == null) {
            return;
        }
        tlStockTickerList
                .stream()
                .map(TlQuoteConverter::convertTlAfterKbcToStockWrapper)
                .filter(Objects::nonNull)
                .forEach(this::sendStockQuoteWrapper);
    }

}
