package com.hb.quotestock.collector.job;

import com.hb.quotestock.collector.cache.ApplicationCache;
import com.hb.quotestock.common.cache.QuoteCache;
import com.hb.quotestock.common.constant.QuoteTypeEnum;
import com.hb.quotestock.common.pojo.po.StockBasicInfoModel;
import com.hb.quotestock.common.pojo.quote.QuoteWrapper;
import com.hb.quotestock.common.pojo.quote.StockQuote;
import com.hb.quotestock.common.pojo.quote.TransactionQuote;
import com.hb.quotestock.common.util.LocalDateUtil;
import com.hb.quotestock.common.util.QuoteUtil;
import com.hb.quotestock.common.util.StringUtil;
import lombok.extern.slf4j.Slf4j;

import java.math.BigDecimal;
import java.text.DecimalFormat;

/**
 * 行情转换工具类
 */
@Slf4j
public class QuoteConverter {

    /**
     * 精确到5位小数，涨跌幅、振幅
     */
    private static final DecimalFormat DECIMAL_FORMAT = new DecimalFormat("0.00000");

    /**
     * 判断是否是盘后交易时间
     */
    public static boolean isAfterTransactionTime() {
        return LocalDateUtil.nowBetween("15:05:00", "15:30:09");
    }

    /**
     * 根据股票编码获取名称
     */
    protected static String getStockName(String code) {
        StockBasicInfoModel stockBasicInfoModel = ApplicationCache.stockBasicInfoMap.get(code);
        if (stockBasicInfoModel != null) {
            return stockBasicInfoModel.getStockShortName();
        }
        return null;
    }

    /* ----------------------------------------- 计算行情 start ------------------------------------------ */

    /**
     * 计算涨跌幅、涨跌价、换手率
     */
    protected static void compute(StockQuote stock) {
        // 计算涨跌幅
        computeUpAndDown(stock);
        // 亏损股计算公式不一样
        computePulAndPdl(stock);
        // 计算换手率
        computeTr(stock);
        // 计算量比
        computeLb(stock);
    }

    /**
     * 计算涨跌幅
     */
    private static void computeUpAndDown(StockQuote stock) {
        if (stock.getCp() == 0) {
            return;
        }
        if (stock.getYtp() > 0) {
            stock.setCg(Double.parseDouble(DECIMAL_FORMAT.format((stock.getCp() - stock.getYtp()))));
            stock.setCgp(Double.parseDouble(DECIMAL_FORMAT.format(((stock.getCp() - stock.getYtp()) / stock.getYtp()))));
            stock.setAp(Double.parseDouble(DECIMAL_FORMAT.format(((stock.getTmp() - stock.getTip()) / stock.getYtp()))));
            return;
        }

        // 新股票没有昨收价
        if (stock.getTp() == 0) {
            return;
        }
        stock.setCg(Double.parseDouble(DECIMAL_FORMAT.format((stock.getCp() - stock.getTp()))));
        stock.setCgp(Double.parseDouble(DECIMAL_FORMAT.format(((stock.getCp() - stock.getTp()) / stock.getTp()))));
        stock.setAp(Double.parseDouble(DECIMAL_FORMAT.format(((stock.getTmp() - stock.getTip()) / stock.getTp()))));

    }


    /**
     * 亏损股计算公式不一样
     */
    private static void computePulAndPdl(StockQuote stock) {

        // 判断是否是科创板
        boolean isKC = QuoteUtil.stockIsKCB(stock.getSd());

        // 是否亏损股
        boolean isST = isST(stock);

        // 判断股票是否有涨跌停限制
        boolean isNoLimit = isNoLimit(stock, isKC);
        if (isNoLimit) {
            stock.setPul(-1);
            stock.setPdl(-1);
            return;
        }

        BigDecimal ytp = new BigDecimal("" + stock.getYtp());

        // 涨停价
        String up = isKC ? "1.20" : isST ? "1.05" : "1.10";
        BigDecimal pul = ytp.multiply(new BigDecimal(up)).setScale(2, BigDecimal.ROUND_HALF_UP);

        // 跌停价
        String down = isKC ? "0.80" : isST ? "0.95" : "0.90";
        BigDecimal pdl = ytp.multiply(new BigDecimal(down)).setScale(2, BigDecimal.ROUND_HALF_UP);

        stock.setPul(pul.doubleValue());
        stock.setPdl(pdl.doubleValue());
    }

    /**
     * 判断是否是亏损股
     */
    private static boolean isST(StockQuote stock) {
        String sn = stock.getSn();
        if (sn == null) {
            return false;
        }
        return sn.startsWith("*S") || sn.startsWith("S");
    }

    /**
     * 判断股票是否有涨跌停限制
     */
    private static boolean isNoLimit(StockQuote stock, boolean isKC) {
        StockBasicInfoModel stockBasicInfoModel = ApplicationCache.stockBasicInfoMap.get(stock.getSd());
        if (stockBasicInfoModel == null) {
            return false;
        }
        String openDay = LocalDateUtil.formatDate(stockBasicInfoModel.getListDate());
        if (isKC) {
            // 科创板判断5天交易日
            return ApplicationCache.kcbNoLimitDateList.contains(openDay);
        }
//////////////////////////////////////////////////////////////////////////////////////////////////
//            // 其他的判断一天
//        return StringUtil.equals(ApplicationCache.kcbNoLimitDateList.get(0), openDay);
//////////////////////////////////////////////////////////////////////////////////////////////////
        return false;
    }

    /**
     * 计算换手率
     * 换手率 = 成交量/发行总股数（手）×100%
     */
    private static void computeTr(StockQuote stock) {
        StockBasicInfoModel stockBasicInfoModel = ApplicationCache.stockBasicInfoMap.get(stock.getSd());
        if (stockBasicInfoModel == null) {
            return;
        }
        // 计算换手率 成交量/发行总股数（手）×100%
        BigDecimal volume = new BigDecimal(stock.getDsn());
        BigDecimal nonRestFloatA = BigDecimal.valueOf(stockBasicInfoModel.getNonRestFloatA());
        double tr = volume.divide(nonRestFloatA, 4, BigDecimal.ROUND_HALF_UP).multiply(new BigDecimal("100")).doubleValue();
        stock.setTr(tr);
    }

    /**
     * 计算量比
     * 量比=(当天即时成交量/开盘至今地累计N分钟)/(前五天总成量 /1200分钟)
     * 未计算科创板盘后的量比
     */
    private static void computeLb(StockQuote stock) {
        try {
            long dsn = Long.parseLong(stock.getDsn());
            if (dsn == 0) {
                stock.setLb("0");
                return;
            }
            long openMinutesToday = ApplicationCache.openMinutesToday;
            if (openMinutesToday == 0) {
                stock.setLb("0");
                return;
            }
            BigDecimal todayAvg = new BigDecimal(dsn).divide(new BigDecimal(openMinutesToday), 4, BigDecimal.ROUND_HALF_UP);

            Long totalVolume = ApplicationCache.fiveDayVolumeTotal.get(stock.getSd());
            // 新股票，没有前几日总成交量，设置为0
            if (totalVolume == null) {
                stock.setLb("0");
                return;
            }
            BigDecimal lastFiveDaysAvg = new BigDecimal(totalVolume).divide(new BigDecimal("1200"), 4, BigDecimal.ROUND_HALF_UP);
            String lb = todayAvg.divide(lastFiveDaysAvg, 4, BigDecimal.ROUND_HALF_UP).toString();
            stock.setLb(lb);
        } catch (Exception e) {
            stock.setLb("0");
        }
    }

    /* ----------------------------------------- 计算行情 end ------------------------------------------ */



    /* ============================================ 计算分笔 start =============================================== */

    /**
     * 根据行情计算分笔
     */
    public static QuoteWrapper<TransactionQuote> getTransactionByQuote(QuoteWrapper<StockQuote> wrapper) {
        // wrapper不是null，wrapper.getStock()也不会是null
        StockQuote current = wrapper.getQuoteData();

        StockQuote old = getOldStockDTOFromCache(current.getSd());
        if (old == null) {
            return null;
        }

        // 计算成交量
        double tv = getTradeVolume(current, old);
        if (tv == 0) {
            return null;
        }

        QuoteWrapper<TransactionQuote> transactionDTOWrapper = new QuoteWrapper<>();
        transactionDTOWrapper.setQuoteSource(wrapper.getQuoteSource());
        transactionDTOWrapper.setQuoteType(QuoteTypeEnum.TRANSACTION);

        // 买卖方向
        int to = getBuySellDirection(current, old);

        TransactionQuote transaction = TransactionQuote.builder()
                .tt(current.getDate())
                .sd(current.getSd())
                .tt(current.getDate())
                .tp(parseDouble(current.getCp()))
                .tv(tv)
                .to(to)
                .build();

        transactionDTOWrapper.setQuoteData(transaction);
        return transactionDTOWrapper;
    }

    private static StockQuote getOldStockDTOFromCache(String stockCode) {
        QuoteWrapper<StockQuote> oldWrapper = QuoteCache.STOCK.get(stockCode);
        if (oldWrapper == null) {
            return null;
        }
        return oldWrapper.getQuoteData();
    }

    /**
     * 成交量
     */
    private static double getTradeVolume(StockQuote current, StockQuote old) {

        String dsn;
        String oldDsn;

        if (isAfterTransactionTime()) {
            // 盘后交易的计算方式
            dsn = current.getCdsn();
            oldDsn = old.getCdsn();
        } else {
            // 盘中的计算方式
            dsn = current.getDsn();
            oldDsn = old.getDsn();
        }

        double tv = Math.round(parseDouble(dsn) - parseDouble(oldDsn));
        if (tv <= 0) {
            return 0;
        }
        // 向下取整
        return Math.floor(tv / 100) * 100;

    }

    /**
     * 买卖方向
     */
    private static int getBuySellDirection(StockQuote current, StockQuote old) {
        if (isAfterTransactionTime()) {
            // 盘后科创板逐笔
            return getBuySellDirectionAfter(current, old);
        } else {
            // 盘中逐笔
            return getBuySellDirectionMid(current, old);
        }
    }


    /**
     * 盘中方向计算
     */
    private static int getBuySellDirectionMid(StockQuote current, StockQuote old) {
        int to = current.getCp() >= old.getS1p() ? 0 : current.getCp() <= old.getB1p() ? 1 : 2;

        // 判断涨跌停
        // 买一量很大、卖一量0，涨停，标记为卖盘
        if (new BigDecimal("" + current.getCp()).compareTo(new BigDecimal("" + current.getPul())) >= 0 && current.getS1() == 0) {
            to = 1;
        }
        // 买一量0、卖一量很大，跌停，标记为买盘
        if (new BigDecimal("" + current.getCp()).compareTo(new BigDecimal("" + current.getPdl())) <= 0 && current.getB1() == 0) {
            to = 0;
        }
        return to;
    }

    /**
     * 盘后科创板方向计算
     */
    private static int getBuySellDirectionAfter(StockQuote current, StockQuote old) {

        // 当前行情总盘后成交量
        float currCdsn = parseFloat(current.getCdsn());
        // 上一笔行情总盘后成交量
        float oldCdsn = parseFloat(old.getCdsn());

        // 当前总成交量为0，表示没有成交
        if (currCdsn == 0) {
            return 2;
        }

        // 第一个成交
        if (currCdsn > 0 && oldCdsn == 0) {
            return current.getS1() > 0 ? 0 : current.getB1() > 0 ? 1 : 2;
        }

        // 当前的成交量
        float tv = currCdsn - oldCdsn;

        // 上一个行情卖1量 > 0 && 上一个行情卖1量 >= 成交量，主买盘
        if (old.getS1() > 0 && old.getS1() >= tv) {
            return 0;
        }

        // 上一个行情买1量 > 0 && 上一个行情买1量 >= 成交量，主卖盘
        if (old.getB1() > 0 && old.getB1() >= tv) {
            return 1;
        }

        return 2;
    }

    /* ============================================ 计算分笔 end =============================================== */


    /* ----------------------------------------- 解析数值 start ----------------------------------------- */


    protected static float parseFloat(String str) {
        if (StringUtil.isEmpty(str)) {
            return 0;
        }
        try {
            return Float.parseFloat(str);
        } catch (NumberFormatException e) {
            return 0;
        }
    }

    protected static double parseDouble(String str) {
        if (StringUtil.isEmpty(str)) {
            return 0;
        }
        try {
            return Double.parseDouble(str);
        } catch (NumberFormatException e) {
            return 0;
        }
    }

    protected static double parseDouble(float data) {
        try {
            return data;
        } catch (NumberFormatException e) {
            return 0;
        }
    }
    /* ----------------------------------------- 判断是否是指数 start ----------------------------------------- */


}

