package com.hb.quotestock.collector.job.tl;

import com.hb.quotestock.collector.constant.TlSubscribeChannelTypeEnum;
import com.hb.quotestock.common.util.ThreadPoolUtil;
import lombok.extern.slf4j.Slf4j;
import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisPool;
import redis.clients.jedis.JedisPoolConfig;

/**
 * 通联股票采集任务
 */
@Slf4j
public class TlRedisSubscribeTask extends Thread {

    private static final String ALL = ".*";

    private final Object subLock = new Object();
    private final Object unSubLock = new Object();

    // redis消息处理器
    private TlRedisMessageReceiver subscriber = new TlRedisMessageReceiver();
    // redis连接池
    private JedisPool jedisPool;
    // redis连接
    private Jedis jedis = null;

    // 订阅通道
    private String[] channels;

    // 线程开关，当isEnable==false，线程关闭
    private boolean isEnabled = true;

    // redis重连时间
    private long reconnectTime = 3000L;


    TlRedisSubscribeTask(String ip, int port) {
        super("TL-redis-subscribe-task");
        this.jedisPool = new JedisPool(new JedisPoolConfig(), ip, port);
        this.channels = getChannels();
    }

    @Override
    public void run() {
        while (true) {
            subscribe();
            ThreadPoolUtil.sleep(reconnectTime);
            if (!this.isEnabled) {
                log.info("通联订阅行情线程关闭");
                break;
            }
        }
    }

    /**
     * 重新订阅
     */
    void reSubscribe() {
        synchronized (unSubLock) {
            try {
                log.info("开始取消订阅");
                subscriber.unsubscribe(this.channels);

                log.info("等待订阅取消通知");
                unSubLock.wait();
            } catch (InterruptedException ignored) {
            }
        }

        log.info("通知重新订阅");
        synchronized (subLock) {
            subLock.notifyAll();
        }

    }

    /**
     * 关闭线程
     */
    void close() {
        this.isEnabled = false;
        if (jedis != null) {
            jedis.close();
            jedisPool.close();
        }
    }

    /**
     * 需要订阅的频道
     * 只订阅 深交所、上交所的行情
     * 通联的逐笔计算方法不一样，我们使用新浪的计算方法自己计算
     */
    private String[] getChannels() {
        String[] channels = new String[2];
        channels[0] = TlSubscribeChannelTypeEnum.SH_STOCK_L1.getType() + ALL;
        channels[1] = TlSubscribeChannelTypeEnum.SZ_STOCK_L1.getType() + ALL;
        return channels;
    }


    /**
     * 订阅
     * 线程阻塞
     */
    private void subscribe() {
        try {
            jedis = jedisPool.getResource();

            log.info("获取redis连接，开始订阅");
            // 这是个阻塞方法
            jedis.subscribe(subscriber, channels);

            log.info("取消订阅成功");
            synchronized (unSubLock) {
                unSubLock.notifyAll();
            }

            log.info("等待订阅通知");
            synchronized (subLock) {
                try {
                    subLock.wait();
                } catch (InterruptedException ignored) {
                }
            }
        } catch (Exception e) {
            log.error("订阅redis服务器失败, {}ms后重新订阅,{}", reconnectTime, e);
        } finally {
            if (jedis != null) {
                log.info("关闭redis连接");
                jedis.close();
            }
        }
    }


}
