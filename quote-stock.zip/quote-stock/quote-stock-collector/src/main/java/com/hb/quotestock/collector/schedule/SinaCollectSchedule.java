package com.hb.quotestock.collector.schedule;

import com.hb.quotestock.collector.cache.ApplicationCache;
import com.hb.quotestock.collector.constant.ThreadPoolConstant;
import com.hb.quotestock.collector.job.sina.SinaQuoteCollectHandler;
import com.hb.quotestock.common.constant.QuoteSourceEnum;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

/**
 * 新浪行情采集定时器
 */
@Component
@Slf4j
public class SinaCollectSchedule {

    private final SinaQuoteCollectHandler sinaQuoteCollectHandler;

    @Autowired
    public SinaCollectSchedule(SinaQuoteCollectHandler sinaQuoteCollectHandler) {
        this.sinaQuoteCollectHandler = sinaQuoteCollectHandler;
    }

    /**
     * 9:00 - 15:59 每秒钟获取新浪行情
     */
    @Scheduled(cron = "*/1 * 9-15 * * ?")
    public void collectInTransaction() {
        execute();
    }

    /**
     * 每日00:00 - 08:59 每分钟采集一次新浪行情
     * 每日16:00 - 23:59 每分钟采集一次新浪行情
     */
    @Scheduled(cron = "0 0/1 0-8,16-23 * * ?")
    public void collectInNonTradingTime() {
        execute();
    }

    /**
     * 使用独立的单线程池执行具体任务，防止影响其他定时任务
     */
    private void execute() {

        // 抓取新浪指数行情
        ThreadPoolConstant.SINA_EXPONENT_COLLECT_POOL.execute(sinaQuoteCollectHandler::collectExponent);

        // 抓取新浪行业行情
        ThreadPoolConstant.SINA_INDUSTRY_COLLECT_POOL.execute(sinaQuoteCollectHandler::collectIndustry);

        // 只有开启新浪行情源，采取抓取新浪行情
        if (ApplicationCache.quoteSource.equals(QuoteSourceEnum.SINA)) {
            ThreadPoolConstant.SINA_STOCK_COLLECT_POOL.execute(sinaQuoteCollectHandler::collectStock);
        }
    }

}