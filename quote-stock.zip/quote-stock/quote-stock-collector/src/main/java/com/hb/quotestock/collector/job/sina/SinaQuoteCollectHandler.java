package com.hb.quotestock.collector.job.sina;

import com.hb.quotestock.collector.cache.ApplicationCache;
import com.hb.quotestock.collector.config.SinaConfig;
import com.hb.quotestock.collector.job.QuoteHandler;
import com.hb.quotestock.collector.util.SinaQuoteCollectUtil;
import com.hb.quotestock.common.constant.CharsetsConstant;
import com.hb.quotestock.common.pojo.quote.ExponentQuote;
import com.hb.quotestock.common.pojo.quote.QuoteWrapper;
import com.hb.quotestock.common.pojo.quote.SinaIndustryQuote;
import com.hb.quotestock.common.pojo.quote.StockQuote;
import com.hb.quotestock.common.util.StringUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * 新浪行情采集服务
 */
@Component
@Slf4j
public class SinaQuoteCollectHandler extends QuoteHandler {

    private final SinaConfig sinaConfig;

    @Autowired
    public SinaQuoteCollectHandler(SinaConfig sinaConfig) {
        this.sinaConfig = sinaConfig;
    }

    /**
     * 采集股票行情
     */
    public void collectStock() {
        ApplicationCache.sinaStockUrlCollectParams.forEach(param -> {
            String url = sinaConfig.getStockUrl() + param;
            String result = SinaQuoteCollectUtil.collect(url);
            if (StringUtil.isEmpty(result)) {
                return;
            }
            List<QuoteWrapper<StockQuote>> stockList = SinaQuoteConverter.convertToStockWrapper(result);
            result = null;
            stockList.forEach(this::sendStockQuoteWrapper);
        });
    }

    /**
     * 采集指数
     */
    public void collectExponent() {
        String result = SinaQuoteCollectUtil.collect(sinaConfig.getExponentUrl());
        if (StringUtil.isEmpty(result)) {
            return;
        }
        List<QuoteWrapper<ExponentQuote>> exponentList = SinaQuoteConverter.convertToExponentWrapper(result);
        result = null;
        // 发送指数消息
        exponentList.forEach(this::sendExponentMessage);
    }


    /**
     * 采集新浪行业行情
     */
    public void collectIndustry() {
        String result = SinaQuoteCollectUtil.collect(sinaConfig.getIndustryUrl(), CharsetsConstant.GB_2312.toString());
        if (StringUtil.isEmpty(result)) {
            return;
        }
        List<QuoteWrapper<SinaIndustryQuote>> exponentList = SinaQuoteConverter.convertToSinaIndustryWrapper(result);
        result = null;
        // 发送指数消息
        exponentList.forEach(this::sendSinaIndustryMessage);
    }


}
