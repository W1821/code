package com.hb.quotestock.collector.service;

import com.hb.quotestock.collector.cache.ApplicationCache;
import com.hb.quotestock.common.repository.SinaIndustryRepository;
import com.hb.quotestock.common.pojo.po.SinaIndustryModel;
import com.hb.quotestock.common.util.StringUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

@Service
@Slf4j
public class SinaIndustryCacheService {

    private final SinaIndustryRepository sinaIndustryRepository;

    @Autowired
    public SinaIndustryCacheService(SinaIndustryRepository sinaIndustryRepository) {
        this.sinaIndustryRepository = sinaIndustryRepository;
    }

    /**
     * 更新新浪行业信息
     * 一个行业有哪些股票编号
     * 行业格式：new_blhy
     * 股票编号格式：sz000001,sh688001
     */
    public void updateSinaIndustryCache() {
        log.info(">>>>>>>>> 每日定时更新新浪行业信息开始 <<<<<<<<<");
        List<SinaIndustryModel> list = sinaIndustryRepository.findAll();
        // 更新新浪行业股票
        Map<String, List<String>> map = new ConcurrentHashMap<>();
        list.forEach(model -> {
            String[] stockCodes = StringUtil.splitComma(model.getIndustryStocks());
            if (stockCodes == null) {
                return;
            }
            map.put(model.getSinaIndustryCode(), Arrays.asList(stockCodes));
        });
        ApplicationCache.sinaIndustryStockCode = map;
        log.info("更新新浪行业信息成功，{}", ApplicationCache.sinaIndustryStockCode);
        log.info(">>>>>>>>> 每日定时更新新浪行业信息结束 <<<<<<<<<");
    }


}
