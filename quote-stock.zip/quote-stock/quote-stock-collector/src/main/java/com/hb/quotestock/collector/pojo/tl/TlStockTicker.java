package com.hb.quotestock.collector.pojo.tl;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

/**
 * 通联科创板盘后行情
 */
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class TlStockTicker {
    /**
     * 证券代码
     */
    private String ticker;
    /**
     * 证券简称
     */
    private String shortNM;
    /**
     * 交易日期（yyyy-MM-dd）
     */
    private String dataDate;
    /**
     * 交易时间(HH:MM:SS.ms)
     */
    private String dataTime;
    /**
     * 今日收盘价
     */
    private Float closePrice;
    /**
     * 交易状态（PCALL-集中撮合阶段，ENDPT-闭市阶段, POSMT-连续交易时间）
     */
    private String instrumentStatus;
    /**
     * 成交笔数
     */
    private String numTrades;
    /**
     * 成交总量
     */
    private Double totalVolume;
    /**
     * 成交总额（元）
     */
    private Double totalValue;
    /**
     * 委托买入总量
     */
    private Double totalBidQty;
    /**
     * 委托卖出总量
     */
    private Double totalOfferQty;
    /**
     * 买入撤单笔数
     */
    private Integer withdrawBuyNumber;
    /**
     * 买入撤单数量
     */
    private Double withdrawBuyAmount;
    /**
     * 卖出撤单笔数
     */
    private Integer withdrawSellNumber;
    /**
     * 卖出撤单数量
     */
    private Double withdrawSellAmount;

    /**
     * 卖盘档位
     */
    List<TlTickerBook> askBook;
    /**
     * 买盘档位
     */
    List<TlTickerBook> bidBook;

}
