package com.hb.quotestock.collector.job.tl;

import com.hb.quotestock.collector.config.TLConfig;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.annotation.PreDestroy;

@Component
@Slf4j
public class TlRedisSubscribeManager {

    private TlRedisSubscribeTask tlRedisSubscribeTask;

    private final TLConfig tlConfig;

    @Autowired
    public TlRedisSubscribeManager(TLConfig tlConfig) {
        this.tlConfig = tlConfig;
    }

    /**
     * 开启通联行情
     * 启动一个线程，订阅redis
     */
    public void startTLQuoteSubscribeTask() {
        synchronized (TlRedisSubscribeManager.class) {
            subscribe();
        }
    }

    /**
     * 订阅、重新订阅
     */
    private void subscribe() {
        if (tlRedisSubscribeTask == null) {
            tlRedisSubscribeTask = new TlRedisSubscribeTask(tlConfig.getMdlRedisIp(), tlConfig.getMdlRedisPort());
            tlRedisSubscribeTask.start();
        } else {
            tlRedisSubscribeTask.reSubscribe();
        }
    }

    /**
     * 关闭通联行情
     * 直接关闭redis连接，结束线程
     */
    @PreDestroy
    public void closeTLCollectTask() {
        log.info("关闭通联行情");
        synchronized (TlRedisSubscribeManager.class) {
            if (tlRedisSubscribeTask != null) {
                tlRedisSubscribeTask.close();
                tlRedisSubscribeTask = null;
            }
        }
    }
}
