package com.hb.quotestock.collector.service;

import com.hb.quotestock.collector.cache.ApplicationCache;
import com.hb.quotestock.common.util.LocalDateUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.time.LocalTime;

@Slf4j
@Service
public class OpenMinutesUpdateService {


    /**
     * 更新当日交易分钟累计
     */
    public void updateOpenMinutes() {
        LocalTime now = LocalTime.now();
        // 开盘前
        boolean inBeforeTradeTime = LocalDateUtil.timeBetween(now, "00:00:00", "09:30:00");
        if (inBeforeTradeTime) {
            ApplicationCache.openMinutesToday = 0;
            return;
        }

        // 上午开盘时间
        boolean inAmTradeTime = LocalDateUtil.timeBetween(now, "09:30:00", "11:30:00");
        if (inAmTradeTime) {
            ApplicationCache.openMinutesToday = LocalDateUtil.getMinutesBetween("09:30:00", now);
            return;
        }

        // 中午休息时间
        boolean inRestTradeTime = LocalDateUtil.timeBetween(now, "11:30:00", "13:00:00");
        if (inRestTradeTime) {
            ApplicationCache.openMinutesToday = 120;
            return;
        }

        // 下午开盘时间
        boolean inPmTradeTime = LocalDateUtil.timeBetween(now, "13:00:00", "15:00:00");
        if (inPmTradeTime) {
            ApplicationCache.openMinutesToday = LocalDateUtil.getMinutesBetween("13:00:00", now) + 120;
            return;
        }

        // 收盘后
        boolean inCloseTime = LocalDateUtil.timeBetween(now, "15:00:00", "23:59:59");
        if (inCloseTime) {
            ApplicationCache.openMinutesToday = 240;
        }

    }

}
