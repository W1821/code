package com.hb.quotestock.collector.runner;


import com.hb.quotestock.collector.cache.ApplicationCache;
import com.hb.quotestock.collector.config.QuoteConfig;
import com.hb.quotestock.collector.service.*;
import com.hb.quotestock.common.constant.QuoteSourceEnum;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

/**
 * 服务启动时执行
 */
@Component
@Order(value = 1)
@Slf4j
public class StartUpRunner implements ApplicationRunner {

    private final QuoteConfig quoteConfig;

    private final StockBasicInfoService stockBasicInfoService;
    private final ExchangeCalendarService exchangeCalendarService;
    private final SinaIndustryCacheService sinaIndustryCacheService;
    private final StockDayKInfoService stockDayKInfoService;
    private final OpenMinutesUpdateService openMinutesUpdateService;


    @Autowired
    public StartUpRunner(
            QuoteConfig quoteConfig,
            StockBasicInfoService stockBasicInfoService,
            ExchangeCalendarService exchangeCalendarService,
            SinaIndustryCacheService sinaIndustryCacheService,
            StockDayKInfoService stockDayKInfoService,
            OpenMinutesUpdateService openMinutesUpdateService) {

        this.quoteConfig = quoteConfig;
        this.stockBasicInfoService = stockBasicInfoService;
        this.exchangeCalendarService = exchangeCalendarService;
        this.sinaIndustryCacheService = sinaIndustryCacheService;
        this.stockDayKInfoService = stockDayKInfoService;
        this.openMinutesUpdateService = openMinutesUpdateService;
    }

    @Override
    public void run(ApplicationArguments args) {
        log.debug(">>>>>>>>>>>>>> 服务启动后执行-加载数据 start <<<<<<<<<<<<<");

        log.info("加载行情源信息");
        String source = quoteConfig.getSource();
        ApplicationCache.quoteSource = QuoteSourceEnum.getByKey(source);
        log.info("当前使用的行情源有：配置的行情源={},实际的行情源={}", source, ApplicationCache.quoteSource);

        log.info("加载股票基本数据");
        stockBasicInfoService.updateStockBasicInfo();

        log.info("加载上交所科创板的无限制交易的开盘日期");
        exchangeCalendarService.updateShKcbNoLimitDates();

        log.info("加载新浪行业信息");
        sinaIndustryCacheService.updateSinaIndustryCache();

        log.info("加载股票前五日的前五天总成交量");
        stockDayKInfoService.updateFiveDayTotal();

        log.info("加载今天的交易分钟累计");
        openMinutesUpdateService.updateOpenMinutes();

        log.debug(">>>>>>>>>>>>>> 服务启动后执行-加载数据 end   <<<<<<<<<<<<<");
    }


}