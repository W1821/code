package com.hb.quotestock.collector.websocket.server;

import com.hb.quotestock.common.config.WebSocketServerConfig;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.lang.NonNull;
import org.springframework.web.socket.config.annotation.EnableWebSocket;
import org.springframework.web.socket.config.annotation.WebSocketConfigurer;
import org.springframework.web.socket.config.annotation.WebSocketHandlerRegistry;

@Configuration
@Slf4j
public class WSServerConfigurer implements WebSocketConfigurer {

    private final CollectorWSInterceptor interceptor;
    private final CollectorWSMessageHandler wsServerMessageHandler;
    private final WebSocketServerConfig webSocketServerConfig;

    @Autowired
    public WSServerConfigurer(
            CollectorWSInterceptor interceptor,
            CollectorWSMessageHandler wsServerMessageHandler,
            WebSocketServerConfig webSocketServerConfig) {
        this.interceptor = interceptor;
        this.wsServerMessageHandler = wsServerMessageHandler;
        this.webSocketServerConfig = webSocketServerConfig;
    }

    @Override
    public void registerWebSocketHandlers(@NonNull WebSocketHandlerRegistry registry) {
        registry.addHandler(wsServerMessageHandler, webSocketServerConfig.getPaths())
                .setAllowedOrigins("*")
                .addInterceptors(interceptor);
    }


}
