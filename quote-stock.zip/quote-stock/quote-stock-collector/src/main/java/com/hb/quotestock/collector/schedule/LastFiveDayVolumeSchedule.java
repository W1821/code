package com.hb.quotestock.collector.schedule;

import com.hb.quotestock.collector.service.StockDayKInfoService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

/**
 * 股票前五日的总成交量
 */
@Component
@Slf4j
public class LastFiveDayVolumeSchedule {

    private final StockDayKInfoService stockDayKInfoService;

    @Autowired
    public LastFiveDayVolumeSchedule(StockDayKInfoService stockDayKInfoService) {
        this.stockDayKInfoService = stockDayKInfoService;
    }

    /**
     * 股票前五日的总成交量
     */
    @Scheduled(cron = "30 1 0 * * ? ")
    public void updateFiveDayTotal() {
        stockDayKInfoService.updateFiveDayTotal();
    }

}
