package com.hb.quotestock.collector.job.tl;

import com.hb.quotestock.collector.constant.TlSubscribeChannelTypeEnum;
import com.hb.quotestock.collector.job.QuoteHandler;
import com.hb.quotestock.common.pojo.quote.QuoteWrapper;
import com.hb.quotestock.common.pojo.quote.StockQuote;
import com.hb.quotestock.common.util.ThreadPoolUtil;
import lombok.extern.slf4j.Slf4j;
import redis.clients.jedis.JedisPubSub;

import java.util.concurrent.ThreadPoolExecutor;

/**
 * 通联订阅返回处理
 */
@Slf4j
public class TlRedisMessageReceiver extends JedisPubSub {

    private ThreadPoolExecutor shStockThreadPoolExecutor;
    private ThreadPoolExecutor szStockThreadPoolExecutor;

    // 行情处理器
    private QuoteHandler quoteHandler;

    TlRedisMessageReceiver() {
        // 股票3000多，队列大小设置5000比较合理
        this.shStockThreadPoolExecutor = ThreadPoolUtil.createSingleExecutor("TL-sh-stock-thread", 5000);
        this.szStockThreadPoolExecutor = ThreadPoolUtil.createSingleExecutor("TL-sz-stock-thread", 5000);

        this.quoteHandler = new QuoteHandler();
    }

    @Override
    public void onMessage(String channel, String message) {

        switch (TlSubscribeChannelTypeEnum.getChannelTypeByChannel(channel)) {
            // 上交所level1 股票行情
            case SH_STOCK_L1:
                shStockThreadPoolExecutor.execute(() -> processShStock(message));
                break;

            // 深交所level 股票行情
            case SZ_STOCK_L1:
                szStockThreadPoolExecutor.execute(() -> processSzStock(message));
                break;

            default:
        }

    }

    /**
     * 上交所level1 股票行情
     */
    private void processShStock(String message) {
        QuoteWrapper<StockQuote> wrapper = TlQuoteConverter.convertShToStockWrapper(message);
        if (wrapper == null) {
            // 非A股，不处理
            return;
        }
        message = null;
        this.quoteHandler.sendStockQuoteWrapper(wrapper);
    }

    /**
     * 深交所level 股票行情
     */
    private void processSzStock(String message) {
        QuoteWrapper<StockQuote> wrapper = TlQuoteConverter.convertSzToStockWrapper(message);
        if (wrapper == null) {
            // 非A股，不处理
            return;
        }
        message = null;
        this.quoteHandler.sendStockQuoteWrapper(wrapper);
    }

}
