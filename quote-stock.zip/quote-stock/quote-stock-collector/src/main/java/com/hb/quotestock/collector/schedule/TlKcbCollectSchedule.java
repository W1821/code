package com.hb.quotestock.collector.schedule;

import com.hb.quotestock.collector.cache.ApplicationCache;
import com.hb.quotestock.collector.job.tl.TlHttpHandler;
import com.hb.quotestock.common.constant.QuoteSourceEnum;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

/**
 * 通联行情采集定时器
 */
@Component
@Slf4j
public class TlKcbCollectSchedule {

    private final TlHttpHandler tlHttpHandler;

    @Autowired
    public TlKcbCollectSchedule(TlHttpHandler tlHttpHandler) {
        this.tlHttpHandler = tlHttpHandler;
    }

    /**
     * 15:00 - 15:59 每秒钟获取通联股票的盘后行情
     */
    @Scheduled(cron = "*/1 * 15-16 * * ?")
    public void tlKcbAfterCollect() {
        if (ApplicationCache.quoteSource.equals(QuoteSourceEnum.TL)) {
            tlHttpHandler.collectTlKcbQuoteAfterTrans();
        }
    }

}