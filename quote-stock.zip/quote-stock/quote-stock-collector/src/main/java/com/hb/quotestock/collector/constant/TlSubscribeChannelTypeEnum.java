package com.hb.quotestock.collector.constant;

import lombok.Getter;
import org.springframework.util.StringUtils;

public enum TlSubscribeChannelTypeEnum {

    /**
     * 上交所level1 股票行情
     */
    SH_STOCK_L1("mdl.3.4"),

    /**
     * 深交所level 股票行情
     */
    SZ_STOCK_L1("mdl.5.2"),

    /**
     * 其他未知
     */
    OTHER("other");

    @Getter
    private String type;

    TlSubscribeChannelTypeEnum(String type) {
        this.type = type;
    }

    /**
     * 根据频道获取类型
     */
    public static TlSubscribeChannelTypeEnum getChannelTypeByChannel(String channel) {
        if (StringUtils.isEmpty(channel)) {
            return OTHER;
        }
        for (TlSubscribeChannelTypeEnum channelType : TlSubscribeChannelTypeEnum.values()) {
            if (channel.startsWith(channelType.type)) {
                return channelType;
            }
        }
        return OTHER;
    }

}
