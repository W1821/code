package com.hb.quotestock.collector.util;

import com.alibaba.fastjson.JSONObject;
import com.hb.quotestock.common.util.FastJsonUtil;
import lombok.extern.slf4j.Slf4j;
import okhttp3.*;

import java.util.concurrent.TimeUnit;

/**
 * 请求通联接口工具类
 */
@Slf4j
public class TlHttpCollectUtil {

    private static final OkHttpClient CLIENT;

    static {
        ConnectionPool pool = new ConnectionPool(5, 3, TimeUnit.MINUTES);
        CLIENT = new OkHttpClient.Builder()
                .connectTimeout(3, TimeUnit.SECONDS)
                .readTimeout(3, TimeUnit.SECONDS)
                .connectionPool(pool)
                .followRedirects(true)
                .retryOnConnectionFailure(false)
                .build();
    }

    /**
     * 调用通联接口
     */
    public static String collect(String url, String token) {
        String result = getByToken(url, token);
        // 调用接口失败
        if (result == null) {
            return null;
        }
        JSONObject jsonObject = FastJsonUtil.toJsonObject(result);
        Integer retCode = jsonObject.getInteger("retCode");
        String retMsg = jsonObject.getString("retMsg");
        if (retCode == null) {
            retCode = 0;
            retMsg = "未知错误，retCode无返回" + retMsg;
        }
        switch (retCode) {
            //成功
            case 1:
                return jsonObject.get("data").toString();
            //无数据返回
            case -1:
                log.warn("通联接口-无数据返回, retCode={}, retMsg={}, url={}, secret={}", retCode, retMsg, url, token);
                return "";
            case -3:
                log.error("通联接口-系统暂停服务, retCode={}, retMsg={}, url={}, secret={}", retCode, retMsg, url, token);
                return null;
            case -4:
                log.error("通联接口-内部服务出错, retCode={}, retMsg={}, url={}, secret={}", retCode, retMsg, url, token);
                return null;
            case -5:
                log.error("通联接口-系统繁忙, retCode={}, retMsg={}, url={}, secret={}", retCode, retMsg, url, token);
                return null;
            case -6:
                log.error("通联接口-试用次数已用完, retCode={}, retMsg={}, url={}, secret={}", retCode, retMsg, url, token);
                return null;
            case -7:
                log.error("通联接口-查询超时, retCode={}, retMsg={}, url={}, secret={}", retCode, retMsg, url, token);
                return null;
            case -8:
                log.error("通联接口-查询失败, retCode={}, retMsg={}, url={}, secret={}", retCode, retMsg, url, token);
                return null;
            case -11:
                log.error("通联接口-调用次数已达上限, retCode={}, retMsg={}, url={}, secret={}", retCode, retMsg, url, token);
                return null;
            case 403:
                log.error("通联接口-需要权限, retCode={}, retMsg={}, url={}, secret={}", retCode, retMsg, url, token);
                return null;
            default:
                log.error("通联接口-失败, retCode={}, retMsg={}, url={}, secret={}", retCode, retMsg, url, token);
                return null;
        }
    }

    /**
     * Bearer Token 鉴权请求
     *
     * @param url    接口地址
     * @param secret 密钥
     * @return 响应字符串, 如果没有则返回null
     */
    private static String getByToken(String url, String secret) {
        try {
            Request request = new Request.Builder()
                    .url(url)
                    .header("Connection", "close")
                    .addHeader("Authorization", "Bearer " + secret)
                    .build();
            Response response = CLIENT.newCall(request).execute();
            // 执行http请求失败
            if (!response.isSuccessful()) {
                log.error("从通联获取数据失败, url={}, secret={}, code={}", url, secret, response.code());
                return null;
            }
            ResponseBody responseBody = response.body();
            if (responseBody != null) {
                return responseBody.string();
            }
        } catch (Exception e) {
            log.error("从通联获取数据失败, url={}, secret={}", url, secret, e);
        }
        return null;
    }

}
