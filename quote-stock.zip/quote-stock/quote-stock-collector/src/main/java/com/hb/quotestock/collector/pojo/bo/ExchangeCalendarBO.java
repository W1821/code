package com.hb.quotestock.collector.pojo.bo;

import com.hb.quotestock.common.pojo.bo.BaseBO;
import com.hb.quotestock.common.pojo.po.ExchangeCalendarModel;
import com.hb.quotestock.common.repository.ExchangeCalendarRepository;
import lombok.*;
import org.springframework.data.jpa.domain.Specification;

import javax.persistence.criteria.Predicate;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@Builder
public class ExchangeCalendarBO extends BaseBO {

    private ExchangeCalendarRepository repository;

    /**
     * 创建JPA动态查询条件
     */
    public static Specification<ExchangeCalendarModel> createSpecification() {
        return (root, cq, cb) -> {
            List<Predicate> predicates = new ArrayList<>();
            predicates.add(cb.equal(root.get("exchangeCode"), "sh"));
            predicates.add(cb.equal(root.get("isOpen"), 1));
            predicates.add(cb.lessThanOrEqualTo(root.get("calendarDate"), LocalDate.now().toString()));
            Predicate[] array = new Predicate[predicates.size()];
            return cb.and(predicates.toArray(array));
        };
    }

}
