package com.hb.quotestock.collector.job.tl;

import com.hb.quotestock.collector.job.QuoteConverter;
import com.hb.quotestock.collector.pojo.tl.TlStockTicker;
import com.hb.quotestock.collector.pojo.tl.TlTickerBook;
import com.hb.quotestock.common.cache.QuoteCache;
import com.hb.quotestock.common.constant.QuoteSourceEnum;
import com.hb.quotestock.common.constant.QuoteTypeEnum;
import com.hb.quotestock.common.pojo.quote.QuoteWrapper;
import com.hb.quotestock.common.pojo.quote.StockQuote;
import com.hb.quotestock.common.util.StringUtil;
import lombok.extern.slf4j.Slf4j;

import java.util.List;

/**
 * 通联转换工具
 */
@Slf4j
class TlQuoteConverter extends QuoteConverter {

    /**
     * 通联订阅redis返回数据转换成统一格式
     * 上交所
     */
    static QuoteWrapper<StockQuote> convertShToStockWrapper(String message) {
        String[] array = StringUtil.splitComma(message);
        if (array == null) {
            return null;
        }
        String stockName = getStockName(array[0]);
        if (stockName == null) {
            return null;
        }
        StockQuote stock = buildShStockQuote(array, stockName);
        return getStockQuoteQuoteWrapper(stock);
    }

    /**
     * 通联订阅redis返回数据转换成统一格式
     * 深交所
     */
    static QuoteWrapper<StockQuote> convertSzToStockWrapper(String message) {
        String[] array = StringUtil.splitComma(message);
        if (array == null) {
            return null;
        }
        String stockName = getStockName(array[0]);
        if (stockName == null) {
            return null;
        }
        StockQuote stock = buildSzStockQuote(array, stockName);
        return getStockQuoteQuoteWrapper(stock);
    }

    /**
     * 通联接口返回科创板盘后行情
     */
    static QuoteWrapper<StockQuote> convertTlAfterKbcToStockWrapper(TlStockTicker tlStockTicker) {
        StockQuote stockQuote = buildAfterStockQuote(tlStockTicker);
        if (stockQuote == null) {
            return null;
        }
        return getStockQuoteQuoteWrapper(stockQuote);
    }

    /* =============================================================================================== */


    private static QuoteWrapper<StockQuote> getStockQuoteQuoteWrapper(StockQuote stock) {
        if (stock == null) {
            return null;
        }
        QuoteWrapper<StockQuote> wrapper = new QuoteWrapper<>();
        wrapper.setQuoteSource(QuoteSourceEnum.TL);
        wrapper.setQuoteType(QuoteTypeEnum.STOCK);
        wrapper.setQuoteData(stock);
        return wrapper;
    }

    private static StockQuote buildShStockQuote(String[] array, String stockName) {
        StockQuote stock = new StockQuote();
        stock.setEd("sh");
        stock.setSd(array[0]);
        stock.setSn(stockName);
        stock.setTp(parseFloat(array[7]));
        stock.setYtp(parseFloat(array[6]));
        stock.setCp(parseFloat(array[10]));
        stock.setTmp(parseFloat(array[8]));
        stock.setTip(parseFloat(array[9]));

        stock.setCbp(parseFloat(array[22]));
        stock.setCsp(parseFloat(array[12]));

        stock.setDsn(array[4]);
        stock.setDsm(array[5]);

        stock.setB1p(parseFloat(array[22]));
        stock.setB1(parseFloat(array[23]));
        stock.setB2p(parseFloat(array[24]));
        stock.setB2(parseFloat(array[25]));
        stock.setB3p(parseFloat(array[26]));
        stock.setB3(parseFloat(array[27]));
        stock.setB4p(parseFloat(array[28]));
        stock.setB4(parseFloat(array[29]));
        stock.setB5p(parseFloat(array[30]));
        stock.setB5(parseFloat(array[31]));

        stock.setS1p(parseFloat(array[12]));
        stock.setS1(parseFloat(array[13]));
        stock.setS2p(parseFloat(array[14]));
        stock.setS2(parseFloat(array[15]));
        stock.setS3p(parseFloat(array[16]));
        stock.setS3(parseFloat(array[17]));
        stock.setS4p(parseFloat(array[18]));
        stock.setS4(parseFloat(array[19]));
        stock.setS5p(parseFloat(array[20]));
        stock.setS5(parseFloat(array[21]));

        // 计算涨跌幅、涨跌价、换手率
        compute(stock);
        return stock;
    }

    private static StockQuote buildSzStockQuote(String[] array, String stockName) {
        StockQuote stock = new StockQuote();
        stock.setEd("sz");
        stock.setSd(array[0]);
        stock.setSn(stockName);
        stock.setTp(parseFloat(array[5]));
        stock.setYtp(parseFloat(array[4]));
        stock.setCp(parseFloat(array[8]));
        stock.setTmp(parseFloat(array[6]));
        stock.setTip(parseFloat(array[7]));

        stock.setCbp(parseFloat(array[27]));
        stock.setCsp(parseFloat(array[17]));

        stock.setDsn(array[9]);
        stock.setDsm(array[10]);

        stock.setB1p(parseFloat(array[27]));
        stock.setB1(parseFloat(array[28]));
        stock.setB2p(parseFloat(array[29]));
        stock.setB2(parseFloat(array[30]));
        stock.setB3p(parseFloat(array[31]));
        stock.setB3(parseFloat(array[32]));
        stock.setB4p(parseFloat(array[33]));
        stock.setB4(parseFloat(array[34]));
        stock.setB5p(parseFloat(array[35]));
        stock.setB5(parseFloat(array[36]));

        stock.setS1p(parseFloat(array[17]));
        stock.setS1(parseFloat(array[18]));
        stock.setS2p(parseFloat(array[19]));
        stock.setS2(parseFloat(array[20]));
        stock.setS3p(parseFloat(array[21]));
        stock.setS3(parseFloat(array[22]));
        stock.setS4p(parseFloat(array[23]));
        stock.setS4(parseFloat(array[24]));
        stock.setS5p(parseFloat(array[25]));
        stock.setS5(parseFloat(array[26]));

        // 计算涨跌幅、涨跌价、换手率
        compute(stock);
        return stock;
    }

    /**
     * 通联接口返回科创板盘后行情
     */
    private static StockQuote buildAfterStockQuote(TlStockTicker tlStockTicker) {
        // 不在盘后交易时间不处理
        if (!isAfterTransactionTime()) {
            return null;
        }

        // 不存在上一笔记录，行情数据将会缺失很多，不推送
        // 盘后交易时间重启采集端并使用通联行情可能会出现这种情况。所以启动时会抓取一次新浪行情，来补充缺失数据
        QuoteWrapper<StockQuote> oldWrapper = QuoteCache.STOCK.get(tlStockTicker.getTicker());
        if (oldWrapper == null) {
            return null;
        }
        // 上一笔行情
        StockQuote oldQuote = oldWrapper.getQuoteData();
        if (oldQuote == null) {
            return null;
        }

        StockQuote stockQuote = new StockQuote();
        stockQuote.setEd("sh");

        stockQuote.setSd(oldQuote.getSd());
        stockQuote.setSn(oldQuote.getSn());
        stockQuote.setCp(oldQuote.getCp());

        stockQuote.setTp(oldQuote.getTp());
        stockQuote.setTmp(oldQuote.getTmp());
        stockQuote.setTip(oldQuote.getTip());
        stockQuote.setYtp(oldQuote.getYtp());

        stockQuote.setCbp(oldQuote.getCbp());
        stockQuote.setCsp(oldQuote.getCsp());
        stockQuote.setDsn(oldQuote.getDsn());
        stockQuote.setDsm(oldQuote.getDsm());

        // 盘后交易量、盘后交易额
        stockQuote.setCdsn(String.valueOf(tlStockTicker.getTotalVolume()));
        stockQuote.setCdsm(String.valueOf(tlStockTicker.getTotalValue()));

        setB1AndS1(tlStockTicker, stockQuote);

        // 计算涨跌幅、涨跌价、换手率
        compute(stockQuote);

        return stockQuote;
    }

    /**
     * 通联行情 赋值买1、卖1
     */
    private static void setB1AndS1(TlStockTicker tlStockTicker, StockQuote stock) {
        List<TlTickerBook> askBook = tlStockTicker.getAskBook();
        if (askBook != null && !askBook.isEmpty()) {
            stock.setS1(askBook.get(0).getOrderQty());
            stock.setS1p(tlStockTicker.getClosePrice());
        }

        List<TlTickerBook> bidBook = tlStockTicker.getBidBook();
        if (bidBook != null && !bidBook.isEmpty()) {
            stock.setB1(bidBook.get(0).getOrderQty());
            stock.setB1p(tlStockTicker.getClosePrice());
        }
    }


}
