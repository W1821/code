package com.hb.quotestock.collector.service;

import com.hb.quotestock.collector.cache.ApplicationCache;
import com.hb.quotestock.collector.pojo.bo.ExchangeCalendarBO;
import com.hb.quotestock.common.repository.ExchangeCalendarRepository;
import com.hb.quotestock.common.repository.StockDayKInfoRepository;
import com.hb.quotestock.common.pojo.po.ExchangeCalendarModel;
import com.hb.quotestock.common.pojo.po.StockDayKInfoModel;
import com.hb.quotestock.common.util.JPAPageableUtil;
import com.hb.quotestock.common.util.LocalDateUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * 股票日K数据
 */
@Slf4j
@Service
public class StockDayKInfoService {

    private final StockDayKInfoRepository stockDayKInfoRepository;
    private final ExchangeCalendarRepository exchangeCalendarRepository;

    @Autowired
    public StockDayKInfoService(StockDayKInfoRepository stockDayKInfoRepository, ExchangeCalendarRepository exchangeCalendarRepository) {
        this.stockDayKInfoRepository = stockDayKInfoRepository;
        this.exchangeCalendarRepository = exchangeCalendarRepository;
    }

    /**
     * 更新股票前五日的前五天总成交量
     */
    public void updateFiveDayTotal() {
        log.info(">>>>>>>>更新股票前五日的前五天总成交量开始<<<<<<<<");
        int size = 6;
        List<ExchangeCalendarModel> list = findFirstFiveDateList(size);
        if (list.size() != size) {
            return;
        }
        LocalDate startDate = LocalDateUtil.parseDate(list.get(size - 1).getCalendarDate());

        LocalDate now = LocalDate.now();
        //  查询出前5个交易日日K数据，不包含今天
        List<StockDayKInfoModel> stockDayInfos = stockDayKInfoRepository.findByDateGreaterThanEqualAndDateLessThan(startDate, now);
        ApplicationCache.fiveDayVolumeTotal = stockDayInfos.stream()
                // 分组求成交量总和
                .collect(Collectors.groupingBy(StockDayKInfoModel::getStockCode, Collectors.summarizingLong(StockDayKInfoModel::getVolume)))
                // 遍历转换
                .entrySet().stream()
                .collect(Collectors.toMap(Map.Entry::getKey, e -> e.getValue().getSum()));

        log.info("更新股票前五日的前五天总成交量完成，startDate={},{}", startDate, ApplicationCache.fiveDayVolumeTotal);
        log.info(">>>>>>>>更新股票前五日的前五天总成交量结束<<<<<<<<");
    }

    /**
     * 查询前size个交易日的交易所日历，包含今天
     */
    private List<ExchangeCalendarModel> findFirstFiveDateList(int size) {
        Pageable pageable = JPAPageableUtil.getFirstPageableDesc(size, "calendarDate");
        Page<ExchangeCalendarModel> page = exchangeCalendarRepository.findAll(ExchangeCalendarBO.createSpecification(), pageable);
        return page.getContent();
    }

}