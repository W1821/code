package com.hb.quotestock.collector.runner;


import com.hb.quotestock.collector.cache.ApplicationCache;
import com.hb.quotestock.collector.config.QuoteConfig;
import com.hb.quotestock.collector.job.QuoteConverter;
import com.hb.quotestock.collector.job.sina.SinaQuoteCollectHandler;
import com.hb.quotestock.collector.job.tl.TlHttpHandler;
import com.hb.quotestock.collector.job.tl.TlRedisSubscribeManager;
import com.hb.quotestock.collector.service.*;
import com.hb.quotestock.common.constant.QuoteSourceEnum;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

/**
 * 服务启动时执行
 */
@Component
@Order(value = 2)
@Slf4j
public class TlQuoteRunner implements ApplicationRunner {

    private final SinaQuoteCollectHandler sinaQuoteCollectHandler;
    private final TlRedisSubscribeManager tlRedisSubscribeManager;
    private final TlHttpHandler tlHttpHandler;

    @Autowired
    public TlQuoteRunner(
            SinaQuoteCollectHandler sinaQuoteCollectHandler,
            TlRedisSubscribeManager tlRedisSubscribeManager,
            TlHttpHandler tlHttpHandler) {

        this.sinaQuoteCollectHandler = sinaQuoteCollectHandler;
        this.tlRedisSubscribeManager = tlRedisSubscribeManager;
        this.tlHttpHandler = tlHttpHandler;
    }

    @Override
    public void run(ApplicationArguments args) {
        log.debug(">>>>>>>>>>>>>> 服务启动后执行-通联行情 start <<<<<<<<<<<<<");
        if (!ApplicationCache.quoteSource.equals(QuoteSourceEnum.TL)) {
            log.info("未使用{}行情,不启动订阅任务", QuoteSourceEnum.TL.getValue());
            return;
        }
        log.info("抓取一次新浪行情补充缓存数据");
        sinaQuoteCollectHandler.collectStock();

        if (QuoteConverter.isAfterTransactionTime()) {
            log.info("盘后科创板交易时间内启动，抓取一次盘后科创板行情");
            tlHttpHandler.collectTlKcbQuoteAfterTrans();
        }
        log.info("启动通联redis订阅");
        tlRedisSubscribeManager.startTLQuoteSubscribeTask();

        log.debug(">>>>>>>>>>>>>> 服务启动后执行-通联行情 end   <<<<<<<<<<<<<");
    }


}