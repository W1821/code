package com.hb.quotestock.collector.config;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

import java.util.ArrayList;
import java.util.List;

/**
 * 行情源配置
 */
@Configuration
@ConfigurationProperties(prefix = "quote")
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class QuoteConfig {

    private String source;

}
