package com.hb.quotestock.collector.websocket.server;

import com.hb.quotestock.common.websocket.server.WSHandshakeInterceptor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.server.ServerHttpRequest;
import org.springframework.http.server.ServerHttpResponse;
import org.springframework.stereotype.Component;
import org.springframework.web.socket.WebSocketHandler;

import java.util.Map;

/**
 * web socket 握手拦截器
 */
@Slf4j
@Component
public class CollectorWSInterceptor extends WSHandshakeInterceptor {

    /**
     * web socket 握手前拦截处理
     */
    @Override
    public boolean beforeHandshake(ServerHttpRequest request, ServerHttpResponse response, WebSocketHandler wsHandler, Map<String, Object> attributes) {
        super.beforeHandshake(request, response, wsHandler, attributes);
        return true;
    }

}
