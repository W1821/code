package com.hb.quotestock.collector.job.sina;


import com.alibaba.fastjson.JSONObject;
import com.hb.quotestock.collector.cache.ApplicationCache;
import com.hb.quotestock.collector.job.QuoteConverter;
import com.hb.quotestock.common.cache.QuoteCache;
import com.hb.quotestock.common.constant.QuoteSourceEnum;
import com.hb.quotestock.common.constant.QuoteTypeEnum;
import com.hb.quotestock.common.pojo.quote.ExponentQuote;
import com.hb.quotestock.common.pojo.quote.QuoteWrapper;
import com.hb.quotestock.common.pojo.quote.SinaIndustryQuote;
import com.hb.quotestock.common.pojo.quote.StockQuote;
import com.hb.quotestock.common.util.FastJsonUtil;
import com.hb.quotestock.common.util.QuoteUtil;
import com.hb.quotestock.common.util.StringUtil;
import lombok.extern.slf4j.Slf4j;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 * 新浪行情转换工具
 */
@Slf4j
class SinaQuoteConverter extends QuoteConverter {

    private static final int SING_STOCK_ARRAY_LENGTH = 34;

    /* ====================================== 转换指数 start ========================================= */

    /**
     * 新浪采集的数据整理成ExponentWrapper
     */
    static List<QuoteWrapper<ExponentQuote>> convertToExponentWrapper(String data) {
        Stream<String[]> stream = parseSinaDate(data);
        if (stream == null) {
            return new ArrayList<>();
        }
        return stream
                .map(SinaQuoteConverter::createExponentDTOWrapper)
                .filter(dto -> dto.getQuoteData() != null)
                .collect(Collectors.toList());
    }

    /**
     * 创建ExponentDTOWrapper对象
     */
    private static QuoteWrapper<ExponentQuote> createExponentDTOWrapper(String[] quoteArr) {
        QuoteWrapper<ExponentQuote> wrapper = new QuoteWrapper<>();
        wrapper.setQuoteSource(QuoteSourceEnum.SINA);
        wrapper.setQuoteType(QuoteTypeEnum.EXPONENT);
        try {
            ExponentQuote exponent = ExponentQuote.builder()
                    .ed(quoteArr[0].substring(0, 2))
                    .sd(quoteArr[0].substring(2))
                    .sn(quoteArr[1])
                    .jk(quoteArr[2])
                    .zs(quoteArr[3])
                    .cps(quoteArr[4])
                    .zg(quoteArr[5])
                    .zd(quoteArr[6])
                    .dsn(quoteArr[9])
                    .dsm(quoteArr[10])
                    .date(quoteArr[31] + " " + quoteArr[32])
                    .build();
            wrapper.setQuoteData(exponent);
        } catch (Exception e) {
            // 可能出现的异常
            log.error("创建ExponentDTO对象出错", e);
        }
        return wrapper;
    }

    /* ====================================== 转换指数 end ========================================= */

    /* ====================================== 转换新浪行业 start =================================== */

    /**
     * 新浪行业行情
     * {"new_blhy":"new_blhy,玻璃行业,19,8.6978947368421,-0.19736842105263,-2.2188036210875,61712302,479264649,sh600176,0.612,8.220,0.050,中国巨石"}
     */
    static List<QuoteWrapper<SinaIndustryQuote>> convertToSinaIndustryWrapper(String result) {
        try {
            String json = result.substring(37);
            JSONObject jsonObject = FastJsonUtil.toJsonObject(json);
            return jsonObject.values()
                    .stream()
                    .map(obj -> createSinaIndustryDTOWrapper((String) obj))
                    .filter(dto -> dto.getQuoteData() != null)
                    .collect(Collectors.toList());
        } catch (IndexOutOfBoundsException e) {
            log.error("新浪返回行业数据异常,line={}", result);
            return new ArrayList<>();
        }
    }

    private static QuoteWrapper<SinaIndustryQuote> createSinaIndustryDTOWrapper(String str) {
        QuoteWrapper<SinaIndustryQuote> wrapper = new QuoteWrapper<>();
        wrapper.setQuoteSource(QuoteSourceEnum.SINA);
        wrapper.setQuoteType(QuoteTypeEnum.SINA_INDUSTRY);

        String[] industryArr = StringUtil.splitComma(str);
        if (industryArr == null) {
            return wrapper;
        }

        SinaIndustryQuote sinaIndustry = SinaIndustryQuote.builder()
                .hydm(industryArr[0])
                .hymc(industryArr[1])
                .hypjjg(industryArr[3])
                .hyzde(industryArr[4])
                .hyzdf(industryArr[5])
                .hycjzl(industryArr[6])
                .hycjze(industryArr[7])
                .lzgdm(industryArr[8])
                .lzgzdf(industryArr[9])
                .lzgdqj(industryArr[10])
                .lzgzde(industryArr[11])
                .lzgmc(industryArr[12])
                .build();
        // 计算有涨跌股票数量
        computeSinaIndustryZDSL(sinaIndustry);

        wrapper.setQuoteData(sinaIndustry);
        return wrapper;
    }

    /**
     * 计算有涨跌股票数量
     */
    private static void computeSinaIndustryZDSL(SinaIndustryQuote sinaIndustry) {
        List<String> stockCodeList = ApplicationCache.sinaIndustryStockCode.get(sinaIndustry.getHydm());
        if (stockCodeList == null) {
            return;
        }
        List<StockQuote> stockList = QuoteCache.STOCK.values().stream()
                .map(QuoteWrapper::getQuoteData)
                .filter(Objects::nonNull)
                .filter(e -> stockCodeList.contains(e.getEd() + e.getSd()))
                .collect(Collectors.toList());

        long up = stockList.stream().filter(e -> e.getCg() > 0).count();
        long down = stockList.stream().filter(e -> e.getCg() < 0).count();
        long flat = stockList.stream().filter(e -> e.getCg() == 0).count();

        sinaIndustry.setHyzs("" + up);
        sinaIndustry.setHyds("" + down);
        sinaIndustry.setHyps("" + flat);
    }

    /* ====================================== 转换新浪行业 end ========================================= */

    /* ====================================== 转换新浪股票 start ======================================= */

    /**
     * 将sina抓取的股票数据转换为我们需要的
     */
    static List<QuoteWrapper<StockQuote>> convertToStockWrapper(String data) {
        Stream<String[]> stream = parseSinaDate(data);
        if (stream == null) {
            return new ArrayList<>();
        }
        return stream
                .map(SinaQuoteConverter::createStockDTOWrapper)
                .filter(dto -> dto.getQuoteData() != null)
                .collect(Collectors.toList());
    }

    /**
     * 创建StockDTOWrapper对象
     */
    private static QuoteWrapper<StockQuote> createStockDTOWrapper(String[] array) {
        QuoteWrapper<StockQuote> wrapper = new QuoteWrapper<>();
        wrapper.setQuoteSource(QuoteSourceEnum.SINA);
        wrapper.setQuoteType(QuoteTypeEnum.STOCK);
        StockQuote stock = buildStockDTO(array);
        wrapper.setQuoteData(stock);
        return wrapper;
    }

    private static StockQuote buildStockDTO(String[] array) {
        String stockCode = array[0].substring(2);
        String stockName = getStockName(stockCode);
        // 缓存中找不到的股票代码，不处理
        if (stockName == null) {
            return null;
        }
        try {
            StockQuote stock = StockQuote.builder()
                    .ed(array[0].substring(0, 2))
                    .sd(stockCode)
                    .sn(stockName)

                    .tp(Float.parseFloat(array[2]))
                    .ytp(Float.parseFloat(array[3]))
                    .cp(Float.parseFloat(array[4]))
                    .tmp(Float.parseFloat(array[5]))
                    .tip(Float.parseFloat(array[6]))
                    .cbp(Float.parseFloat(array[7]))
                    .csp(Float.parseFloat(array[8]))

                    .dsn(array[9])
                    .dsm(array[10])

                    .b1(Float.parseFloat(array[11]))
                    .b1p(Float.parseFloat(array[12]))
                    .b2(Float.parseFloat(array[13]))
                    .b2p(Float.parseFloat(array[14]))
                    .b3(Float.parseFloat(array[15]))
                    .b3p(Float.parseFloat(array[16]))
                    .b4(Float.parseFloat(array[17]))
                    .b4p(Float.parseFloat(array[18]))
                    .b5(Float.parseFloat(array[19]))
                    .b5p(Float.parseFloat(array[20]))

                    .s1(Float.parseFloat(array[21]))
                    .s1p(Float.parseFloat(array[22]))
                    .s2(Float.parseFloat(array[23]))
                    .s2p(Float.parseFloat(array[24]))
                    .s3(Float.parseFloat(array[25]))
                    .s3p(Float.parseFloat(array[26]))
                    .s4(Float.parseFloat(array[27]))
                    .s4p(Float.parseFloat(array[28]))
                    .s5(Float.parseFloat(array[29]))
                    .s5p(Float.parseFloat(array[30]))

                    .date(array[31] + " " + array[32])
                    .build();

            // 如果是科创板，需要赋值盘后行情
            if (QuoteUtil.stockIsKCB(stock.getSd())) {
                setAfterTicker(stock, array[34]);
            }

            // 计算涨跌幅、涨跌价、换手率
            compute(stock);
            return stock;

        } catch (Exception e) {
            log.error("创建StockDTO对象出错，{}", array, e);
            return null;
        }
    }


    /**
     * 赋值盘后交易量
     */
    private static void setAfterTicker(StockQuote stock, String data) {
        String[] arr = StringUtil.splitVerticalLine(data);
        if (arr == null) {
            stock.setCdsn("0");
            stock.setCdsm("0");
        } else {
            stock.setCdsn(arr[1]);
            stock.setCdsm(arr[2]);
        }
    }

    /* ====================================== 转换新浪股票 end ========================================= */

    /**
     * 解析新浪数据
     */
    private static Stream<String[]> parseSinaDate(String data) {
        String[] lines = StringUtil.splitNewline(data);
        if (lines == null) {
            return null;
        }
        return Arrays.stream(lines)
                .map(SinaQuoteConverter::parseSinaQuote)
                .filter(Objects::nonNull)
                .map(StringUtil::splitComma)
                .filter(Objects::nonNull)
                .filter(quoteArr -> quoteArr.length >= SING_STOCK_ARRAY_LENGTH);
    }

    /**
     * 解析新浪返回的行情数据
     */
    private static String parseSinaQuote(String str) {
        try {
            String stockId = str.substring(11, 19);
            return stockId + "," + str.substring(21).substring(0, str.substring(21).length() - 2);
        } catch (IndexOutOfBoundsException e) {
            log.error("新浪返回数据异常,line={}", str);
            return null;
        }
    }

}
