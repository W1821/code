package com.hb.quotestock.collector.service;

import com.hb.quotestock.collector.cache.ApplicationCache;
import com.hb.quotestock.collector.pojo.bo.ExchangeCalendarBO;
import com.hb.quotestock.common.repository.ExchangeCalendarRepository;
import com.hb.quotestock.common.pojo.po.ExchangeCalendarModel;
import com.hb.quotestock.common.util.JPAPageableUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

/**
 * 交易所日历Service层
 */
@Slf4j
@Service
public class ExchangeCalendarService {


    private final ExchangeCalendarRepository exchangeCalendarRepository;

    @Autowired
    public ExchangeCalendarService(ExchangeCalendarRepository exchangeCalendarRepository) {
        this.exchangeCalendarRepository = exchangeCalendarRepository;
    }

    /**
     * 更新上交所科创板的无限制交易的开盘日期
     */
    public void updateShKcbNoLimitDates() {
        log.info(">>>>>>>> 更新上交所科创板的无限制交易的开盘日期开始 <<<<<<<<");
        int size = 5;
        List<ExchangeCalendarModel> list = findFirstFiveDateList(size);
        if (list.size() != size) {
            log.error("更新上交所科创板的无限制交易的开盘日期失败，交易所日历数据不够！");
            return;
        }
        ApplicationCache.kcbNoLimitDateList = list.stream().map(ExchangeCalendarModel::getCalendarDate).collect(Collectors.toList());
        log.info("更新上交所科创板的无限制交易的开盘日期,{}", ApplicationCache.kcbNoLimitDateList);
        log.info(">>>>>>>> 更新上交所科创板的无限制交易的开盘日期结束 <<<<<<<<");
    }

    /**
     * 查询前size个交易日的交易所日历，包含今天
     */
    private List<ExchangeCalendarModel> findFirstFiveDateList(int size) {
        Pageable pageable = JPAPageableUtil.getFirstPageableDesc(size, "calendarDate");
        Page<ExchangeCalendarModel> page = exchangeCalendarRepository.findAll(ExchangeCalendarBO.createSpecification(), pageable);
        return page.getContent();
    }


}