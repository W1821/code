package com.hb.quotestock.collector.cache;

import com.hb.quotestock.common.constant.QuoteSourceEnum;
import com.hb.quotestock.common.pojo.po.StockBasicInfoModel;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class ApplicationCache {

    /**
     * 当前行情源缓存,默认用新浪
     */
    public static QuoteSourceEnum quoteSource = QuoteSourceEnum.SINA;

    /**
     * 新浪股票采集url的参数
     * 用于每秒采集股票行情
     */
    public static List<String> sinaStockUrlCollectParams = new ArrayList<>();

    /**
     * 科创板股票代码集合
     */
    public static String kcbStockCodeStr = "";

    /**
     * 股票基本信息缓存，如"000003:StockBaseInfo","000232:StockBaseInfo"
     * 便于查询
     */
    public static Map<String, StockBasicInfoModel> stockBasicInfoMap = new ConcurrentHashMap<>();

    /**
     * 新浪行业-股票编号集合缓存
     * key格式：new_blhy
     */
    public static Map<String, List<String>> sinaIndustryStockCode = new ConcurrentHashMap<>();

    /**
     * 股票前五日的前五天总成交量
     * key格式：000001
     */
    public static Map<String, Long> fiveDayVolumeTotal = new ConcurrentHashMap<>();

    /**
     * 上交所科创板的无限制交易日的日期集合
     */
    public static List<String> kcbNoLimitDateList = new ArrayList<>();

    /**
     * 当日开盘分钟数
     */
    public static long openMinutesToday = 0;


}
