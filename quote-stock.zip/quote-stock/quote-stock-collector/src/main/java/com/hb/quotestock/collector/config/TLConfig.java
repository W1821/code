package com.hb.quotestock.collector.config;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;

/**
 * 通联配置
 */
@Configuration
@ConfigurationProperties(prefix = "tl")
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class TLConfig {
    /**
     * mdl redis数据库ip
     */
    private String mdlRedisIp;
    /**
     * mdl redis数据库port
     */
    private int mdlRedisPort;
    /**
     * http 科创板行情url
     */
    private String httpKcbQuoteUrl;

    private String secret;
}
