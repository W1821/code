package com.hb.quotestock.collector.websocket.server;

import com.hb.quotestock.common.pojo.quote.BaseQuote;
import com.hb.quotestock.common.pojo.quote.QuoteWrapper;
import com.hb.quotestock.common.websocket.server.WSClientSession;
import com.hb.quotestock.common.websocket.server.WSClientSessionManager;
import org.springframework.web.socket.WebSocketSession;

public class CollectorQuoteSender {

    /**
     * 响应消息给所有客户端，没有做行情订阅判断，collector发送server端使用此方法。
     */
    public static void sendMsgToAll(QuoteWrapper<? extends BaseQuote> wrapper) {
        WSClientSessionManager.getAllWebSocketClient().forEach(clientSession -> WSClientSessionManager.sendMsgToClient(clientSession, wrapper.toString()));
    }

    /**
     * 响应消息给单个客户端，没有行情订阅判断，collector发送server端使用此方法。
     */
    public static void sendMsgToClient(WebSocketSession webSocketSession, QuoteWrapper<? extends BaseQuote> wrapper) {
        WSClientSession clientSession = WSClientSessionManager.getClientSessionById(webSocketSession.getId());
        if (clientSession == null) {
            return;
        }
        WSClientSessionManager.sendMsgToClient(clientSession, wrapper.toString());
    }

}
