package com.hb.quotestock.collector.schedule;

import com.hb.quotestock.collector.service.ExchangeCalendarService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

/**
 * 交易所日历定时器
 */
@Component
@Slf4j
public class ExchangeCalendarUpdateSchedule {

    private final ExchangeCalendarService exchangeCalendarService;

    @Autowired
    public ExchangeCalendarUpdateSchedule(ExchangeCalendarService exchangeCalendarService) {
        this.exchangeCalendarService = exchangeCalendarService;
    }

    /**
     * 更新上交所科创板的无限制交易的开盘日期
     */
    @Scheduled(cron = "30 0 0 * * ? ")
    public void updateExchangeCalendar() {
        exchangeCalendarService.updateShKcbNoLimitDates();
    }

}
