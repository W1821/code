package com.hb.quotestock.collector.schedule;

import com.hb.quotestock.collector.service.OpenMinutesUpdateService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

/**
 * 当天的交易累计分钟更新
 */
@Component
@Slf4j
public class OpenMinutesUpdateSchedule {

    private final OpenMinutesUpdateService openMinutesUpdateService;

    @Autowired
    public OpenMinutesUpdateSchedule(OpenMinutesUpdateService openMinutesUpdateService) {
        this.openMinutesUpdateService = openMinutesUpdateService;
    }

    /**
     * 9-15每分钟执行一次，更新当日交易分钟累计
     */
    @Scheduled(cron = "0 0/1 9-15 * * ?")
    public void updateOpenMinutes() {
        openMinutesUpdateService.updateOpenMinutes();
    }


}
