package com.hb.quotestock.collector.schedule;

import com.hb.quotestock.collector.service.SinaIndustryCacheService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

/**
 * 新浪行情数据缓存更新
 */
@Component
@Slf4j
public class SinaIndustryUpdateSchedule {

    private final SinaIndustryCacheService sinaIndustryCacheService;

    @Autowired
    public SinaIndustryUpdateSchedule(SinaIndustryCacheService sinaIndustryCacheService) {
        this.sinaIndustryCacheService = sinaIndustryCacheService;
    }

    /**
     * 每日16点半定时更新新浪行情分类数据
     */
    @Scheduled(cron = "0 0 16 * * ?")
    public void sinaIndustryUpdate() {
        sinaIndustryCacheService.updateSinaIndustryCache();
    }


}