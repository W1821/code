package com.hb.quotestock.collector.pojo.tl;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * 科创板盘后交易行情五档
 */
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class TlTickerBook {

    /**
     * 委托量
     */
    private Float orderQty;
    /**
     * 委托笔数
     */
    private Integer numOrders;
    /**
     * 委托明细
     */
    private String orders;

}
