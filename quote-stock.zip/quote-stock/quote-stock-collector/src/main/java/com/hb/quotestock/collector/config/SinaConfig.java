package com.hb.quotestock.collector.config;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

/**
 * 新浪采集配置
 */
@Configuration
@ConfigurationProperties(prefix = "sina")
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class SinaConfig {
    /**
     * 股票采集url
     */
    private String stockUrl;
    /**
     * 指数采集url
     */
    private String exponentUrl;
    /**
     * 新浪行业采集url
     */
    private String industryUrl;
}
