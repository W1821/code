package com.hb.quotestock.collector.constant;

import com.hb.quotestock.common.util.ThreadPoolUtil;
import lombok.extern.slf4j.Slf4j;

import java.util.concurrent.ThreadPoolExecutor;

/**
 * 使用@Scheduled方式进行定时器任务，由于默认单线程，所以需要使用线程池进行任务异步执行
 * 这是为了防止某个定时器任务出错或超时导致其他任务异常
 */
@Slf4j
public class ThreadPoolConstant {

    /**
     * 新浪股票行情采集 开盘中1秒一次，为了保证有序使用单线程池
     * 一次采集大概需要 3800/500 次http请求，所以线程队列理论上设置为8就可以了
     * 冗余设计为 100
     */
    public static final ThreadPoolExecutor SINA_STOCK_COLLECT_POOL = ThreadPoolUtil.createSingleExecutor("sina_stock_collect-thread", 100);

    /**
     * 新浪指数行情采集 开盘中1秒一次，为了保证有序使用单线程池
     * 一次采集就一次http请求，所以线程队列理论上设置为1就可以了
     * 冗余设计为 10
     */
    public static final ThreadPoolExecutor SINA_EXPONENT_COLLECT_POOL = ThreadPoolUtil.createSingleExecutor("sina_exponent_collect-thread", 10);

    /**
     * 新浪行业行情采集 开盘中1秒一次，为了保证有序使用单线程池
     * 一次采集就一次http请求，所以线程队列理论上设置为1就可以了
     * 冗余设计为 10
     */
    public static final ThreadPoolExecutor SINA_INDUSTRY_COLLECT_POOL = ThreadPoolUtil.createSingleExecutor("sina_industry_collect-thread", 10);

    /**
     * 通联盘后科创板行情采集 开盘中1秒一次，为了保证有序使用单线程池
     * 一次采集就一次http请求，所以线程队列理论上设置为1就可以了
     * 冗余设计为 10
     */
    public static final ThreadPoolExecutor TL_KCB_COLLECT_POOL = ThreadPoolUtil.createSingleExecutor("tl_kcb_collect-thread", 10);

}
