package com.hb.quotestock.collector.schedule;

import com.hb.quotestock.collector.service.StockBasicInfoService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

/**
 * 股票基本信息定时器
 */
@Component
@Slf4j
public class StockBasicInfoUpdateSchedule {

    private final StockBasicInfoService stockBasicInfoService;

    @Autowired
    public StockBasicInfoUpdateSchedule(StockBasicInfoService stockBasicInfoService) {
        this.stockBasicInfoService = stockBasicInfoService;
    }

    /**
     * 每日8点半定时更新股票基本数据,从库里拿最新数据
     */
    @Scheduled(cron = "0 1/30 8-15 * * ? ")
    public void stockBaseInfoUpdate() {
        stockBasicInfoService.updateStockBasicInfo();
    }


}