package com.hb.quotestock.collector.websocket.server;

import com.hb.quotestock.common.cache.QuoteCache;
import com.hb.quotestock.common.websocket.server.WSMessageHandler;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.web.socket.WebSocketSession;

import java.util.Objects;


@Slf4j
@Component
public class CollectorWSMessageHandler extends WSMessageHandler {

    /**
     * 新连接打开
     */
    @Override
    public void afterConnectionEstablished(WebSocketSession session) {
        // 放入管理对象中
        putWSClientSessionToManager(session);
        // 发送行情数据
        sendQuote(session);
    }

    private void sendQuote(WebSocketSession session) {
        // 股票
        sendStockQuote(session);
        // 指数行情
        sendExponentQuote(session);
        // 股票逐笔
        sendTransactionQuote(session);
        // 新浪行业行情缓存
        sendSinaIndustryQuote(session);
    }

    private void sendSinaIndustryQuote(WebSocketSession session) {
        QuoteCache.SINA_INDUSTRY.values()
                .stream()
                .filter(Objects::nonNull)
                .forEach(wrapper -> CollectorQuoteSender.sendMsgToClient(session, wrapper));
    }

    private void sendTransactionQuote(WebSocketSession session) {
        QuoteCache.TRANSACTION.values()
                .stream()
                .filter(Objects::nonNull)
                .forEach(wrapper -> CollectorQuoteSender.sendMsgToClient(session, wrapper));
    }

    private void sendExponentQuote(WebSocketSession session) {
        QuoteCache.EXPONENT.values()
                .stream()
                .filter(Objects::nonNull)
                .forEach(wrapper -> CollectorQuoteSender.sendMsgToClient(session, wrapper));
    }

    private void sendStockQuote(WebSocketSession session) {
        QuoteCache.STOCK.values()
                .stream()
                .filter(Objects::nonNull)
                .forEach(wrapper -> CollectorQuoteSender.sendMsgToClient(session, wrapper));
    }

}
