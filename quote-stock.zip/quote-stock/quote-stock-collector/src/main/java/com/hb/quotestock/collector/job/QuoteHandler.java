package com.hb.quotestock.collector.job;

import com.hb.quotestock.collector.websocket.server.CollectorQuoteSender;
import com.hb.quotestock.common.cache.QuoteCache;
import com.hb.quotestock.common.pojo.quote.*;
import com.hb.quotestock.common.util.QuoteUtil;

public class QuoteHandler {
    /**
     * 先计算逐笔并发送
     * 再发送股票行情消息
     */
    public void sendStockQuoteWrapper(QuoteWrapper<StockQuote> wrapper) {
        // 先计算逐笔并发送，因为用到了股票上一笔行情记录，所以需要先执行
        QuoteWrapper<TransactionQuote> transactionDTOWrapper = QuoteConverter.getTransactionByQuote(wrapper);
        // 发送逐笔
        if (transactionDTOWrapper != null) {
            sendStockTransactionMessage(transactionDTOWrapper);
        }
        // 再发送股票行情消息
        sendStockQuoteMessage(wrapper);
    }

    /**
     * 发送指数
     */
    protected void sendExponentMessage(QuoteWrapper<ExponentQuote> wrapper) {
        ExponentQuote current = wrapper.getQuoteData();
        QuoteWrapper<ExponentQuote> oldWrapper = QuoteCache.EXPONENT.get(current.getSd());

        // 相同就不发送
        if (oldWrapper != null && equals(oldWrapper.getQuoteData(), current)) {
            return;
        }

        // 放入缓存中
        QuoteCache.EXPONENT.put(current.getSd(), wrapper);
        // 打印日志
        QuoteUtil.log(wrapper);
        // 发送消息，使用线程
        CollectorQuoteSender.sendMsgToAll(wrapper);
    }

    /**
     * 发送新浪行业
     */
    protected void sendSinaIndustryMessage(QuoteWrapper<SinaIndustryQuote> wrapper) {
        SinaIndustryQuote current = wrapper.getQuoteData();
        QuoteWrapper<SinaIndustryQuote> oldWrapper = QuoteCache.SINA_INDUSTRY.get(current.getHydm());
        if (oldWrapper != null && equals(oldWrapper.getQuoteData(), current)) {
            return;
        }
        // 放入缓存中
        QuoteCache.SINA_INDUSTRY.put(current.getHydm(), wrapper);
        // 打印日志
        QuoteUtil.log(wrapper);
        // 发送消息，使用线程
        CollectorQuoteSender.sendMsgToAll(wrapper);
    }


    /**
     * 判断缓存和当前是否一样
     */
    private boolean equals(BaseQuote old, BaseQuote current) {
        if (old == null) {
            return false;
        }
        return old.toString().equals(current.toString());
    }


    /**
     * 发送股票行情
     */
    private void sendStockQuoteMessage(QuoteWrapper<StockQuote> wrapper) {
        StockQuote current = wrapper.getQuoteData();
        QuoteWrapper<StockQuote> oldWrapper = QuoteCache.STOCK.get(current.getSd());
        if (oldWrapper != null && equals(oldWrapper.getQuoteData(), current)) {
            return;
        }
        // 放入缓存中
        QuoteCache.STOCK.put(current.getSd(), wrapper);
        // 打印日志
        QuoteUtil.log(wrapper);
        // 发送消息，使用线程
        CollectorQuoteSender.sendMsgToAll(wrapper);
    }

    /**
     * 发送股票逐笔
     */
    private void sendStockTransactionMessage(QuoteWrapper<TransactionQuote> wrapper) {
        TransactionQuote current = wrapper.getQuoteData();
        QuoteWrapper<TransactionQuote> oldWrapper = QuoteCache.TRANSACTION.get(current.getSd());
        if (oldWrapper != null && equals(oldWrapper.getQuoteData(), current)) {
            return;
        }
        // 放入缓存中
        QuoteCache.TRANSACTION.put(current.getSd(), wrapper);
        // 打印日志
        QuoteUtil.log(wrapper);
        // 发送消息，使用线程
        CollectorQuoteSender.sendMsgToAll(wrapper);
    }


}
