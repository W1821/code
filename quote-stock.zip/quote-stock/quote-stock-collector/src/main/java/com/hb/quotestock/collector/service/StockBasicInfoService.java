package com.hb.quotestock.collector.service;

import com.hb.quotestock.collector.cache.ApplicationCache;
import com.hb.quotestock.common.pojo.po.StockBasicInfoModel;
import com.hb.quotestock.common.repository.StockBasicInfoRepository;
import com.hb.quotestock.common.util.ListUtil;
import com.hb.quotestock.common.util.QuoteUtil;
import com.hb.quotestock.common.util.StringUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;


/**
 * 股票基本信息
 */
@Service
@Slf4j
public class StockBasicInfoService {

    /**
     * 一次请求新浪股票行情的股票数量
     */
    private static final int SINA_STOCK_NUMBER = 500;

    private final StockBasicInfoRepository stockBasicInfoRepository;

    @Autowired
    public StockBasicInfoService(StockBasicInfoRepository stockBasicInfoRepository) {
        this.stockBasicInfoRepository = stockBasicInfoRepository;
    }

    /**
     * 更新股票基础数据信息，存到系统缓存
     */
    public void updateStockBasicInfo() {
        log.info(">>>>>>>>更新股票基本信息开始<<<<<<<<");
        List<StockBasicInfoModel> list = stockBasicInfoRepository.findAll();

        List<String> sinaCodeList = new ArrayList<>();
        List<String> kcbStockCodeList = new ArrayList<>();
        Map<String, StockBasicInfoModel> stockBasicInfoMap = new ConcurrentHashMap<>();

        for (StockBasicInfoModel model : list) {
            // 判断是否退市，退市的股票不需要
            if (isDE(model)) {
                continue;
            }

            // 抓取新浪行情需要的交易所简码 sh或sz
            String sinaExchangeCode = getSinaExchangeCode(model.getExchangeCode());
            // 股票编号 000001
            String stockCode = model.getStockCode();

            // 交易所+股票代码 数据缓存
            sinaCodeList.add(sinaExchangeCode + stockCode);

            // 判断是否是科创板
            if (QuoteUtil.stockIsKCB(stockCode)) {
                kcbStockCodeList.add(stockCode);
            }
            // 股票基本信息缓存
            stockBasicInfoMap.put(stockCode, model);
        }

        ApplicationCache.stockBasicInfoMap = stockBasicInfoMap;
        ApplicationCache.kcbStockCodeStr = ListUtil.joinCommaToString(kcbStockCodeList);
        updateSinaStockUrlCollectParams(sinaCodeList);
        log.info("加载股票基础数据结束，共{}条数据", sinaCodeList.size());
        log.info(">>>>>>>>更新股票基本信息结束<<<<<<<<");
    }

    /**
     * 判断是否退市
     */
    private boolean isDE(StockBasicInfoModel model) {
        return !StringUtil.equals(model.getListStatusCode(), "L") && !StringUtil.equals(model.getListStatusCode(), "S");
    }

    /**
     * 返回新浪股票交易所简码
     * sh: 上交所 XSHG
     * sz：深交所 XSHE
     */
    private String getSinaExchangeCode(String exchangeCode) {
        if (StringUtil.isEmpty(exchangeCode)) {
            return "";
        }
        if (StringUtil.equals("XSHG", exchangeCode)) {
            return "sh";
        }
        if (StringUtil.equals("XSHE", exchangeCode)) {
            return "sz";
        }
        return "";
    }

    private void updateSinaStockUrlCollectParams(List<String> sinaCodeList) {
        if (sinaCodeList == null) {
            return;
        }
        List<String> sinaStockUrlCollectParams = new ArrayList<>();
        int size = sinaCodeList.size() % SINA_STOCK_NUMBER == 0 ? sinaCodeList.size() / SINA_STOCK_NUMBER : sinaCodeList.size() / SINA_STOCK_NUMBER + 1;
        for (int i = 0; i < size; i++) {
            List<String> list = sinaCodeList.stream()
                    .skip(i * SINA_STOCK_NUMBER)
                    .limit(SINA_STOCK_NUMBER)
                    .collect(Collectors.toList());
            sinaStockUrlCollectParams.add(ListUtil.joinCommaToString(list));
        }
        ApplicationCache.sinaStockUrlCollectParams = sinaStockUrlCollectParams;
    }

}
