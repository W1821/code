- quote-stock-collector 股票行情采集器，负责获取行情相关数据
- quote-stock-server  股票行情站点，负责通过websocket从collector接收行情，然后推送给其他应用，包括app端
- quote-stock-app  客户自己搭建行情服务
- quote-stock-data  数据服务， 负责从数据库提供数据查询接口
- quote-stock-task-center  任务中心，负责定时从通联和新浪抓取基本数据入库

---

**app端**

1. 删除股票排行榜接口（通过抓取新浪排行榜接口实现的）
2. 移除新浪采集行情功能（功能不全，没有计算涨跌幅、涨跌价、换手率、量比）

**data端**

1. 删除股票排行榜接口（通过抓取新浪排行榜接口实现的）
2. 删除股票排序（通过抓取新浪行情排序实现的）

**task-center端**

1. 增加除权除息入库操作