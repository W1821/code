package com.hb.quotestock.data.schedule;

import com.hb.quotestock.data.service.StockBasicInfoService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

@Component
@Slf4j
public class StockBasicInfoSchedule {

    private final StockBasicInfoService stockBasicInfoService;

    public StockBasicInfoSchedule(StockBasicInfoService stockBasicInfoService) {
        this.stockBasicInfoService = stockBasicInfoService;
    }

    @Scheduled(cron = "0 10/40 8-15 * * ? ")
    public void updateCache() {
        log.info("更新股票基本信息开始。。。");
        stockBasicInfoService.updateStockInfoAllListCache();
        stockBasicInfoService.updateStockInfoSectionListCache();
        log.info("更新股票基本信息结束。。。");
    }

}
