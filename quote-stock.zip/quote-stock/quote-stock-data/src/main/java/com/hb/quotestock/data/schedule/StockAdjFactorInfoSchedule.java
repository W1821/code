package com.hb.quotestock.data.schedule;

import com.hb.quotestock.data.service.StockAdjFactorService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

@Component
@Slf4j
public class StockAdjFactorInfoSchedule {

    private final StockAdjFactorService stockAdjFactorService;

    public StockAdjFactorInfoSchedule(StockAdjFactorService stockAdjFactorService) {
        this.stockAdjFactorService = stockAdjFactorService;
    }

    @Scheduled(cron = "0 5 9 * * ?")
    public void updateCache() {
        log.info("更新通联今天的除权除息信息缓存开始。。。");
        stockAdjFactorService.updateTodayAdjFactoryFromTLCache();
        log.info("更新通联今天的除权除息信息缓存结束。。。");
    }

}
