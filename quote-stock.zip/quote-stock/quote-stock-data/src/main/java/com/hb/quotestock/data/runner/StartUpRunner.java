package com.hb.quotestock.data.runner;


import com.hb.quotestock.data.service.ExchangeCalendarService;
import com.hb.quotestock.data.service.StockAdjFactorService;
import com.hb.quotestock.data.service.StockBasicInfoService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

/**
 * 服务启动时执行
 */
@Component
@Order(value = 1)
@Slf4j
public class StartUpRunner implements ApplicationRunner {

    private final ExchangeCalendarService exchangeCalendarService;
    private final StockBasicInfoService stockBasicInfoService;
    private final StockAdjFactorService stockAdjFactorService;

    @Autowired
    public StartUpRunner(
            ExchangeCalendarService exchangeCalendarService,
            StockBasicInfoService stockBasicInfoService,
            StockAdjFactorService stockAdjFactorService) {
        this.exchangeCalendarService = exchangeCalendarService;
        this.stockBasicInfoService = stockBasicInfoService;
        this.stockAdjFactorService = stockAdjFactorService;
    }

    @Override
    public void run(ApplicationArguments args) {
        log.debug(">>>>>>>>>>>>>>>服务启动后执行<<<<<<<<<<<<<");

        log.info("更新交易所日历数据信息缓存开始。。。");
        exchangeCalendarService.updateNextOneYearExchangeCalendars();
        exchangeCalendarService.updateNextTwoYearExchangeCalendars();
        log.info("更新交易所日历数据信息缓存结束。。。");

        log.info("更新通联今天的除权除息信息缓存开始。。。");
        stockAdjFactorService.updateTodayAdjFactoryFromTLCache();
        log.info("更新通联今天的除权除息信息缓存结束。。。");

        log.info("更新股票基本信息开始。。。");
        stockBasicInfoService.updateStockInfoAllListCache();
        stockBasicInfoService.updateStockInfoSectionListCache();
        log.info("更新股票基本信息结束。。。");

    }

}