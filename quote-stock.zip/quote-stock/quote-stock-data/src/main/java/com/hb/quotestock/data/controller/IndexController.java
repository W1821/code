package com.hb.quotestock.data.controller;

import com.hb.quotestock.common.pojo.dto.ResponseMessage;
import com.hb.quotestock.common.util.ResponseMessageUtil;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * 系统首页
 */
@RestController
public class IndexController {

    @RequestMapping("/")
    public ResponseMessage index() {
        return ResponseMessageUtil.success("系统正在运行");
    }
}
