package com.hb.quotestock.data.controller;

import com.hb.quotestock.common.constant.GlobalCodeEnum;
import com.hb.quotestock.common.pojo.dto.ResponseMessage;
import com.hb.quotestock.common.pojo.dto.StopResumptionDTO;
import com.hb.quotestock.common.util.LocalDateUtil;
import com.hb.quotestock.common.util.ResponseMessageUtil;
import com.hb.quotestock.data.service.StopResumptionService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.time.LocalDate;
import java.util.List;


/**
 * 股票停复牌Controller
 */
@Slf4j
@RestController
@Api("股票停复牌相关")
@RequestMapping(value = "/stock")
public class StopResumptionController {

    private final StopResumptionService stopResumptionService;

    @Autowired
    public StopResumptionController(StopResumptionService stopResumptionService) {
        this.stopResumptionService = stopResumptionService;
    }

    @RequestMapping(value = "/stopResumption", method = RequestMethod.GET)
    @ApiOperation(value = "根据时间获取股票停复牌,当日的建议每天9点更新")
    @SuppressWarnings("unchecked")
    public ResponseMessage<List<StopResumptionDTO>> getStockStopResumption(@RequestParam("date") @ApiParam("日期，yyyy-MM-dd格式") String date) {
        LocalDate localDate = LocalDateUtil.parseDate(date);
        if (localDate == null) {
            return ResponseMessageUtil.error(GlobalCodeEnum.ErrorCode.ERROR_1001);
        }
        return ResponseMessageUtil.success(stopResumptionService.getStockStopResumption(date));
    }

}
