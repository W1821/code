package com.hb.quotestock.data.cache;

import com.hb.quotestock.common.pojo.dto.*;

import java.util.ArrayList;
import java.util.List;

/**
 * 接口查询缓存
 */
public class QueryCache {

    /**
     * 股票基本信息缓存
     */
    public static List<StockInfoAllDTO> stockInfoAllList = new ArrayList<>();
    /**
     * 股票部分信息缓存
     */
    public static List<StockInfoSectionDTO> stockInfoSectionList = new ArrayList<>();


    /**
     * 通联接口返回的除权除息信息查询缓存
     */
    public static List<AdjFactorInfoTLDTO> adjFactorInfoTLList = new ArrayList<>();



    /**
     * 今天到2年后今天的股票交易所日历
     */
    public static List<ExchangeCalendarDTO> nextTwoYearExchangeCalendar = new ArrayList<>();
    /**
     * 今年和明天一整年的交易日历list
     */
    public static List<ExchangeCalendarDTO> nextOneYearExchangeCalendar = new ArrayList<>();

}
