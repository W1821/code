package com.hb.quotestock.data.service;

import com.hb.quotestock.common.pojo.dto.AdjFactorInfoImportDTO;
import com.hb.quotestock.common.pojo.dto.AdjFactorInfoTLDTO;
import com.hb.quotestock.common.pojo.po.StockAdjFactorInfoModel;
import com.hb.quotestock.common.pojo.po.StockAdjFactorInfoTLModel;
import com.hb.quotestock.common.repository.StockAdjFactorInfoRepository;
import com.hb.quotestock.common.repository.StockAdjFactorInfoTLRepository;
import com.hb.quotestock.common.util.LocalDateUtil;
import com.hb.quotestock.data.cache.QueryCache;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;

@Slf4j
@Service
public class StockAdjFactorService {


    private final StockAdjFactorInfoRepository adjFactorInfoRepository;
    private final StockAdjFactorInfoTLRepository adjFactorInfoTLRepository;

    public StockAdjFactorService(StockAdjFactorInfoRepository adjFactorInfoRepository, StockAdjFactorInfoTLRepository adjFactorInfoTLRepository) {
        this.adjFactorInfoRepository = adjFactorInfoRepository;
        this.adjFactorInfoTLRepository = adjFactorInfoTLRepository;
    }

    /**
     * 根据时间查询某天的除权除息-人工导入的数据
     */
    public List<AdjFactorInfoImportDTO> getAdjFactoryFromImportByDate(String date) {
        List<StockAdjFactorInfoModel> list = adjFactorInfoRepository.findByExcludeDate(date);
        return list
                .stream()
                .map(this::buildAdjFactorInfoDTO)
                .collect(Collectors.toList());
    }


    /**
     * 查询通联今天的除权除息信息
     */
    public List<AdjFactorInfoTLDTO> getTodayAdjFactoryFromTL() {
        return QueryCache.adjFactorInfoTLList;
    }

    /**
     * 更新通联今天的除权除息信息缓存
     */
    public void updateTodayAdjFactoryFromTLCache() {
        List<StockAdjFactorInfoTLModel> list = adjFactorInfoTLRepository.findByExDivDate(LocalDate.now());
        QueryCache.adjFactorInfoTLList = list
                .stream()
                .map(this::buildAdjFactorInfoTLDTO)
                .collect(Collectors.toList());
    }

    private AdjFactorInfoTLDTO buildAdjFactorInfoTLDTO(StockAdjFactorInfoTLModel model) {
        return AdjFactorInfoTLDTO
                .builder()
                .stockId(model.getTicker())
                .excludeDate(LocalDateUtil.formatDate(model.getExDivDate()))
                .stockName(model.getSecShortName())
                .perShareCash(model.getPerCashDiv())
                .perShareRatio(model.getPerShareDivRatio())
                .perAllotmentRatio(model.getAllotmentRatio())
                .allotmentPrice(model.getAllotmentPrice())
                .exchangeCD(model.getExchangeCode())
                .perTransRatio(model.getPerShareTransRatio())
                .adjFactor(model.getAdjFactor())
                .accumAdjFactor(model.getAccumAdjFactor())
                .adjEndDate(LocalDateUtil.formatDate(model.getEndDate()))
                .build();
    }


    private AdjFactorInfoImportDTO buildAdjFactorInfoDTO(StockAdjFactorInfoModel model) {
        return AdjFactorInfoImportDTO
                .builder()
                .stockId(model.getStockId())
                .excludeDate(model.getExcludeDate())
                .stockName(model.getStockName())
                .perShareCash(model.getPerShareCash())
                .perShareRatio(model.getPerShareRatio())
                .perAllotmentRatio(model.getPerAllotmentRatio())
                .allotmentPrice(model.getAllotmentPrice())
                .build();
    }

}
