package com.hb.quotestock.data.schedule;

import com.hb.quotestock.data.service.ExchangeCalendarService;
import com.hb.quotestock.data.service.StockAdjFactorService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

@Component
@Slf4j
public class ExchangeCalendarSchedule {

    private final ExchangeCalendarService exchangeCalendarService;

    public ExchangeCalendarSchedule(ExchangeCalendarService exchangeCalendarService) {
        this.exchangeCalendarService = exchangeCalendarService;
    }

    @Scheduled(cron = "1 0 0 * * ? ")
    public void updateCache() {
        log.info("更新交易所日历数据信息缓存开始。。。");
        exchangeCalendarService.updateNextOneYearExchangeCalendars();
        exchangeCalendarService.updateNextTwoYearExchangeCalendars();
        log.info("更新交易所日历数据信息缓存结束。。。");
    }

}
