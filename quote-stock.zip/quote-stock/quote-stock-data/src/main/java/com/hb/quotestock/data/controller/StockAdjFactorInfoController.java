package com.hb.quotestock.data.controller;

import com.hb.quotestock.common.constant.GlobalCodeEnum;
import com.hb.quotestock.common.pojo.dto.AdjFactorInfoImportDTO;
import com.hb.quotestock.common.pojo.dto.AdjFactorInfoTLDTO;
import com.hb.quotestock.common.pojo.dto.ResponseMessage;
import com.hb.quotestock.common.util.LocalDateUtil;
import com.hb.quotestock.common.util.ResponseMessageUtil;
import com.hb.quotestock.data.service.StockAdjFactorService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.time.LocalDate;
import java.util.List;

@RestController
@Api("股票除权除息")
public class StockAdjFactorInfoController {

    private final StockAdjFactorService stockAdjFactorService;

    @Autowired
    public StockAdjFactorInfoController(StockAdjFactorService stockAdjFactorService) {
        this.stockAdjFactorService = stockAdjFactorService;
    }

    @ApiOperation(value = "查询某天的除权除息，人工导入的数据")
    @RequestMapping(value = "/stock/factor/db/{exDivDate}", method = RequestMethod.GET)
    @SuppressWarnings("unchecked")
    public ResponseMessage<List<AdjFactorInfoImportDTO>> getAdjFactoryFromImport(@PathVariable("exDivDate") @ApiParam("日期，yyyy-MM-dd格式") String exDivDate) {
        LocalDate localDate = LocalDateUtil.parseDate(exDivDate);
        if (localDate == null) {
            return ResponseMessageUtil.error(GlobalCodeEnum.ErrorCode.ERROR_1001);
        }
        return ResponseMessageUtil.success(stockAdjFactorService.getAdjFactoryFromImportByDate(exDivDate));
    }

    @ApiOperation(value = "查询今天的除权除息，早上9:05分从通联获取的数据，建议在9:10之后查询")
    @RequestMapping(value = "/stock/formerAdjFactor", method = RequestMethod.GET)
    @SuppressWarnings("unchecked")
    public ResponseMessage<List<AdjFactorInfoTLDTO>> getTodayAdjFactoryFromTL() {
        return ResponseMessageUtil.success(stockAdjFactorService.getTodayAdjFactoryFromTL());
    }

}
