package com.hb.quotestock.data.service;

import com.hb.quotestock.common.pojo.dto.StockInfoAllDTO;
import com.hb.quotestock.common.pojo.dto.StockInfoSectionDTO;
import com.hb.quotestock.common.pojo.po.StockBasicInfoModel;
import com.hb.quotestock.common.repository.StockBasicInfoRepository;
import com.hb.quotestock.common.util.LocalDateUtil;
import com.hb.quotestock.common.util.StringUtil;
import com.hb.quotestock.data.cache.QueryCache;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;


/**
 * 股票基本信息
 */
@Service
@Slf4j
public class StockBasicInfoService {

    private final StockBasicInfoRepository stockBasicInfoRepository;

    @Autowired
    public StockBasicInfoService(StockBasicInfoRepository stockBasicInfoRepository) {
        this.stockBasicInfoRepository = stockBasicInfoRepository;
    }

    public List<StockInfoAllDTO> getStockBasicInfoAll() {
        return QueryCache.stockInfoAllList;
    }

    public List<StockInfoSectionDTO> getStockInfoSection() {
        return QueryCache.stockInfoSectionList;
    }

    /**
     * 更新股票基础数据信息，存到系统查询缓存
     */
    public void updateStockInfoAllListCache() {
        List<StockBasicInfoModel> list = stockBasicInfoRepository.findAll();
        QueryCache.stockInfoAllList = list
                .stream()
                .filter(model -> !isDE(model))
                .map(this::buildStockInfoAllDTO)
                .collect(Collectors.toList());
    }


    /**
     * 更新股票部分信息，存到系统查询缓存
     */
    public void updateStockInfoSectionListCache() {
        List<StockInfoAllDTO> list = QueryCache.stockInfoAllList;

        QueryCache.stockInfoSectionList = list
                .stream()
                .filter(e -> e.getSecshortname() != null)
                .map(this::buildStockInfoSectionDTO)
                .collect(Collectors.toList());
    }

    /* ============================================================================================= */

    /**
     * 判断是否退市
     */
    private boolean isDE(StockBasicInfoModel model) {
        return !StringUtil.equals(model.getListStatusCode(), "L") && !StringUtil.equals(model.getListStatusCode(), "S");
    }

    private StockInfoAllDTO buildStockInfoAllDTO(StockBasicInfoModel model) {
        return StockInfoAllDTO
                .builder()
                .secid(model.getStockId())
                .ticker(model.getStockCode())
                .exchangecd(getSinaExchangeCode(model.getExchangeCode()))
                .pinyin(model.getStockPinyin())
                .lissectorcd(model.getListSectorCode())
                .listsector(model.getListSectorDesc())
                .transcurrcd(model.getTradeCurrencyCode())
                .secshortname(model.getStockShortName())
                .secfullname(model.getStockFullName())
                .liststatuscd(model.getListStatusCode())
                .listdate(LocalDateUtil.formatDate(model.getListDate()))
                .delistdate(LocalDateUtil.formatDate(model.getDelistDate()))
                .equtypecd(model.getStockTypeCode())
                .equtype(model.getStockTypeName())
                .excountrycd(model.getExchangeCountryCode())
                .totalshares(model.getTotalShares())
                .nonrestfloatshares(model.getNonRestFloatShares())
                .nonrestfloata(model.getNonRestFloatA())
                .officaddr(model.getOfficeAddress())
                .primeoperating(model.getMainBusinessScope())
                .enddate(LocalDateUtil.formatDate(model.getFinancialReportDate()))
                .tshequity(model.getTotalOwnersEquity())
                .build();

    }

    /**
     * 返回新浪股票交易所简码
     * sh: 上交所 XSHG
     * sz：深交所 XSHE
     */
    private String getSinaExchangeCode(String exchangeCode) {
        if (StringUtil.isEmpty(exchangeCode)) {
            return "";
        }
        if (StringUtil.equals("XSHG", exchangeCode)) {
            return "sh";
        }
        if (StringUtil.equals("XSHE", exchangeCode)) {
            return "sz";
        }
        return "";
    }


    private StockInfoSectionDTO buildStockInfoSectionDTO(StockInfoAllDTO stockInfoAllDTO) {
        return StockInfoSectionDTO
                .builder()
                .ticker(stockInfoAllDTO.getTicker())
                .exchangeCd(stockInfoAllDTO.getExchangecd())
                .lisSectorCd(stockInfoAllDTO.getLissectorcd())
                .listSector(stockInfoAllDTO.getListsector())
                .secShortName(stockInfoAllDTO.getSecshortname())
                .pinYin(stockInfoAllDTO.getPinyin())
                .listDate(stockInfoAllDTO.getListdate())
                .totalShares(stockInfoAllDTO.getTotalshares())
                .isST(isST(stockInfoAllDTO.getSecshortname()) ? 1 : 0)
                .build();
    }

    /**
     * 判断是否亏损股
     */
    private boolean isST(String shortName) {
        return shortName.startsWith("*S") || shortName.startsWith("S");
    }

}
