package com.hb.quotestock.data.controller;


import com.hb.quotestock.common.pojo.dto.ResponseMessage;
import com.hb.quotestock.common.pojo.dto.StockInfoAllDTO;
import com.hb.quotestock.common.pojo.dto.StockInfoSectionDTO;
import com.hb.quotestock.common.util.QuoteUtil;
import com.hb.quotestock.common.util.ResponseMessageUtil;
import com.hb.quotestock.data.service.StockBasicInfoService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@Api("股票相关")
@Slf4j
public class StockBasicInfoController {

    private final StockBasicInfoService stockBasicInfoService;

    public StockBasicInfoController(StockBasicInfoService stockBasicInfoService) {
        this.stockBasicInfoService = stockBasicInfoService;
    }

    /**
     * 建议使用此方法
     */
    @ApiOperation(value = "建议使用此接口--返回股票部分基本信息，减少带宽流量")
    @RequestMapping(value = "/stock/info/all", method = RequestMethod.GET)
    @SuppressWarnings("unchecked")
    public ResponseMessage<List<StockInfoSectionDTO>> getStockInfoAll() {
        List<StockInfoSectionDTO> list = stockBasicInfoService.getStockInfoSection();
        // 去除科创板
        list = list
                .stream()
                .filter(dto -> !QuoteUtil.stockIsKCB(dto.getTicker()))
                .collect(Collectors.toList());
        log.info("客户端获取股票基本信息-返回部分字段,共:{}条", list.size());
        return ResponseMessageUtil.success(list);
    }

    /**
     * 建议以后弃用 删除
     */
    @Deprecated
    @ApiOperation(value = "所有股票数据,建议每天9点钟更新,不返回科创板")
    @RequestMapping(value = "/stockInfoManager/stockBasticInfo.json", method = RequestMethod.GET)
    @SuppressWarnings("unchecked")
    public ResponseMessage<List<StockInfoAllDTO>> all() {
        List<StockInfoAllDTO> list = stockBasicInfoService.getStockBasicInfoAll();
        // 去除科创板
        list = list
                .stream()
                .filter(dto -> !QuoteUtil.stockIsKCB(dto.getTicker()))
                .collect(Collectors.toList());
        log.info("客户端获取股票基本信息，共:{}条", list.size());
        return ResponseMessageUtil.success(list);
    }

    @Deprecated
    @ApiOperation(value = "所有股票数据,建议每天9点钟更新，返回包含科创板")
    @RequestMapping(value = "/stockInfoManager/kcb/stockBasticInfo.json", method = RequestMethod.GET)
    @SuppressWarnings("unchecked")
    public ResponseMessage<List<StockInfoAllDTO>> allAndKcb() {
        List<StockInfoAllDTO> list = stockBasicInfoService.getStockBasicInfoAll();
        log.info("客户端获取股票基本信息，共:{}条", list.size());
        return ResponseMessageUtil.success(list);
    }

    @Deprecated
    @ApiOperation(value = "所有股票数据,建议每天9点钟更新,返回时间格式为yyyy-MM-dd HH:mm:ss")
    @RequestMapping(value = "/stock/stockInfoFormatTime", method = RequestMethod.GET)
    @SuppressWarnings("unchecked")
    public ResponseMessage<List<StockInfoAllDTO>> stockInfoFormatTime() {
        List<StockInfoAllDTO> list = stockBasicInfoService.getStockBasicInfoAll();
        // 去除科创板
        list = list
                .stream()
                .filter(dto -> !QuoteUtil.stockIsKCB(dto.getTicker()))
                .collect(Collectors.toList());
        log.info("客户端获取股票基本信息，共:{}条", list.size());
        return ResponseMessageUtil.success(list);
    }

    @Deprecated
    @ApiOperation(value = "所有股票数据,建议每天9点钟更新,返回时间格式为yyyy-MM-dd HH:mm:ss")
    @RequestMapping(value = "/stock/stockInfoFormatTime/kcb", method = RequestMethod.GET)
    @SuppressWarnings("unchecked")
    public ResponseMessage<List<StockInfoAllDTO>> stockInfoFormatTimeKcb() {
        List<StockInfoAllDTO> list = stockBasicInfoService.getStockBasicInfoAll();
        log.info("客户端获取股票基本信息，共:{}条", list.size());
        return ResponseMessageUtil.success(list);
    }

    @Deprecated
    @ApiOperation(value = "所有股票数据,返回部分字段,建议每天9点钟更新,返回时间格式为yyyy-MM-dd HH:mm:ss")
    @RequestMapping(value = "/stock/partFields", method = RequestMethod.GET)
    @SuppressWarnings("unchecked")
    public ResponseMessage<List<StockInfoSectionDTO>> getStockPartFields() {
        List<StockInfoSectionDTO> list = stockBasicInfoService.getStockInfoSection();
        // 去除科创板
        list = list
                .stream()
                .filter(dto -> !QuoteUtil.stockIsKCB(dto.getTicker()))
                .collect(Collectors.toList());
        log.info("客户端获取股票基本信息-返回部分字段,共:{}条", list.size());
        return ResponseMessageUtil.success(list);
    }

    @Deprecated
    @ApiOperation(value = "所有股票数据,返回部分字段,建议每天9点钟更新,带科创板,返回时间格式为yyyy-MM-dd HH:mm:ss")
    @RequestMapping(value = "/stock/partFields/kcb", method = RequestMethod.GET)
    @SuppressWarnings("unchecked")
    public ResponseMessage<List<StockInfoSectionDTO>> getStockPartFieldsKcb() {
        List<StockInfoSectionDTO> list = stockBasicInfoService.getStockInfoSection();
        log.info("客户端获取股票基本信息-返回部分字段,共:{}条", list.size());
        return ResponseMessageUtil.success(list);
    }


}
