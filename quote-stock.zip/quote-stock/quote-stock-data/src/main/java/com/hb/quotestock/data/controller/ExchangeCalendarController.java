package com.hb.quotestock.data.controller;

import com.hb.quotestock.common.pojo.dto.ExchangeCalendarDTO;
import com.hb.quotestock.common.pojo.dto.ResponseMessage;
import com.hb.quotestock.common.util.ResponseMessageUtil;
import com.hb.quotestock.data.service.ExchangeCalendarService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * 交易所日历Controller
 */
@RestController
@Api("交易所日历")
public class ExchangeCalendarController {

    private final ExchangeCalendarService exchangeCalendarService;

    @Autowired
    public ExchangeCalendarController(ExchangeCalendarService exchangeCalendarService) {
        this.exchangeCalendarService = exchangeCalendarService;
    }


    @ApiOperation(value = "获取今天到2年后今天的股票交易所日历")
    @RequestMapping(value = "/stock/calendar", method = RequestMethod.GET)
    @SuppressWarnings("unchecked")
    public ResponseMessage<List<ExchangeCalendarDTO>> calendar() {
        return ResponseMessageUtil.success(exchangeCalendarService.getNextTwoYearsCalendars());
    }

    @RequestMapping(value = "/calendar/allThisYear/allExchanges", method = RequestMethod.GET)
    @ApiOperation(value = "获取所有交易所当年整年的交易日历")
    @SuppressWarnings("unchecked")
    public ResponseMessage<List<ExchangeCalendarDTO>> getAllExchangesAllThisYear() {
        return ResponseMessageUtil.success(exchangeCalendarService.getAllCalendarsThisYear());
    }

    @RequestMapping(value = "/calendar/allThisYear/{exchangeCode}", method = RequestMethod.GET)
    @ApiOperation(value = "按交易所获取当年整年的交易日历，exchangeCode为'sh'或'sz'")
    @SuppressWarnings("unchecked")
    public ResponseMessage<List<ExchangeCalendarDTO>> getAllExchangesAllThisYearByExchangeCode(@PathVariable("exchangeCode") String exchangeCode) {
        return ResponseMessageUtil.success(exchangeCalendarService.getAllCalendarsThisYearByExchangeCode(exchangeCode));
    }


}
