package com.hb.quotestock.data.service;

import com.hb.quotestock.common.pojo.dto.ExchangeCalendarDTO;
import com.hb.quotestock.common.pojo.po.ExchangeCalendarModel;
import com.hb.quotestock.common.repository.ExchangeCalendarRepository;
import com.hb.quotestock.common.util.LocalDateUtil;
import com.hb.quotestock.common.util.StringUtil;
import com.hb.quotestock.data.cache.QueryCache;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.temporal.TemporalAdjusters;
import java.util.List;
import java.util.stream.Collectors;

/**
 * 交易所日历Service层
 */
@Slf4j
@Service
public class ExchangeCalendarService {


    private final ExchangeCalendarRepository exchangeCalendarRepository;

    @Autowired
    public ExchangeCalendarService(ExchangeCalendarRepository exchangeCalendarRepository) {
        this.exchangeCalendarRepository = exchangeCalendarRepository;
    }

    /**
     * 获取今天到2年后今天的股票交易所日历
     */
    public List<ExchangeCalendarDTO> getNextTwoYearsCalendars() {
        return QueryCache.nextTwoYearExchangeCalendar;
    }

    /**
     * 获取所有交易所当年整年的交易日历
     */
    public List<ExchangeCalendarDTO> getAllCalendarsThisYear() {
        return QueryCache.nextOneYearExchangeCalendar;
    }


    /**
     * 按交易所获取当年整年的交易日历
     */
    public List<ExchangeCalendarDTO> getAllCalendarsThisYearByExchangeCode(String exchangeCode) {
        return getAllCalendarsThisYear()
                .stream()
                .filter(dto -> StringUtil.equals(exchangeCode, dto.getExchangeCD()))
                .collect(Collectors.toList());
    }

    /**
     * 更新今天到2年后今天的数据
     */
    public void updateNextTwoYearExchangeCalendars() {
        LocalDate now = LocalDate.now();
        String beginDate = LocalDateUtil.formatDate(now);
        // 2年后的今天
        String endDate = LocalDateUtil.formatDate(now.plusYears(2));
        QueryCache.nextTwoYearExchangeCalendar = getExchangeCalendarDTOs(beginDate, endDate);
    }

    /**
     * 更新当天到1年后最后一天的数据
     */
    public void updateNextOneYearExchangeCalendars() {
        LocalDate now = LocalDate.now();
        String beginDate = LocalDateUtil.formatDate(now);
        // 明年一整年
        String endDate = LocalDateUtil.formatDate(now.plusYears(1).with(TemporalAdjusters.lastDayOfYear()));
        QueryCache.nextOneYearExchangeCalendar = getExchangeCalendarDTOs(beginDate, endDate);
    }


    private List<ExchangeCalendarDTO> getExchangeCalendarDTOs(String beginDate, String endDate) {
        List<ExchangeCalendarModel> list = exchangeCalendarRepository.findByCalendarDateBetween(beginDate, endDate);
        return list
                .stream()
                .map(model -> ExchangeCalendarDTO.builder()
                        .exchangeCD(model.getExchangeCode())
                        .calendarDate(model.getCalendarDate())
                        .isOpen(model.getIsOpen())
                        .prevTradeDate(model.getPrevTradeDate())
                        .isWeekEnd(model.getIsWeekEnd())
                        .isMonthEnd(model.getIsMonthEnd())
                        .isQuarterEnd(model.getIsQuarterEnd())
                        .isYearEnd(model.getIsYearEnd())
                        .build())
                .collect(Collectors.toList());
    }

}