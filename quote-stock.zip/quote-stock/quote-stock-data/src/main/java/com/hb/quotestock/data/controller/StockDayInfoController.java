package com.hb.quotestock.data.controller;

import com.hb.quotestock.common.constant.GlobalCodeEnum;
import com.hb.quotestock.common.pojo.dto.ResponseMessage;
import com.hb.quotestock.common.pojo.dto.StockDayInfoDTO;
import com.hb.quotestock.common.util.LocalDateUtil;
import com.hb.quotestock.common.util.ResponseMessageUtil;
import com.hb.quotestock.common.util.StringUtil;
import com.hb.quotestock.data.service.StockDayKInfoService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.time.LocalDate;

/**
 * 股票日KController
 */
@RestController
@Api("股票日K")
public class StockDayInfoController {

    private final StockDayKInfoService stockDayKInfoService;

    @Autowired
    public StockDayInfoController(StockDayKInfoService stockDayKInfoService) {
        this.stockDayKInfoService = stockDayKInfoService;
    }


    @ApiOperation(value = "根据日期查询股票信息(开、高、低、收等)")
    @RequestMapping(value = "/stock/singleDayInfo", method = RequestMethod.GET)
    @SuppressWarnings("unchecked")
    public ResponseMessage<StockDayInfoDTO> getStockDayInfo(@RequestParam @ApiParam("日期，yyyy-MM-dd格式") String date,
                                                            @RequestParam @ApiParam("股票编号，如:000001") String stockCode) {
        if (StringUtil.isEmpty(date) || StringUtil.isEmpty(stockCode)) {
            return ResponseMessageUtil.error(GlobalCodeEnum.ErrorCode.ERROR_1001);
        }
        LocalDate localDate = LocalDateUtil.parseDate(date);
        if (localDate == null) {
            return ResponseMessageUtil.error(GlobalCodeEnum.ErrorCode.ERROR_1001);
        }
        return ResponseMessageUtil.success(stockDayKInfoService.getStockDayInfoByCode(stockCode, localDate));
    }

}
