package com.hb.quotestock.data.service;

import com.hb.quotestock.common.pojo.dto.StopResumptionDTO;
import com.hb.quotestock.common.pojo.po.StockStopResumptionModel;
import com.hb.quotestock.common.repository.StockStopResumptionRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

/**
 * 股票停复牌Service
 */
@Slf4j
@Service
public class StopResumptionService {

    private final StockStopResumptionRepository stockStopResumptionRepository;

    @Autowired
    public StopResumptionService(StockStopResumptionRepository stockStopResumptionRepository) {
        this.stockStopResumptionRepository = stockStopResumptionRepository;
    }


    public List<StopResumptionDTO> getStockStopResumption(String date) {
        List<StockStopResumptionModel> list = stockStopResumptionRepository.findByStopResDateOrderByStockIdAsc(date);

        return list.stream()
                .map(model -> StopResumptionDTO
                        .builder()
                        .stockId(model.getStockId())
                        .tipsTypeCd(model.getTipsTypeCode())
                        .build())
                .collect(Collectors.toList());

    }
}
