package com.hb.quotestock.data.service;

import com.hb.quotestock.common.pojo.dto.StockDayInfoDTO;
import com.hb.quotestock.common.pojo.po.StockDayKInfoModel;
import com.hb.quotestock.common.pojo.po.StockDayKInfoPrimaryKey;
import com.hb.quotestock.common.repository.StockDayKInfoRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;

/**
 * 股票日K数据
 */
@Slf4j
@Service
public class StockDayKInfoService {

    private final StockDayKInfoRepository stockDayKInfoRepository;

    @Autowired
    public StockDayKInfoService(StockDayKInfoRepository stockDayKInfoRepository) {
        this.stockDayKInfoRepository = stockDayKInfoRepository;
    }


    /**
     * 根据日期查询股票信息
     */
    public StockDayInfoDTO getStockDayInfoByCode(String stockCode, LocalDate date) {
        StockDayKInfoPrimaryKey id = StockDayKInfoPrimaryKey
                .builder()
                .stockCode(stockCode)
                .date(date)
                .build();
        StockDayKInfoModel stockDayInfo = stockDayKInfoRepository.findById(id).orElse(null);
        if (stockDayInfo == null) {
            return null;
        }
        return StockDayInfoDTO
                .builder()
                .open(stockDayInfo.getOpen() == null ? 0 : Float.valueOf(stockDayInfo.getOpen().toString()))
                .high(stockDayInfo.getHigh() == null ? 0 : Float.valueOf(stockDayInfo.getHigh().toString()))
                .low(stockDayInfo.getLow() == null ? 0 : Float.valueOf(stockDayInfo.getLow().toString()))
                .close(stockDayInfo.getClose() == null ? 0 : Float.valueOf(stockDayInfo.getClose().toString()))
                .build();
    }

}