package com.hb.quotestock.taskcenter.schedule;

import com.hb.quotestock.taskcenter.service.ExchangeCalendarService;
import com.hb.quotestock.taskcenter.service.StockDayKInfoService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

/**
 * 日K数据定时器
 */
@Component
@Slf4j
public class StockDayKSchedule {

    private final StockDayKInfoService stockDayKInfoService;

    @Autowired
    public StockDayKSchedule(StockDayKInfoService stockDayKInfoService) {
        this.stockDayKInfoService = stockDayKInfoService;
    }

    /**
     * 更新股票日K信息
     */
    @Scheduled(cron = "0 30 16 * * ? ")
    public void updateStockDayKline() {
        log.info("每日定时从更新股票日K数据开始。。。");
        stockDayKInfoService.singleUpdate();
        log.info("每日定时从更新股票日K数据结束。。。");
    }


}
