package com.hb.quotestock.taskcenter.controller;

import com.hb.quotestock.common.pojo.dto.ResponseMessage;
import com.hb.quotestock.taskcenter.service.StockBasicInfoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;


/**
 * 股票基本数据
 */
@RestController
@RequestMapping(value = "/stock")
public class StockBasicInfoController {

    private final StockBasicInfoService stockBasicInfoService;

    @Autowired
    public StockBasicInfoController(StockBasicInfoService stockBasicInfoService) {
        this.stockBasicInfoService = stockBasicInfoService;
    }


    @RequestMapping(value = "/basic/info/update", method = RequestMethod.POST)
    public ResponseMessage updateStockBaseInfo() {
        return stockBasicInfoService.singleUpdate();
    }
}
