package com.hb.quotestock.taskcenter.service;


import com.alibaba.fastjson.JSONArray;
import com.hb.quotestock.common.config.NotifyConfig;
import com.hb.quotestock.common.pojo.dto.ResponseMessage;
import com.hb.quotestock.common.pojo.po.StockBasicInfoModel;
import com.hb.quotestock.common.repository.StockBasicInfoRepository;
import com.hb.quotestock.common.util.LocalDateUtil;
import com.hb.quotestock.common.util.NotifyForwardUtil;
import com.hb.quotestock.common.util.ResponseMessageUtil;
import com.hb.quotestock.common.util.StringUtil;
import com.hb.quotestock.taskcenter.config.TlConfig;
import com.hb.quotestock.taskcenter.pojo.bo.StockBasicInfoBO;
import com.hb.quotestock.taskcenter.pojo.tl.TlStockBasicInfo;
import com.hb.quotestock.taskcenter.pojo.tl.TlStockPinyinInfo;
import com.hb.quotestock.taskcenter.util.TlHttpApiUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.interceptor.TransactionAspectSupport;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


/**
 * 股票基本信息
 */
@Service
@Slf4j
public class StockBasicInfoService {

    private boolean stockBasicInfoUpdating;

    /**
     * 股票公告页面url
     */
    private static final String STOCK_NOTICE = "http://money.finance.sina.com.cn/corp/view/vCB_AllMemordDetail.php?stockid=";

    private final NotifyConfig notifyConfig;
    private final TlConfig tlConfig;
    private final StockBasicInfoRepository stockBasicInfoRepository;
    private final NamedParameterJdbcTemplate namedParameterJdbcTemplate;

    @Autowired
    public StockBasicInfoService(NotifyConfig notifyConfig, TlConfig tlConfig, StockBasicInfoRepository stockBasicInfoRepository, NamedParameterJdbcTemplate namedParameterJdbcTemplate) {
        this.notifyConfig = notifyConfig;
        this.tlConfig = tlConfig;
        this.stockBasicInfoRepository = stockBasicInfoRepository;
        this.namedParameterJdbcTemplate = namedParameterJdbcTemplate;
    }

    @Transactional(rollbackFor = Exception.class)
    public ResponseMessage singleUpdate() {
        if (stockBasicInfoUpdating) {
            return ResponseMessageUtil.success("正在更新，请勿重复执行此命令");
        }
        stockBasicInfoUpdating = true;
        synchronized (StockDayKInfoService.class) {
            if (!stockBasicInfoUpdating) {
                return ResponseMessageUtil.success();
            }
            doUpdateStockBasicInfo();
            stockBasicInfoUpdating = false;
        }
        return ResponseMessageUtil.success();
    }

    private void doUpdateStockBasicInfo() {
        LocalDateTime startTime = LocalDateTime.now();
        updateStockBasicInfo();
        LocalDateTime endTime = LocalDateTime.now();
        log.info("股票基本信息更新结束，耗时：{}ms", LocalDateUtil.getMillisBetween(startTime, endTime));
    }

    /**
     * 更新基本信息
     */
    private void updateStockBasicInfo() {
        String token = tlConfig.getSecret();
        String stockBasicInfoUrl = tlConfig.getStockBaseInfoUrl();
        String pinYinCodeUrl = tlConfig.getPinYinCodeUrl();
        // 通联最新股票基本数据
        String stockBody = TlHttpApiUtil.requestApi(stockBasicInfoUrl, token);
        if (StringUtil.isEmpty(stockBody)) {
            String message = "股票基本数据更新结果：\n" + "调用通联接口失败！-股票基本信息";
            NotifyForwardUtil.notify(message, notifyConfig);
            log.error("股票基本信息更新失败");
            return;
        }

        // 拼音数据
        String pinyinBody = TlHttpApiUtil.requestApi(pinYinCodeUrl, token);
        if (StringUtil.isEmpty(pinyinBody)) {
            String message = "股票基本数据更新结果：\n" + "调用通联接口失败！-股票拼音码";
            NotifyForwardUtil.notify(message, notifyConfig);
            log.error("股票拼音信息更新失败");
            return;
        }

        Map<String, String> pyMap = getPyCache(pinyinBody);
        // 数据库旧数据
        Map<String, StockBasicInfoModel> dbDataMap = getDbDataMap();

        try {
            updateLocalByRemote(dbDataMap, stockBody, pyMap);
        } catch (Exception e) {
            String message = "股票基本数据更新通知：\n" + "更新失败！";
            NotifyForwardUtil.notify(message, notifyConfig);
            log.error("股票基本信息更新失败, allStockUrl={}, pinyinUrl={}, secret={}", stockBasicInfoUrl, pinYinCodeUrl, token, e);
            // 手动回滚
            TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
        }
    }

    /**
     * 数据库中获取股票基本信息
     */
    private Map<String, StockBasicInfoModel> getDbDataMap() {
        List<StockBasicInfoModel> dbData = stockBasicInfoRepository.findAll();
        Map<String, StockBasicInfoModel> dbDataMap = new HashMap<>();
        for (StockBasicInfoModel model : dbData) {
            dbDataMap.put(model.getStockId(), model);
        }
        return dbDataMap;
    }

    /**
     * 证券编码及基本上市信息获取，同步到本地缓存 pyMap
     */
    private HashMap<String, String> getPyCache(String pinyinBody) {
        HashMap<String, String> pyMap = new HashMap<>();
        List<TlStockPinyinInfo> list = JSONArray.parseArray(pinyinBody, TlStockPinyinInfo.class);
        for (TlStockPinyinInfo tlStockListInfo : list) {
            boolean needUpdate = needUpdate(tlStockListInfo.getExchangeCD(), tlStockListInfo.getListStatusCD(), tlStockListInfo.getTicker());
            if (needUpdate) {
                pyMap.put(tlStockListInfo.getSecID(), tlStockListInfo.getCnSpell());
            }
        }
        return pyMap;
    }

    /**
     * 判断是否需要更新
     * 会导致数据库中包含已退市的股票信息不正确
     * <p>
     * 上交所：
     * - A股以600、601、603打头
     * - 科创板以688开头
     * <p>
     * 深交所：
     * - A股以00打头
     * - 中小板以002打头
     * - 创业板以30开头
     */
    private boolean needUpdate(String exchangeCD, String listStatusCD, String ticker) {

        if (ticker == null) {
            return false;
        }

        // 上交所、深交所
        boolean isXSHG = StringUtil.equals("XSHG", exchangeCD);
        boolean isXSHE = StringUtil.equals("XSHE", exchangeCD);

        // 上市
        boolean isL = StringUtil.equals("L", listStatusCD);
        // 暂停
        boolean isS = StringUtil.equals("S", listStatusCD);
        // 退市
        boolean isDE = StringUtil.equals("DE", listStatusCD);

        // 符合条件的A股股票
        boolean isCorrectA = ticker.startsWith("60") ||
                ticker.startsWith("688") ||
                ticker.startsWith("00") ||
                ticker.startsWith("30");

        return (isXSHG || isXSHE) && (isL || isS || isDE) && isCorrectA;
    }

    /**
     * 比较本地数据与远程数据，更新本地
     */
    private void updateLocalByRemote(Map<String, StockBasicInfoModel> dbDataMap, String stockBody, Map<String, String> pyMap) {

        List<TlStockBasicInfo> tlStockBasicInfoList = JSONArray.parseArray(stockBody, TlStockBasicInfo.class);

        // 需要更新的数据集合
        List<StockBasicInfoModel> needInsertOrUpdateList = new ArrayList<>();

        StringBuilder sb = new StringBuilder();

        int insertCount = 0;
        int updateCount = 0;

        List<String> s2l = new ArrayList<>();
        List<String> l2s = new ArrayList<>();
        List<String> addList = new ArrayList<>();
        List<String> toDE = new ArrayList<>();
        for (TlStockBasicInfo tlStockBasicInfo : tlStockBasicInfoList) {
            boolean needUpdate = needUpdate(tlStockBasicInfo.getExchangeCD(), tlStockBasicInfo.getListStatusCD(), tlStockBasicInfo.getTicker());
            if (!needUpdate) {
                continue;
            }
            StockBasicInfoModel tempStock = tLStockInfoConvert(tlStockBasicInfo);

            // 如果为pinyin是null赋值默认值
            String pinyin = pyMap.get(tempStock.getStockId());
            tempStock.setStockPinyin(pinyin == null ? "unknown" : pinyin);

            // 如果通联没有人民币货币
            if (StringUtil.isEmpty(tlStockBasicInfo.getTransCurrCD())) {
                tempStock.setTradeCurrencyCode("CNY");
            }

            StockBasicInfoModel dbExistTemp = dbDataMap.get(tlStockBasicInfo.getSecID());
            if (dbExistTemp == null) {
                addList.add(tempStock.getStockCode());
                insertCount++;
                needInsertOrUpdateList.add(tempStock);
                continue;
            }

            updateCount++;
            needInsertOrUpdateList.add(tempStock);

            // 判断上市状态是否改变 上市状态。L-上市；S-暂停；DE-终止上市；UN-未上市
            if (!StringUtil.equals(tempStock.getListStatusCode(), dbExistTemp.getListStatusCode())) {
                switch (tempStock.getListStatusCode()) {
                    case "L":
                        s2l.add(tempStock.getStockCode());
                        break;
                    case "S":
                        l2s.add(tempStock.getStockCode());
                        break;
                    case "DE":
                        toDE.add(tempStock.getStockCode());
                        break;
                    default:
                        break;
                }
            }
        }
        sb.append(sendStockStatusInfo(s2l, l2s, addList, toDE));

        // 批量更新
        StockBasicInfoBO.builder()
                .namedParameterJdbcTemplate(namedParameterJdbcTemplate)
                .build()
                .batchSave(needInsertOrUpdateList);

        sb.append("\n")
                .append("共更新").append(insertCount + updateCount).append("条,")
                .append("新增").append(insertCount).append("条")
                .append("修改").append(updateCount).append("条");
        String result = sb.toString();
        String message = "股票基本数据更新结果：\n" + result;
        NotifyForwardUtil.notify(message, notifyConfig);
        log.info("股票基本信息数据更新完成, " + result);
    }

    /**
     * 通联标准返回bean转为本地com.hx.stock.collect.bean.StockBaseInfo
     */
    private StockBasicInfoModel tLStockInfoConvert(TlStockBasicInfo tlStockInfo) {
        StockBasicInfoModel tempStock = new StockBasicInfoModel();
        tempStock.setStockId(tlStockInfo.getSecID());
        tempStock.setStockCode(tlStockInfo.getTicker());
        tempStock.setStockShortName(tlStockInfo.getSecShortName());
        tempStock.setStockFullName(tlStockInfo.getSecFullName());
        tempStock.setExchangeCode(tlStockInfo.getExchangeCD());
        tempStock.setExchangeCountryCode(tlStockInfo.getExCountryCD());
        tempStock.setListSectorCode(tlStockInfo.getListSectorCD());
        tempStock.setListSectorDesc(tlStockInfo.getListsector());
        tempStock.setListStatusCode(tlStockInfo.getListStatusCD());

        tempStock.setListDate(tlStockInfo.getListDate());
        tempStock.setDelistDate(tlStockInfo.getDelistDate());
        tempStock.setFinancialReportDate(tlStockInfo.getEndDate());

        tempStock.setStockTypeCode(tlStockInfo.getEquTypeCD());
        tempStock.setStockTypeName(tlStockInfo.getEquType());
        tempStock.setTotalShares(tlStockInfo.getTotalShares() == null ? 0.0d : tlStockInfo.getTotalShares());
        tempStock.setNonRestFloatShares(tlStockInfo.getNonrestFloatShares() == null ? 0.0d : tlStockInfo.getNonrestFloatShares());
        tempStock.setNonRestFloatA(tlStockInfo.getNonrestfloatA() == null ? 0.0d : tlStockInfo.getNonrestfloatA());
        tempStock.setTotalOwnersEquity(tlStockInfo.getTShEquity());
        tempStock.setTradeCurrencyCode(tlStockInfo.getTransCurrCD());
        tempStock.setOfficeAddress(tlStockInfo.getOfficeAddr());
        tempStock.setMainBusinessScope(tlStockInfo.getPrimeOperating());

        return tempStock;
    }

    /**
     * 发送消息：股票上市状态改变信息
     */
    private static String sendStockStatusInfo(List<String> s2l, List<String> l2s, List<String> addList, List<String> toDE) {
        StringBuilder sb = new StringBuilder();
        if (!addList.isEmpty()) {
            sb.append("新增的股票列表 \n");
            for (String info : addList) {
                sb.append(" - [").append(info).append("]").append("(").append(STOCK_NOTICE).append(info).append(") \n ");
            }
        }
        if (!s2l.isEmpty()) {
            if (sb.length() != 0) {
                sb.append("### ");
            }
            sb.append("暂停转上市的股票列表 \n");
            for (String info : s2l) {
                sb.append(" - [").append(info).append("]").append("(").append(STOCK_NOTICE).append(info).append(") \n ");
            }
        }
        if (!l2s.isEmpty()) {
            if (sb.length() != 0) {
                sb.append("### ");
            }
            sb.append("上市转暂停的股票列表 \n");
            for (String info : l2s) {
                sb.append(" - [").append(info).append("]").append("(").append(STOCK_NOTICE).append(info).append(") \n ");
            }
        }
        if (!toDE.isEmpty()) {
            if (sb.length() != 0) {
                sb.append("### ");
            }
            sb.append("退市的股票列表 \n");
            for (String info : toDE) {
                sb.append(" - [").append(info).append("]").append("(").append(STOCK_NOTICE).append(info).append(") \n ");
            }
        }
        if (sb.length() == 0) {
            sb.append("今日无上市状态改变的股票");
        }
        return sb.toString();
    }

}
