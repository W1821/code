package com.hb.quotestock.taskcenter.pojo.tl;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


/**
 * 交易所日历基本信息
 *
 */
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class TlExchangeCalendar {

    /**
     * 证券交易所
     */
    private String exchangeCD;

    /**
     * 日期
     */
    private String calendarDate;

    /**
     * 日期当天是否开市
     */
    private Integer isOpen;

    /**
     * 当前日期前一天交易日
     */
    private String prevTradeDate;

    /**
     * 当前日期是否当周最后交易日
     */
    private Integer isWeekEnd;

    /**
     * 当前日期是否当月最后交易日
     */
    private Integer isMonthEnd;

    /**
     * 当前日期是否当季最后交易日
     */
    private Integer isQuarterEnd;

    /**
     * 当前日期是否当年最后交易日
     */
    private Integer isYearEnd;


}
