package com.hb.quotestock.taskcenter.service;

import com.alibaba.fastjson.JSONArray;
import com.hb.quotestock.common.config.NotifyConfig;
import com.hb.quotestock.common.pojo.dto.ResponseMessage;
import com.hb.quotestock.common.pojo.po.StockStopResumptionModel;
import com.hb.quotestock.common.repository.StockStopResumptionRepository;
import com.hb.quotestock.common.util.LocalDateUtil;
import com.hb.quotestock.common.util.NotifyForwardUtil;
import com.hb.quotestock.common.util.ResponseMessageUtil;
import com.hb.quotestock.common.util.StringUtil;
import com.hb.quotestock.taskcenter.config.TlConfig;
import com.hb.quotestock.taskcenter.pojo.bo.StockStopResumptionBO;
import com.hb.quotestock.taskcenter.pojo.tl.TlStockStopResumptionInfo;
import com.hb.quotestock.taskcenter.util.TlHttpApiUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.interceptor.TransactionAspectSupport;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

/**
 * 股票停复牌Service
 */
@Slf4j
@Service
public class StockStopResumptionService {

    /**
     * 是否正在更新
     */
    private boolean stopResumptionUpdating = false;

    private final StockStopResumptionRepository stockStopResumptionRepository;
    private final NotifyConfig notifyConfig;
    private final TlConfig tlConfig;
    private final NamedParameterJdbcTemplate namedParameterJdbcTemplate;

    @Autowired
    public StockStopResumptionService(StockStopResumptionRepository stockStopResumptionRepository, NotifyConfig notifyConfig, TlConfig tlConfig, NamedParameterJdbcTemplate namedParameterJdbcTemplate) {
        this.stockStopResumptionRepository = stockStopResumptionRepository;
        this.notifyConfig = notifyConfig;
        this.tlConfig = tlConfig;
        this.namedParameterJdbcTemplate = namedParameterJdbcTemplate;
    }

    @Transactional(rollbackFor = Exception.class)
    public ResponseMessage singleUpdate() {

        if (!ExchangeCalendarService.isOpenToday) {
            log.info("今天不交易，股票停复牌数据不更新");
            return ResponseMessageUtil.success("非交易日，不需要更新");
        }

        if (stopResumptionUpdating) {
            return ResponseMessageUtil.success("正在更新，请勿重复执行此命令");
        }
        stopResumptionUpdating = true;
        synchronized (StockDayKInfoService.class) {
            if (!stopResumptionUpdating) {
                return ResponseMessageUtil.success();
            }
            doUpdateStopResumption();
            stopResumptionUpdating = false;
        }
        return ResponseMessageUtil.success();
    }

    private void doUpdateStopResumption() {
        LocalDateTime startTime = LocalDateTime.now();
        try {
            updateStopResumption();
        } catch (Exception e) {
            String message = "更新股票停复牌通知：\n" + "更新失败！";
            NotifyForwardUtil.notify(message, notifyConfig);
            log.error("更新股票停复牌失败", e);
            // 手动回滚
            TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
        }
        LocalDateTime endTime = LocalDateTime.now();
        log.info("股票停复牌更新结束，耗时：{}ms", LocalDateUtil.getMillisBetween(startTime, endTime));
    }

    /**
     * 更新停复牌
     */
    private void updateStopResumption() {

        // 调用通联接口，获取股票当日停复牌信息
        String stopResumptionBody = TlHttpApiUtil.requestApi(tlConfig.getSecTipsUrl(), tlConfig.getSecret());
        // 调用接口失败
        if (stopResumptionBody == null) {
            String message = "更新股票停复牌通知：\n" + "调用通联接口失败！";
            NotifyForwardUtil.notify(message, notifyConfig);
            return;
        }
        List<TlStockStopResumptionInfo> tlList = JSONArray.parseArray(stopResumptionBody, TlStockStopResumptionInfo.class);

        // 当前时间
        String nowDate = LocalDateUtil.formatDate(LocalDate.now());

        List<StockStopResumptionModel> beanList = tlList
                .stream()
                .map(info -> new StockStopResumptionModel(nowDate, info.getTicker(), info.getTipsDesc(), info.getTipsTypeCD()))
                .collect(Collectors.toList());

        synchronized (StockStopResumptionService.class) {
            // 删除
            stockStopResumptionRepository.deleteByStopResDate(nowDate);
            // 插入
            StockStopResumptionBO.builder()
                    .namedParameterJdbcTemplate(namedParameterJdbcTemplate)
                    .build()
                    .batchSave(beanList);
        }

        int resumptionCount = 0;
        for (StockStopResumptionModel stockStopResumption : beanList) {
            if (StringUtil.equals(stockStopResumption.getTipsTypeCode(), "R")) {
                resumptionCount++;
            }
        }

        int totalCount = beanList.size();
        String content = "共更新" + totalCount + "条：停牌" + (totalCount - resumptionCount) + "条，复牌" + resumptionCount + "条";
        String message = "更新股票今日停复牌通知：\n" + content;
        NotifyForwardUtil.notify(message, notifyConfig);

        log.info("更新沪深股票今日停复牌成功。。。" + content);
    }

    /**
     * 删除库中股票停复牌
     * 距当前超过30天的
     */
    public void deleteStopResumption() {
        String stopResDate = LocalDateUtil.formatDate(LocalDate.now().minusDays(30));
        stockStopResumptionRepository.deleteByStopResDateLessThan(stopResDate);
    }

}
