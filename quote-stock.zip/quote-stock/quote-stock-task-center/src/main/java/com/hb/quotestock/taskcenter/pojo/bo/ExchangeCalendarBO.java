package com.hb.quotestock.taskcenter.pojo.bo;

import com.hb.quotestock.common.pojo.bo.BaseBO;
import com.hb.quotestock.common.pojo.po.ExchangeCalendarModel;
import lombok.*;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSourceUtils;

import java.util.List;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@Builder
public class ExchangeCalendarBO extends BaseBO {

    private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

    /**
     * 批量操作
     */
    public void batchSave(List<ExchangeCalendarModel> list) {
        SqlParameterSource[] batch = SqlParameterSourceUtils.createBatch(list);
        namedParameterJdbcTemplate.batchUpdate(getBatchUpdateSql(), batch);
    }

    private String getBatchUpdateSql() {
        return "REPLACE INTO exchange_calendar(" +
                "exchange_code, " +
                "calendar_date, " +
                "is_open, " +
                "prev_trade_date, " +
                "is_week_end, " +
                "is_month_end, " +
                "is_quarter_end, " +
                "is_year_end " +
                ") " +
                "VALUES (" +
                ":exchangeCode, " +
                ":calendarDate, " +
                ":isOpen, " +
                ":prevTradeDate, " +
                ":isWeekEnd, " +
                ":isMonthEnd, " +
                ":isQuarterEnd, " +
                ":isYearEnd " +
                ")";
    }
}
