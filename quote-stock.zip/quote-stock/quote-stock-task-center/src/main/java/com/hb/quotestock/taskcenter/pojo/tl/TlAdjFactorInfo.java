package com.hb.quotestock.taskcenter.pojo.tl;

import com.hb.quotestock.common.pojo.dto.BaseDTO;
import lombok.*;

import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * 通联股票除权除息接口返回json格式
 */
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@Builder
public class TlAdjFactorInfo extends BaseDTO {


    /**
     * 通联编制的证券编码
     */
    private String secID;

    /**
     * 通用交易代码
     */
    private String ticker;

    /**
     * 通联编制的交易市场编码
     */
    private String exchangeCD;

    /**
     * 证券简称
     */
    private String secShortName;

    /**
     * 证券英文简称
     */
    private String secShortNameEn;

    /**
     * 除权除息日，股改对应股改后首个交易日
     */
    private LocalDate exDivDate;

    /**
     * 每股派现（税前）
     */
    private Double perCashDiv;

    /**
     * 每股送股比例
     */
    private Double perShareDivRatio;

    /**
     * 每股转增股比例
     */
    private Double perShareTransRatio;

    /**
     * 每股配股比例
     */
    private Double allotmentRatio;

    /**
     * 配股价
     */
    private Double allotmentPrice;

    /**
     * 单次前复权因子，对应一个除权除息日的权息修复比例
     */
    private Double adjFactor;

    /**
     * 累积前复权因子，发生在本次除权除息日（含）之后的前复权因子累乘。每当有新的前复权因子产生，该股票的所有累积前复权因子均会刷新
     */
    private Double accumAdjFactor;

    /**
     * 累积前复权因子起始生效日期，前复权价=对应交易日期在[endDate,exDivDate)区间的未复权价*累积前复权因子
     */
    private LocalDate endDate;

    /**
     * 最近一次更新时间
     */
    private LocalDateTime updateTime;

}
