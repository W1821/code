package com.hb.quotestock.taskcenter.pojo.bo;

import com.hb.quotestock.common.pojo.bo.BaseBO;
import com.hb.quotestock.common.pojo.po.SinaIndustryModel;
import lombok.*;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSourceUtils;

import java.util.List;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@Builder
public class SinaIndustryBO extends BaseBO {

    private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

    /**
     * 批量操作
     */
    public void batchSave(List<SinaIndustryModel> list) {
        SqlParameterSource[] batch = SqlParameterSourceUtils.createBatch(list);
        namedParameterJdbcTemplate.batchUpdate(getBatchUpdateSql(), batch);
    }


    public static String getBatchUpdateSql() {
        return "REPLACE INTO sina_industry(" +
                "sina_industry_code, " +
                "industry_stocks " +
                ") " +
                "VALUES (" +
                ":sinaIndustryCode, " +
                ":industryStocks " +
                ")";
    }
}
