package com.hb.quotestock.taskcenter;

import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

/**
 * 应用入口
 */
@SpringBootApplication
@Slf4j
@EntityScan(basePackages = {"com.hb.quotestock.common.pojo.po"})
@EnableJpaRepositories(basePackages = "com.hb.quotestock.common.repository")
@ComponentScan(basePackages = {"com.hb.quotestock"})
@EnableScheduling
@EnableTransactionManagement
public class TaskCenterApplication {

    public static void main(String[] args) {
        SpringApplication application = new SpringApplication(TaskCenterApplication.class);
        application.run(args);
    }

    @PostConstruct
    public void init() {
        log.info("应用启动中");
    }

    @PreDestroy
    public void destroy() {
        log.info("应用关闭中");
    }
}
