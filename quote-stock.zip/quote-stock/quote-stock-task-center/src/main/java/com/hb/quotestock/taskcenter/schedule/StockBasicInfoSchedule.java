package com.hb.quotestock.taskcenter.schedule;

import com.hb.quotestock.taskcenter.service.ExchangeCalendarService;
import com.hb.quotestock.taskcenter.service.StockBasicInfoService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

/**
 * 股票更新定时器
 */
@Component
@Slf4j
public class StockBasicInfoSchedule {

    private final StockBasicInfoService stockBasicInfoService;

    @Autowired
    public StockBasicInfoSchedule(StockBasicInfoService stockBasicInfoService) {
        this.stockBasicInfoService = stockBasicInfoService;
    }

    /**
     * 更新通联更新股票基础数据
     */
    @Scheduled(cron = "0 0/30 8-15 * * ? ")
    public void updateStockBaseInfo() {
        // 交易日才更新
        if (ExchangeCalendarService.isOpenToday) {
            log.info("每日定时从通联更新股票基础数据开始。。。");
            stockBasicInfoService.singleUpdate();
            log.info("每日定时从通联更新股票基础数据结束。。。");
        } else {
            log.info("今天不交易，股票基础数据不更新");
        }
    }


}
