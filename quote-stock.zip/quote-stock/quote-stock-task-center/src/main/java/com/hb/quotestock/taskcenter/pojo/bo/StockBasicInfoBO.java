package com.hb.quotestock.taskcenter.pojo.bo;

import com.hb.quotestock.common.pojo.bo.BaseBO;
import com.hb.quotestock.common.pojo.po.StockBasicInfoModel;
import lombok.*;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSourceUtils;

import java.util.List;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@Builder
public class StockBasicInfoBO extends BaseBO {

    private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

    /**
     * 批量操作
     */
    public void batchSave(List<StockBasicInfoModel> list) {
        SqlParameterSource[] batch = SqlParameterSourceUtils.createBatch(list);
        namedParameterJdbcTemplate.batchUpdate(StockBasicInfoBO.getBatchUpdateSql(), batch);
    }

    private static String getBatchUpdateSql() {
        return "REPLACE INTO stock_basic_info( " +
                "stock_id," +
                "delist_date," +
                "exchange_code," +
                "exchange_country_code," +
                "financial_report_date," +
                "list_date," +
                "list_sector_code," +
                "list_sector_desc," +
                "list_status_code," +
                "main_business_scope," +
                "non_rest_float_a," +
                "non_rest_float_shares," +
                "office_address," +
                "stock_code," +
                "stock_full_name," +
                "stock_pinyin," +
                "stock_short_name," +
                "stock_type_code," +
                "stock_type_name," +
                "total_owners_equity," +
                "total_shares," +
                "trade_currency_code" +
                ") " +
                " VALUES (" +
                ":stockId," +
                ":delistDate," +
                ":exchangeCode," +
                ":exchangeCountryCode," +
                ":financialReportDate," +
                ":listDate," +
                ":listSectorCode," +
                ":listSectorDesc," +
                ":listStatusCode," +
                ":mainBusinessScope," +
                ":nonRestFloatA," +
                ":nonRestFloatShares," +
                ":officeAddress," +
                ":stockCode," +
                ":stockFullName," +
                ":stockPinyin," +
                ":stockShortName," +
                ":stockTypeCode," +
                ":stockTypeName," +
                ":totalOwnersEquity," +
                ":totalShares," +
                ":tradeCurrencyCode" +
                ")";
    }
}
