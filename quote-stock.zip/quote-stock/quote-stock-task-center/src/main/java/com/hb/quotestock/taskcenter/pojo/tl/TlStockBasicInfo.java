package com.hb.quotestock.taskcenter.pojo.tl;

import com.hb.quotestock.common.pojo.BaseBean;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDate;

/**
 * 通联股票基本信息接口返回json格式
 */
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class TlStockBasicInfo extends BaseBean {

    /**
     * 证券ID
     */
    private String secID;

    /**
     * 交易代码
     */
    private String ticker;

    /**
     * 交易市场。例如，XSHG-上海证券交易所；XSHE-深圳证券交易所。对应getSysCode.codeTypeID=10002
     */
    private String exchangeCD;

    /**
     * 上市板块编码。例如，1-主板；2-创业板；3-中小板。对应getSysCode.codeTypeID=10016
     */
    private int ListSectorCD;

    /**
     * 上市板块
     */
    private String listsector;

    /**
     * 交易货币。例如，CNY-人民币元；USD-美元。对应getSysCode.codeTypeID=10004
     */
    private String transCurrCD;

    /**
     * 证券简称
     */
    private String secShortName;

    /**
     * 证券全称
     */
    private String secFullName;

    /**
     * 上市状态。L-上市；S-暂停；DE-终止上市；UN-未上市。对应getSysCode.codeTypeID=10005
     */
    private String listStatusCD;

    /**
     * 上市日期
     */
    private LocalDate listDate;

    /**
     * 摘牌日期
     */
    private LocalDate delistDate;

    /**
     * 股票分类编码。例如，A-A股；B-B股
     */
    private String equTypeCD;

    /**
     * 股票类别
     */
    private String equType;

    /**
     * 交易市场所属地区。例如，CHN-中国大陆；HKG-香港。对应getSysCode.codeTypeID=10002
     */
    private String exCountryCD;

    /**
     * 机构内部ID：int64
     */
    private int partyID;

    /**
     * 总股本(最新)
     */
    private Double totalShares;

    /**
     * 公司无限售流通股份合计(最新)
     */
    private Double nonrestFloatShares;

    /**
     * 无限售流通股本(最新)。如果为A股，该列为最新无限售流通A股股本数量；如果为B股，该列为最新流通B股股本数量
     */
    private Double nonrestfloatA;

    /**
     * 办公地址
     */
    private String officeAddr;

    /**
     * 主营业务范围
     */
    private String primeOperating;

    /**
     * 财务报告日期
     */
    private LocalDate endDate;

    /**
     * 所有者权益合计
     */
    private Double TShEquity;
}
