package com.hb.quotestock.taskcenter.config;

import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

/**
 * 通联配置
 */
@Configuration
@ConfigurationProperties(prefix = "tl")
@Getter
@Setter
public class TlConfig {

    /**
     * 股票基本信息
     */
    private String stockBaseInfoUrl;
    /**
     * 证券编码及基本上市信息 股票拼音信息
     */
    private String pinYinCodeUrl;
    /**
     * 交易所日历
     */
    private String exchangeCalendarUrl;
    /**
     * 沪深股票今日停复牌
     */
    private String secTipsUrl;
    /**
     * 沪深股票日K数据
     */
    private String dayKlineUrl;
    /**
     * 除权除息
     */
    private String adjFactorUrl;
    /**
     * 密钥
     */
    private String secret;

}
