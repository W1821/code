package com.hb.quotestock.taskcenter.controller;

import com.hb.quotestock.common.pojo.dto.ResponseMessage;
import com.hb.quotestock.common.util.ResponseMessageUtil;
import com.hb.quotestock.taskcenter.service.StockStopResumptionService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

/**
 * 股票停复牌相关
 */
@RestController
@RequestMapping(value = "/stock")
@Slf4j
public class StockStopResumptionController {

    private final StockStopResumptionService stockStopResumptionService;

    @Autowired
    public StockStopResumptionController(StockStopResumptionService stockStopResumptionService) {
        this.stockStopResumptionService = stockStopResumptionService;
    }

    /**
     * 手动更新股票停复牌
     */
    @RequestMapping(value = "/stop/resumption/update", method = RequestMethod.POST)
    public ResponseMessage updateStockStopResumption() {
        return stockStopResumptionService.singleUpdate();
    }

    /**
     * 手动删除股票停复牌,距当前超过30天的
     */
    @RequestMapping(value = "/stop/resumption/delete", method = RequestMethod.POST)
    public ResponseMessage deleteStockStopResumption() {
        stockStopResumptionService.deleteStopResumption();
        return ResponseMessageUtil.success("删除30天前的股票停复牌信息成功");
    }

}
