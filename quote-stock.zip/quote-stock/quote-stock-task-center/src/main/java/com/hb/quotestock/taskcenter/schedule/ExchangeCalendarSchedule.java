package com.hb.quotestock.taskcenter.schedule;

import com.hb.quotestock.taskcenter.service.ExchangeCalendarService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

/**
 * 交易所日历定时器
 */
@Component
@Slf4j
public class ExchangeCalendarSchedule {

    private final ExchangeCalendarService exchangeCalendarService;

    @Autowired
    public ExchangeCalendarSchedule(ExchangeCalendarService exchangeCalendarService) {
        this.exchangeCalendarService = exchangeCalendarService;
    }

    /**
     * 更新交易所日历
     */
    @Scheduled(cron = "0 0 0 * * ? ")
    public void updateExchangeCalendar() {
        log.info("更新交易所日历开始。。。");
        exchangeCalendarService.doUpdateExchangeCalendar();
        log.info("更新交易所日历结束。。。");
    }

    /**
     * 判断今天是否开盘
     */
    @Scheduled(cron = "0 0 1 * * ? ")
    public void isOpenToday() {
        log.info("判断今天是否开盘开始。。。");
        exchangeCalendarService.doUpdateIsOpenToday();
        log.info("判断今天是否开盘结束。。。");
    }

}
