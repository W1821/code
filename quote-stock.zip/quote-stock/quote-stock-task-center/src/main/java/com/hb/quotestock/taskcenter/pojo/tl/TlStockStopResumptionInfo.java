package com.hb.quotestock.taskcenter.pojo.tl;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * 通联股票停复牌接口返回对象
 */
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class TlStockStopResumptionInfo {

    /**
     * 股票代码
     */
    private String ticker;

    /**
     * 交易提示描述
     */
    private String tipsDesc;

    /**
     * 交易提示类型：H--停牌，R--复牌
     */
    private String tipsTypeCD;

}
