package com.hb.quotestock.taskcenter.pojo.bo;

import com.hb.quotestock.common.pojo.bo.BaseBO;
import com.hb.quotestock.common.pojo.po.StockDayKInfoModel;
import lombok.*;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSourceUtils;

import java.util.List;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@Builder
public class StockDayKInfoBO extends BaseBO {

    private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

    /**
     * 批量操作
     */
    public void batchSave(List<StockDayKInfoModel> list) {
        SqlParameterSource[] batch = SqlParameterSourceUtils.createBatch(list);
        namedParameterJdbcTemplate.batchUpdate(getBatchUpdateSql(), batch);
    }

    private  String getBatchUpdateSql() {
        return "REPLACE INTO stock_day_k_info(" +
                "stock_code, " +
                "date, " +
                "close, " +
                "high, " +
                "low, " +
                "open, " +
                "volume" +
                ") " +
                "VALUES (" +
                ":stockCode, " +
                ":date, " +
                ":close, " +
                ":high, " +
                ":low, " +
                ":open, " +
                ":volume" +
                ")";
    }
}
