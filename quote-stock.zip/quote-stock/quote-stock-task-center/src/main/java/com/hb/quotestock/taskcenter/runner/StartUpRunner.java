package com.hb.quotestock.taskcenter.runner;


import com.hb.quotestock.taskcenter.service.*;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

/**
 * 服务启动时执行
 */
@Component
@Order(value = 1)
@Slf4j
public class StartUpRunner implements ApplicationRunner {

    private final ExchangeCalendarService exchangeCalendarService;
    private final StockBasicInfoService stockBasicInfoService;
    private final SinaIndustryService sinaIndustryService;
    private final StockDayKInfoService stockDayKInfoService;
    private final StockStopResumptionService stopResumptionService;
    private final StockAdjFactorService stockAdjFactorService;

    @Autowired
    public StartUpRunner(
            ExchangeCalendarService exchangeCalendarService,
            StockBasicInfoService stockBasicInfoService,
            SinaIndustryService sinaIndustryService,
            StockDayKInfoService stockDayKInfoService,
            StockStopResumptionService stopResumptionService,
            StockAdjFactorService stockAdjFactorService) {
        this.exchangeCalendarService = exchangeCalendarService;
        this.stockBasicInfoService = stockBasicInfoService;
        this.sinaIndustryService = sinaIndustryService;
        this.stockDayKInfoService = stockDayKInfoService;
        this.stopResumptionService = stopResumptionService;
        this.stockAdjFactorService = stockAdjFactorService;
    }

    @Override
    public void run(ApplicationArguments args) {
        log.debug(">>>>>>>>>>>>>>>服务启动后执行<<<<<<<<<<<<<");

        log.info("更新通联更新股票基础数据开始。。。");
        stockBasicInfoService.singleUpdate();
        log.info("更新通联更新股票基础数据结束。。。");

        log.info("更新交易所日历开始。。。");
        exchangeCalendarService.doUpdateExchangeCalendar();
        log.info("更新交易所日历结束。。。");

        log.info("判断今天是否开盘开始。。。");
        exchangeCalendarService.doUpdateIsOpenToday();
        log.info("判断今天是否开盘结束。。。");

        log.info("更新新浪行业信息开始。。。");
        sinaIndustryService.doUpdateSinaIndustry();
        log.info("更新新浪行业信息结束。。。");

        // 交易日才更新
        log.info("每日定时从更新股票日K数据开始。。。");
        stockDayKInfoService.singleUpdate();
        log.info("每日定时从更新股票日K数据结束。。。");

        // 交易日才更新
        log.info("更新股票停复牌开始。。。");
        stopResumptionService.singleUpdate();
        log.info("更新股票停复牌结束。。。");

        log.info("更新股票除权除息开始。。。");
        stockAdjFactorService.singleUpdate();
        log.info("更新股票除权除息结束。。。");

    }

}