package com.hb.quotestock.taskcenter.schedule;

import com.hb.quotestock.taskcenter.service.ExchangeCalendarService;
import com.hb.quotestock.taskcenter.service.StockStopResumptionService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

/**
 * 停复牌定时器
 */
@Component
@Slf4j
public class StopResumptionSchedule {

    private final StockStopResumptionService stopResumptionService;

    @Autowired
    public StopResumptionSchedule(StockStopResumptionService stopResumptionService) {
        this.stopResumptionService = stopResumptionService;
    }

    /**
     * 更新股票停复牌
     */
    @Scheduled(cron = "0 15 8 * * ?")
    public void updateStockStopResumption() {
        log.info("更新股票停复牌开始。。。");
        stopResumptionService.singleUpdate();
        log.info("更新股票停复牌结束。。。");
    }

    /**
     * 删除沪深股票停复牌信息
     * 距当前超过30天的
     */
    @Scheduled(cron = "0 59 23 * * ?")
    public void deleteStopResumption() {
        log.info("删除30天前沪深股票停复牌信息开始。。。");
        stopResumptionService.deleteStopResumption();
        log.info("删除30天前沪深股票停复牌信息结束。。。");
    }

}
