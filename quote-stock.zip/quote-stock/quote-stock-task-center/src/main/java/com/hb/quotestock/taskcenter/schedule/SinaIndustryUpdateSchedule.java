package com.hb.quotestock.taskcenter.schedule;

import com.hb.quotestock.taskcenter.service.SinaIndustryService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

/**
 * 股票基本信息定时器
 */
@Component
@Slf4j
public class SinaIndustryUpdateSchedule {

    private final SinaIndustryService sinaIndustryService;

    @Autowired
    public SinaIndustryUpdateSchedule(SinaIndustryService sinaIndustryService) {
        this.sinaIndustryService = sinaIndustryService;
    }

    /**
     * 每日8点半定时更新股票基本数据,从库里拿最新数据
     */
    @Scheduled(cron = "0 0 16 * * ?")
    public void stockBaseInfoUpdate() {
        log.info("每日定时更新本机股票行业信息开始。。。");
        sinaIndustryService.doUpdateSinaIndustry();
        log.info("每日定时更新本机股票行业信息结束。。。");
    }


}