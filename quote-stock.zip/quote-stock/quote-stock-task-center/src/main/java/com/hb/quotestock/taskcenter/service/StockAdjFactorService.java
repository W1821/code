package com.hb.quotestock.taskcenter.service;

import com.alibaba.fastjson.JSONArray;
import com.hb.quotestock.common.config.NotifyConfig;
import com.hb.quotestock.common.pojo.dto.ResponseMessage;
import com.hb.quotestock.common.pojo.po.StockAdjFactorInfoTLModel;
import com.hb.quotestock.common.util.LocalDateUtil;
import com.hb.quotestock.common.util.NotifyForwardUtil;
import com.hb.quotestock.common.util.ResponseMessageUtil;
import com.hb.quotestock.taskcenter.config.TlConfig;
import com.hb.quotestock.taskcenter.pojo.bo.TlAdjFactorInfoBO;
import com.hb.quotestock.taskcenter.pojo.tl.TlAdjFactorInfo;
import com.hb.quotestock.taskcenter.util.TlHttpApiUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.interceptor.TransactionAspectSupport;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Slf4j
@Service
public class StockAdjFactorService {

    /**
     * 是否正在更新
     */
    private boolean adjFactorInfoUpdating = false;

    private final NotifyConfig notifyConfig;
    private final TlConfig tlConfig;
    private final NamedParameterJdbcTemplate namedParameterJdbcTemplate;

    public StockAdjFactorService(NotifyConfig notifyConfig, TlConfig tlConfig, NamedParameterJdbcTemplate namedParameterJdbcTemplate) {
        this.notifyConfig = notifyConfig;
        this.tlConfig = tlConfig;
        this.namedParameterJdbcTemplate = namedParameterJdbcTemplate;
    }


    @Transactional(rollbackFor = Exception.class)
    public ResponseMessage singleUpdate() {
        if (adjFactorInfoUpdating) {
            return ResponseMessageUtil.success("正在更新，请勿重复执行此命令");
        }
        adjFactorInfoUpdating = true;
        synchronized (StockDayKInfoService.class) {
            if (!adjFactorInfoUpdating) {
                return ResponseMessageUtil.success();
            }
            doUpdateAdjFactorInfoFromTL();
            adjFactorInfoUpdating = false;
        }
        return ResponseMessageUtil.success();
    }

    /**
     * 从通联获取今天的除权除息数据
     */
    private void doUpdateAdjFactorInfoFromTL() {
        LocalDateTime startTime = LocalDateTime.now();
        try {
            updateAdjFactorInfo();
        } catch (Exception e) {
            String message = "更新股票除权除息通知：\n" + "更新失败！";
            NotifyForwardUtil.notify(message, notifyConfig);
            log.error("更新股票除权除息失败", e);
            // 手动回滚
            TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
        }
        LocalDateTime endTime = LocalDateTime.now();
        log.info("更新股票除权除息结束，耗时：{}ms", LocalDateUtil.getMillisBetween(startTime, endTime));
    }

    private void updateAdjFactorInfo() {
        // 从通联获取日K信息
        String url = tlConfig.getAdjFactorUrl() + LocalDateUtil.formatDate(LocalDate.now(), LocalDateUtil.yyyyMMdd);
        String result = TlHttpApiUtil.requestApi(url, tlConfig.getSecret());
        if (result == null) {
            String message = "股票除权除息更新结果：\n" + "调用通联接口失败！";
            NotifyForwardUtil.notify(message, notifyConfig);
            log.error(message);
            return;
        }
        if ("".equals(result)) {
            String message = "股票除权除息更新结果：\n" + "今日无除权除息！";
            NotifyForwardUtil.notify(message, notifyConfig);
            log.warn(message);
            return;
        }
        List<TlAdjFactorInfo> tlList = JSONArray.parseArray(result, TlAdjFactorInfo.class);

        List<StockAdjFactorInfoTLModel> list = tlList
                .stream()
                .map(this::getStockDayInfoFromTl)
                .collect(Collectors.toList());

        // 使用批量插入数据库
        TlAdjFactorInfoBO.builder()
                .namedParameterJdbcTemplate(namedParameterJdbcTemplate)
                .build()
                .batchSave(list);

        String content = "共更新" + list.size() + "条";
        String message = "股票除权除息更新结果：\n" + content;
        NotifyForwardUtil.notify(message, notifyConfig);
        log.info("股票除权除息更新完成, {}", content);
    }

    private StockAdjFactorInfoTLModel getStockDayInfoFromTl(TlAdjFactorInfo adjFactorInfo) {
        StockAdjFactorInfoTLModel model = new StockAdjFactorInfoTLModel();
        model.setSecId(adjFactorInfo.getSecID());
        model.setTicker(adjFactorInfo.getTicker());
        model.setExchangeCode(adjFactorInfo.getExchangeCD());
        model.setSecShortName(adjFactorInfo.getSecShortName());
        model.setSecShortNameEn(adjFactorInfo.getSecShortNameEn());
        model.setExDivDate(adjFactorInfo.getExDivDate());
        model.setPerCashDiv(adjFactorInfo.getPerCashDiv());
        model.setPerShareDivRatio(adjFactorInfo.getPerShareDivRatio());
        model.setPerShareTransRatio(adjFactorInfo.getPerShareTransRatio());
        model.setAllotmentRatio(adjFactorInfo.getAllotmentRatio());
        model.setAllotmentPrice(adjFactorInfo.getAllotmentPrice());
        model.setAdjFactor(adjFactorInfo.getAdjFactor());
        model.setAccumAdjFactor(adjFactorInfo.getAccumAdjFactor());
        model.setEndDate(adjFactorInfo.getEndDate());
        model.setUpdateTime(adjFactorInfo.getUpdateTime());
        return model;
    }


}
