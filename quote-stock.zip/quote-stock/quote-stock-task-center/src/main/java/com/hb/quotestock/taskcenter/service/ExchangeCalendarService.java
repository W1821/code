package com.hb.quotestock.taskcenter.service;

import com.alibaba.fastjson.JSONArray;
import com.hb.quotestock.common.config.NotifyConfig;
import com.hb.quotestock.common.pojo.po.ExchangeCalendarModel;
import com.hb.quotestock.common.repository.ExchangeCalendarRepository;
import com.hb.quotestock.common.util.LocalDateUtil;
import com.hb.quotestock.common.util.NotifyForwardUtil;
import com.hb.quotestock.common.util.StringUtil;
import com.hb.quotestock.taskcenter.config.TlConfig;
import com.hb.quotestock.taskcenter.pojo.bo.ExchangeCalendarBO;
import com.hb.quotestock.taskcenter.pojo.tl.TlExchangeCalendar;
import com.hb.quotestock.taskcenter.util.TlHttpApiUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.interceptor.TransactionAspectSupport;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.temporal.TemporalAdjusters;
import java.util.*;
import java.util.stream.Collectors;

/**
 * 交易所日历Service层
 */
@Slf4j
@Service
public class ExchangeCalendarService {

    // 交易所是否开市
    public static Boolean isOpenToday = true;

    private final NotifyConfig notifyConfig;
    private final TlConfig tlConfig;
    private final ExchangeCalendarRepository exchangeCalendarRepository;
    private final NamedParameterJdbcTemplate namedParameterJdbcTemplate;

    @Autowired
    public ExchangeCalendarService(NotifyConfig notifyConfig, TlConfig tlConfig, ExchangeCalendarRepository exchangeCalendarRepository, NamedParameterJdbcTemplate namedParameterJdbcTemplate) {
        this.notifyConfig = notifyConfig;
        this.tlConfig = tlConfig;
        this.exchangeCalendarRepository = exchangeCalendarRepository;
        this.namedParameterJdbcTemplate = namedParameterJdbcTemplate;
    }

    /**
     * 更新交易所日历
     */
    @Transactional(rollbackFor = Exception.class)
    public void doUpdateExchangeCalendar() {
        LocalDateTime startTime = LocalDateTime.now();
        updateExchangeCalendar();
        LocalDateTime endTime = LocalDateTime.now();
        log.info("更新交易所日历结束，耗时：{}ms", LocalDateUtil.getMillisBetween(startTime, endTime));
    }


    /**
     * 更新今天是否开盘
     */
    public void doUpdateIsOpenToday() {
        isOpenToday = isOpenToday();
        log.info("Is the exchange open today?  {}", isOpenToday);
    }

    /* ================================================================================================ */

    /**
     * 更新交易所日历
     */
    private void updateExchangeCalendar() {
        // 调用通联http接口，获取最新数据
        List<TlExchangeCalendar> tlData = getExchangeCalendarFromTL();
        if (tlData == null) {
            // 调用http接口失败
            handleError();
        } else {
            List<ExchangeCalendarModel> list = tlData.stream()
                    .map(this::buildExchangeCalendarModel)
                    .collect(Collectors.toList());
            try {
                handleSuccess(list);
            } catch (Exception e) {
                String message = "更新股票交易所日历通知：\n" + "更新失败！";
                NotifyForwardUtil.notify(message, notifyConfig);
                log.error("更新股票交易所日历失败", e);
                // 手动回滚
                TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
            }
        }
    }

    /**
     * 从通联获取数据
     */
    private List<TlExchangeCalendar> getExchangeCalendarFromTL() {
        Calendar calendar = Calendar.getInstance();
        String beginDate = calendar.get(Calendar.YEAR) + "0101";
        String endDate = (calendar.get(Calendar.YEAR) + 2) + "1231";
        String url = tlConfig.getExchangeCalendarUrl() + "beginDate=" + beginDate + "&endDate=" + endDate;
        String result = TlHttpApiUtil.requestApi(url, tlConfig.getSecret());
        // 调用接口失败
        if (StringUtil.isEmpty(result)) {
            return null;
        }

        String data = result.replace("XSHG", "sh").replace("XSHE", "sz");
        return JSONArray.parseArray(data, TlExchangeCalendar.class);
    }

    /**
     * 处理错误
     */
    private void handleError() {
        String message = "更新股票交易所日历通知：\n" + "调用通联接口失败";
        NotifyForwardUtil.notify(message, notifyConfig);
        log.error("更新从当年一月一日起的交易所日历失败");
    }

    private ExchangeCalendarModel buildExchangeCalendarModel(TlExchangeCalendar tlExchangeCalendar) {
        ExchangeCalendarModel model = new ExchangeCalendarModel();
        model.setExchangeCode(tlExchangeCalendar.getExchangeCD());
        model.setCalendarDate(tlExchangeCalendar.getCalendarDate());
        model.setIsOpen(tlExchangeCalendar.getIsOpen());
        model.setPrevTradeDate(tlExchangeCalendar.getPrevTradeDate());
        model.setIsWeekEnd(tlExchangeCalendar.getIsWeekEnd());
        model.setIsMonthEnd(tlExchangeCalendar.getIsMonthEnd());
        model.setIsQuarterEnd(tlExchangeCalendar.getIsQuarterEnd());
        model.setIsYearEnd(tlExchangeCalendar.getIsYearEnd());
        return model;
    }

    /**
     * 调用接口成功
     */
    private void handleSuccess(List<ExchangeCalendarModel> tlData) {
        // 数据库旧数据
        Map<String, ExchangeCalendarModel> dbDataMap = getDbDataMap();

        StringBuilder sb = new StringBuilder();
        int insertCount = 0;
        int updateCount = 0;
        if (dbDataMap.isEmpty()) {
            insertCount = tlData.size();
        } else {
            for (ExchangeCalendarModel exchangeCalendar : tlData) {
                ExchangeCalendarModel dbExistTemp = dbDataMap.get(exchangeCalendar.getExchangeCode() + exchangeCalendar.getCalendarDate());
                if (dbExistTemp == null) {
                    insertCount++;
                } else {
                    updateCount++;
                }
            }
        }
        if (!tlData.isEmpty()) {
            // 批量插入或更新
            ExchangeCalendarBO.builder()
                    .namedParameterJdbcTemplate(namedParameterJdbcTemplate)
                    .build()
                    .batchSave(tlData);
        }
        sb.append("共更新").append(insertCount + updateCount).append("条,")
                .append("新增").append(insertCount).append("条,")
                .append("修改").append(updateCount).append("条");
        String result = sb.toString();
        String message = "更新股票交易所日历结果：\n" + result;
        NotifyForwardUtil.notify(message, notifyConfig);
        log.info("更新股票交易所日历完成, {}", result);
    }

    /**
     * 从数据库中获取数据
     */
    private Map<String, ExchangeCalendarModel> getDbDataMap() {
        List<ExchangeCalendarModel> dbData = getExchangeCalendar();

        Map<String, ExchangeCalendarModel> dbDataMap = new HashMap<>();
        for (ExchangeCalendarModel exchangeCalendar : dbData) {
            dbDataMap.put(exchangeCalendar.getExchangeCode() + exchangeCalendar.getCalendarDate(), exchangeCalendar);
        }
        return dbDataMap;
    }

    /**
     * 获取当天到2年后的数据
     */
    private List<ExchangeCalendarModel> getExchangeCalendar() {
        LocalDate now = LocalDate.now();
        String beginDate = LocalDateUtil.formatDate(now.with(TemporalAdjusters.firstDayOfYear()));
        // 2年后的最后一天
        String endDate = LocalDateUtil.formatDate(now.plusYears(2).with(TemporalAdjusters.lastDayOfYear()));
        return exchangeCalendarRepository.findByCalendarDateBetween(beginDate, endDate);
    }

    private boolean isOpenToday() {
        List<ExchangeCalendarModel> exchangeCalendars = findByCalendarDate();
        for (ExchangeCalendarModel ec : exchangeCalendars) {
            if (ec.getIsOpen() != null && ec.getIsOpen() == 1) {
                return true;
            }
        }
        return false;
    }

    /**
     * 获取今天的交易所日历
     */
    private List<ExchangeCalendarModel> findByCalendarDate() {
        String calendarDate = LocalDateUtil.formatDate(LocalDate.now());
        if (calendarDate == null) {
            return new ArrayList<>();
        }
        return exchangeCalendarRepository.findByCalendarDate(calendarDate);
    }

}