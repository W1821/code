package com.hb.quotestock.taskcenter.pojo.bo;

import com.hb.quotestock.common.pojo.po.StockAdjFactorInfoTLModel;
import lombok.*;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSourceUtils;

import java.util.List;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@Builder
public class TlAdjFactorInfoBO {

    private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

    /**
     * 批量操作
     */
    public void batchSave(List<StockAdjFactorInfoTLModel> list) {
        SqlParameterSource[] batch = SqlParameterSourceUtils.createBatch(list);
        namedParameterJdbcTemplate.batchUpdate(getBatchUpdateSql(), batch);
    }

    private String getBatchUpdateSql() {
        return "REPLACE INTO stock_adj_factor_info_tl(" +
                "sec_id, " +
                "ticker, " +
                "exchange_code, " +
                "sec_short_name, " +
                "sec_short_name_en, " +
                "ex_div_date, " +
                "per_cash_div, " +
                "per_share_div_ratio, " +
                "per_share_trans_ratio, " +
                "allotment_ratio, " +
                "allotment_price, " +
                "adj_factor, " +
                "accum_adj_factor, " +
                "end_date, " +
                "update_time " +
                ") " +
                "VALUES (" +
                ":secId, " +
                ":ticker, " +
                ":exchangeCode, " +
                ":secShortName, " +
                ":secShortNameEn, " +
                ":exDivDate, " +
                ":perCashDiv, " +
                ":perShareDivRatio, " +
                ":perShareTransRatio, " +
                ":allotmentRatio, " +
                ":allotmentPrice, " +
                ":adjFactor, " +
                ":accumAdjFactor, " +
                ":endDate, " +
                ":updateTime " +
                ")";
    }

}
