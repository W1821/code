package com.hb.quotestock.taskcenter.controller;

import com.hb.quotestock.common.pojo.dto.ResponseMessage;
import com.hb.quotestock.taskcenter.service.StockDayKInfoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;


/**
 * 股票日K信息
 */
@RestController
@RequestMapping(value = "/stock")
public class StockDayKlineController {

    private final StockDayKInfoService stockDayKInfoService;

    @Autowired
    public StockDayKlineController(StockDayKInfoService stockDayKInfoService) {
        this.stockDayKInfoService = stockDayKInfoService;
    }


    /**
     * 手动更新股票日K信息
     */
    @RequestMapping(value = "/day/kline/update", method = RequestMethod.POST)
    public ResponseMessage updateStockDayInfo() {
        return stockDayKInfoService.singleUpdate();
    }
}
