package com.hb.quotestock.taskcenter.pojo.tl;

import com.hb.quotestock.common.pojo.BaseBean;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.Date;

/**
 * 通联股票拼音码接口返回json格式
 */
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class TlStockPinyinInfo extends BaseBean {

    /**
     * 证券ID
     */
    private String secID;

    /**
     * 交易代码
     */
    private String ticker;

    /**
     * 证券简称
     */
    private String secShortName;

    /**
     * 证券简称拼音
     */
    private String assetClass;

    /**
     * 交易市场
     */
    private String exchangeCD;

    /**
     * 证券类型
     */
    private String cnSpell;

    /**
     * 上市状态。L-上市；S-暂停；DE-终止上市；UN-未上市。对应getSysCode.codeTypeID=10005
     */
    private String listStatusCD;

    /**
     * 上市日期
     */
    private Date listDate;

    /**
     * 交易货币
     */
    private String transCurrCD;

    /**
     * ISIN编码
     */
    private String ISIN;

    /**
     * 机构ID
     */
    private long partyID;
}
