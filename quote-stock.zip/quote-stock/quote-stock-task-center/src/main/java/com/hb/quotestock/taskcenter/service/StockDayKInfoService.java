package com.hb.quotestock.taskcenter.service;

import com.alibaba.fastjson.JSONArray;
import com.hb.quotestock.common.config.NotifyConfig;
import com.hb.quotestock.common.pojo.dto.ResponseMessage;
import com.hb.quotestock.common.pojo.po.StockDayKInfoModel;
import com.hb.quotestock.common.util.LocalDateUtil;
import com.hb.quotestock.common.util.NotifyForwardUtil;
import com.hb.quotestock.common.util.ResponseMessageUtil;
import com.hb.quotestock.common.util.StringUtil;
import com.hb.quotestock.taskcenter.config.TlConfig;
import com.hb.quotestock.taskcenter.pojo.bo.StockDayKInfoBO;
import com.hb.quotestock.taskcenter.pojo.tl.TlStockDayKInfo;
import com.hb.quotestock.taskcenter.util.TlHttpApiUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.interceptor.TransactionAspectSupport;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

/**
 * 股票日K更新
 */
@Slf4j
@Service
public class StockDayKInfoService {

    /**
     * 是否正在更新
     */
    private boolean dayKInfoUpdating = false;

    private final TlConfig tlConfig;
    private final NotifyConfig notifyConfig;
    private final NamedParameterJdbcTemplate namedParameterJdbcTemplate;

    @Autowired
    public StockDayKInfoService(TlConfig tlConfig, NotifyConfig notifyConfig, NamedParameterJdbcTemplate namedParameterJdbcTemplate) {
        this.tlConfig = tlConfig;
        this.notifyConfig = notifyConfig;
        this.namedParameterJdbcTemplate = namedParameterJdbcTemplate;
    }

    @Transactional(rollbackFor = Exception.class)
    public ResponseMessage singleUpdate() {

        if (!ExchangeCalendarService.isOpenToday) {
            log.info("今天不交易，股票日K数据不更新");
            return ResponseMessageUtil.success("非交易日，不需要更新");
        }

        if (dayKInfoUpdating) {
            return ResponseMessageUtil.success("正在更新，请勿重复执行此命令");
        }
        dayKInfoUpdating = true;
        synchronized (StockDayKInfoService.class) {
            if (!dayKInfoUpdating) {
                return ResponseMessageUtil.success();
            }
            doUpdateStockDayKInfo();
            dayKInfoUpdating = false;
        }
        return ResponseMessageUtil.success();
    }

    private void doUpdateStockDayKInfo() {
        LocalDateTime startTime = LocalDateTime.now();
        try {
            updateStockDayKInfo();
        } catch (Exception e) {
            String message = "股票日K数据更新通知：\n" + "更新失败！";
            NotifyForwardUtil.notify(message, notifyConfig);
            log.error("股票日K数据更新失败", e);
            // 手动回滚
            TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
        }
        LocalDateTime endTime = LocalDateTime.now();
        log.info("股票日K数据更新结束，耗时：{}ms", LocalDateUtil.getMillisBetween(startTime, endTime));
    }

    private void updateStockDayKInfo() {
        // 从通联获取日K信息
        String url = tlConfig.getDayKlineUrl() + LocalDateUtil.formatDate(LocalDate.now(), LocalDateUtil.yyyyMMdd);
        String result = TlHttpApiUtil.requestApi(url, tlConfig.getSecret());
        if (StringUtil.isEmpty(result)) {
            String message = "股票日K数据更新结果：\n" + "调用通联接口失败！";
            NotifyForwardUtil.notify(message, notifyConfig);
            log.error(message);
            return;
        }
        List<TlStockDayKInfo> tlList = JSONArray.parseArray(result, TlStockDayKInfo.class);

        List<StockDayKInfoModel> list = tlList.stream().map(this::getStockDayInfoFromTl).collect(Collectors.toList());

        // 使用批量插入数据库
        StockDayKInfoBO.builder()
                .namedParameterJdbcTemplate(namedParameterJdbcTemplate)
                .build()
                .batchSave(list);

        String content = "共更新" + list.size() + "条";
        String message = "股票日K数据更新结果：\n" + content;
        NotifyForwardUtil.notify(message, notifyConfig);
        log.info("股票日K数据更新完成, {}", content);
    }

    private StockDayKInfoModel getStockDayInfoFromTl(TlStockDayKInfo tlStockDayKInfo) {
        StockDayKInfoModel stockDayInfo = new StockDayKInfoModel();
        stockDayInfo.setStockCode(tlStockDayKInfo.getTicker());
        stockDayInfo.setDate(tlStockDayKInfo.getTradeDate());
        stockDayInfo.setOpen(tlStockDayKInfo.getOpenPrice());
        stockDayInfo.setHigh(tlStockDayKInfo.getHighestPrice());
        stockDayInfo.setLow(tlStockDayKInfo.getLowestPrice());
        stockDayInfo.setClose(tlStockDayKInfo.getClosePrice());
        stockDayInfo.setVolume(tlStockDayKInfo.getTurnoverVol());
        return stockDayInfo;
    }

}
