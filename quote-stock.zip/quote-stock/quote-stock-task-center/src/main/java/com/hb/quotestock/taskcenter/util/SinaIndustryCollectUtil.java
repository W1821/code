package com.hb.quotestock.taskcenter.util;

import lombok.extern.slf4j.Slf4j;
import okhttp3.*;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

/**
 * 新浪行情采集网络请求
 */
@Slf4j
public class SinaIndustryCollectUtil {

    private static final OkHttpClient COLLECTOR_CLIENT;

    /*
     * 初始化OkHttpClient线程池
     */
    static {
        ConnectionPool pool = new ConnectionPool(10, 3, TimeUnit.MINUTES);
        COLLECTOR_CLIENT = new OkHttpClient.Builder()
                .connectTimeout(3, TimeUnit.SECONDS)
                .readTimeout(3, TimeUnit.SECONDS)
                .connectionPool(pool)
                .followRedirects(false)
                .retryOnConnectionFailure(true)
                .build();
    }

    /**
     * 同步方式去获取网络请求返回
     *
     * @param url 请求地址
     */
    public static String collect(String url) {
        ResponseBody responseBody = get(url);
        if (responseBody == null) {
            return null;
        }
        try {
            return responseBody.string();
        } catch (IOException ignored) {
            return null;
        }
    }

    /**
     * 发送请求
     */
    private static ResponseBody get(String url) {
        try {
            Request request = new Request.Builder().url(url).build();
            Response response = COLLECTOR_CLIENT.newCall(request).execute();
            if (!response.isSuccessful()) {
                log.error("新浪行业采集失败, url={}, code={}", url, response.code());
                return null;
            }
            return response.body();
        } catch (Exception e) {
            log.error("新浪行业采集失败, url={}", url, e);
        }
        return null;
    }

}
