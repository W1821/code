package com.hb.quotestock.taskcenter.schedule;

import com.hb.quotestock.taskcenter.service.StockAdjFactorService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

/**
 * 股票除权除息数据定时器
 */
@Component
@Slf4j
public class StockAdjFactorInfoSchedule {

    private final StockAdjFactorService stockAdjFactorService;

    @Autowired
    public StockAdjFactorInfoSchedule(StockAdjFactorService stockAdjFactorService) {
        this.stockAdjFactorService = stockAdjFactorService;
    }

    /**
     * 更新股票日K信息
     */
    @Scheduled(cron = "0 4 9 * * ? ")
    public void updateStockDayKline() {
        log.info("更新股票除权除息开始。。。");
        stockAdjFactorService.singleUpdate();
        log.info("更新股票除权除息结束。。。");
    }


}
