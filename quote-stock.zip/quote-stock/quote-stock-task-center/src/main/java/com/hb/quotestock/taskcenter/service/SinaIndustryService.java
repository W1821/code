package com.hb.quotestock.taskcenter.service;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.hb.quotestock.common.config.NotifyConfig;
import com.hb.quotestock.common.pojo.po.SinaIndustryModel;
import com.hb.quotestock.common.util.FastJsonUtil;
import com.hb.quotestock.common.util.LocalDateUtil;
import com.hb.quotestock.common.util.NotifyForwardUtil;
import com.hb.quotestock.common.util.StringUtil;
import com.hb.quotestock.taskcenter.pojo.bo.SinaIndustryBO;
import com.hb.quotestock.taskcenter.util.SinaIndustryCollectUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.interceptor.TransactionAspectSupport;

import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

@Service
@Slf4j
public class SinaIndustryService {

    /**
     * 行业行情
     */
    private static final String HYHQ_URL = "http://vip.stock.finance.sina.com.cn/q/view/newSinaHy.php";
    /**
     * 行业分类股票数量
     */
    private static final String HY_COUNT_URL = "http://vip.stock.finance.sina.com.cn/quotes_service/api/json_v2.php/Market_Center.getHQNodeStockCount?node=${type}";
    /**
     * 行业分类详细股票信息
     */
    private static final String HYGP_URL = "http://vip.stock.finance.sina.com.cn/quotes_service/api/json_v2.php/Market_Center.getHQNodeData?page=${page}&num=80&sort=symbol&asc=1&node=${type}&symbol=&_s_r_a=init";

    private final NotifyConfig notifyConfig;
    private final NamedParameterJdbcTemplate namedParameterJdbcTemplate;

    @Autowired
    public SinaIndustryService(NotifyConfig notifyConfig, NamedParameterJdbcTemplate namedParameterJdbcTemplate) {
        this.notifyConfig = notifyConfig;
        this.namedParameterJdbcTemplate = namedParameterJdbcTemplate;
    }

    /**
     * 更新新浪行业信息
     */
    @Transactional(rollbackFor = Exception.class)
    public void doUpdateSinaIndustry() {
        LocalDateTime startTime = LocalDateTime.now();
        try {
            updateSinaIndustry();
        } catch (Exception e) {
            String message = "更新新浪行业信息通知：\n" + "更新失败！";
            NotifyForwardUtil.notify(message, notifyConfig);
            log.error("更新新浪行业信息失败", e);
            // 手动回滚
            TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
        }
        LocalDateTime endTime = LocalDateTime.now();
        log.info("更新新浪行业信息结束！耗时：{}ms", LocalDateUtil.getMillisBetween(startTime, endTime));
    }

    private void updateSinaIndustry() {
        // 获取新浪行业分类
        Map<String, String> typeMap = getSinaIndustryTypeMap();
        if (typeMap == null) {
            return;
        }

        // 更新新浪行业股票
        Map<String, List<String>> stockMap = typeMap.keySet().stream().collect(Collectors.toMap(k -> k, this::getHangYeAllStockList));

        // 保存到数据库
        List<SinaIndustryModel> list = stockMap.entrySet().stream()
                .map(e -> new SinaIndustryModel(e.getKey(), String.join(",", e.getValue())))
                .collect(Collectors.toList());
        SinaIndustryBO.builder()
                .namedParameterJdbcTemplate(namedParameterJdbcTemplate)
                .build()
                .batchSave(list);
        String message = "更新新浪行业信息成功结果：\n" + "共更新" + list.size() + "条";
        NotifyForwardUtil.notify(message, notifyConfig);

    }

    /**
     * 采集新浪行业分类
     */
    private Map<String, String> getSinaIndustryTypeMap() {
        String result = SinaIndustryCollectUtil.collect(HYHQ_URL);
        if (StringUtil.isEmpty(result)) {
            return null;
        }
        String json = result.substring(37);
        JSONObject jsonObject = FastJsonUtil.toJsonObject(json);
        Map<String, String> typeMap = jsonObject.values()
                .stream()
                .map(o -> StringUtil.splitComma((String) o))
                .filter(Objects::nonNull)
                .collect(Collectors.toMap(arr -> arr[0], arr -> arr[1]));
        log.info("获取浪行业分类成功，共有{}个分类", typeMap.size());
        return typeMap;
    }

    private List<String> getHangYeAllStockList(String key) {
        List<String> all = new ArrayList<>();
        // 页数
        int pages = getHyPages(key);
        for (int i = 1; i <= pages; i++) {
            List<String> list = getPageStockList(key, i);
            if (list == null) {
                break;
            }
            all.addAll(list);
        }
        log.info("更新一个新浪行业分类股票集合信息成功，分类标识={}，股票详细={}", key, all);
        return all;
    }

    private int getHyPages(String type) {
        String url = StringUtil.replaceUrlParam(HY_COUNT_URL, "type", type);
        /* result 是这样的格式 (new String("245")) */
        String result = SinaIndustryCollectUtil.collect(url);
        if (StringUtil.isEmpty(result)) {
            return 0;
        }
        // 此分类下的股票数量
        int rows = Integer.valueOf(result.substring(13, result.length() - 3));
        int pageSize = 80;
        return rows % pageSize == 0 ? rows / pageSize : rows / pageSize + 1;
    }


    private List<String> getPageStockList(String type, int page) {
        String url = StringUtil.replaceUrlParam(HYGP_URL, "type", type);
        url = StringUtil.replaceUrlParam(url, "page", "" + page);
        String result = SinaIndustryCollectUtil.collect(url);
        if (StringUtil.isEmpty(result)) {
            return null;
        }
        List<HashMap> list = JSONArray.parseArray(result, HashMap.class);
        return list.stream().map(e -> (String) e.get("symbol")).collect(Collectors.toList());
    }
}
