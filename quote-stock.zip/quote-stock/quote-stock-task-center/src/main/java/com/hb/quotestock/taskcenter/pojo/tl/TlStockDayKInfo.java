package com.hb.quotestock.taskcenter.pojo.tl;

import com.hb.quotestock.common.pojo.BaseBean;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDate;

/**
 * 通联股票日K接口返回对象
 */
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class TlStockDayKInfo extends BaseBean {
    /**
     * 交易代码
     */
    private String ticker;

    /**
     * 交易日期
     */
    private LocalDate tradeDate;

    /**
     * 今开盘
     */
    private Double openPrice;

    /**
     * 最高价
     */
    private Double highestPrice;

    /**
     * 最低价
     */
    private Double lowestPrice;

    /**
     * 今收盘
     */
    private Double closePrice;

    /**
     * 成交量
     */
    private Long turnoverVol;


}
