package com.hb.quotestock.app.config;

import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

/**
 * 连接配置
 */
@Getter
@Setter
@Component
@ConfigurationProperties(prefix = "ws.connection")
public class AppWSConnectionConfig {

    /**
     * websocket 连接key
     */
    private String appKey;

    /**
     * 秘钥
     */
    private String appSecret;

    /**
     * 验证加盐
     */
    private String salt;


}
