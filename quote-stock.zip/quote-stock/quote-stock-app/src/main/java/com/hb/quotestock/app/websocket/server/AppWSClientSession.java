package com.hb.quotestock.app.websocket.server;

import com.hb.quotestock.common.pojo.quote.QuoteSubscribeInfo;
import com.hb.quotestock.common.websocket.server.WSClientSession;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.socket.WebSocketSession;

/**
 * websocket建立连接保存对象
 */
@Slf4j
public class AppWSClientSession extends WSClientSession {

    /**
     * 构造方法
     */
    AppWSClientSession(WebSocketSession session) {
        // App端因为不需要推送逐笔，工作队列可以设置小点
        super(session, 10000);
        // 初始化订阅信息，默认不推送股票、指数、新浪行业
        this.quoteSubscribeInfo = new QuoteSubscribeInfo();
    }

}
