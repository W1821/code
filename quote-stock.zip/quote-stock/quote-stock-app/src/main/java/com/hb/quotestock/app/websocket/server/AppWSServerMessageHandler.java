package com.hb.quotestock.app.websocket.server;

import com.hb.quotestock.common.websocket.server.WSMessageHandler;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.web.socket.WebSocketSession;


@Component
@Slf4j
public class AppWSServerMessageHandler extends WSMessageHandler {

    /**
     * 新连接打开
     */
    @Override
    public void afterConnectionEstablished(WebSocketSession session) {
        // 默认不推送股票、指数、新浪行业，所以不推送缓存行情
        AppWSClientSession clientSession = new AppWSClientSession(session);
        putWSClientSessionToManager(clientSession);
        log.info("websocket connected, id={}, ip={}", session.getId(), clientSession.getIp());
    }

}
