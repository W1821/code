package com.hb.quotestock.app.runner;

import com.hb.quotestock.app.websocket.client.AppWSClientEndpoint;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.stereotype.Component;

/**
 * 连接websocket
 */
@Component
@Slf4j
public class WebSocketClientRunner implements ApplicationRunner {

    private final AppWSClientEndpoint clientEndpoint;

    @Autowired
    public WebSocketClientRunner(AppWSClientEndpoint clientEndpoint) {
        this.clientEndpoint = clientEndpoint;
    }

    @Override
    public void run(ApplicationArguments args) {
        clientEndpoint.connectToServer();
    }

}
