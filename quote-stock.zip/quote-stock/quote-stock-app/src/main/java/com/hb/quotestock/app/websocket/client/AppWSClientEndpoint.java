package com.hb.quotestock.app.websocket.client;

import com.hb.quotestock.app.config.AppWSConnectionConfig;
import com.hb.quotestock.common.config.WebSocketClientConfig;
import com.hb.quotestock.common.constant.WSAttributeConstant;
import com.hb.quotestock.common.util.MD5Util;
import com.hb.quotestock.common.websocket.client.WSClientEndpoint;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * web socket 客户端
 */
@Component
@Slf4j
public class AppWSClientEndpoint extends WSClientEndpoint {

    @Autowired
    public AppWSClientEndpoint(
            AppWSClientMessageHandler appWSClientMessageHandler,
            WebSocketClientConfig webSocketClientConfig,
            AppWSConnectionConfig appWSConnectionConfig) {
        super(appWSClientMessageHandler, webSocketClientConfig);
        // 增加连接参数。
        addConnectParams(webSocketClientConfig, appWSConnectionConfig);
    }


    /**
     * TODO 执行订阅操作, 股票、指数、新浪行情默认推送，不需要订阅
     * TODO app 不支持推送，这里不需要处理
     * TODO 如有需要，可以在此处添加订阅代码
     */
    protected void afterOpen() {

    }

    /**
     * 增加连接参数
     */
    private void addConnectParams(WebSocketClientConfig webSocketClientConfig, AppWSConnectionConfig appWSConnectionConfig) {
        // 增加连接参数
        String appKey = appWSConnectionConfig.getAppKey();
        String salt = appWSConnectionConfig.getSalt();
        String timestamp = String.valueOf(System.currentTimeMillis());
        String appSecret = appWSConnectionConfig.getAppSecret();
        // 计算签名
        String sign = MD5Util.getMD5(appKey + salt + timestamp + appSecret);

        String serverUrl = webSocketClientConfig.getServerUrl() + "?" +
                WSAttributeConstant.APP_ID + "=" + appKey + "&" +
                WSAttributeConstant.TYPE + "=" + salt + "&" +
                WSAttributeConstant.TIMESTAMP + "=" + timestamp + "&" +
                WSAttributeConstant.SIGN + "=" + sign + "&" +
                WSAttributeConstant.CLIENT_TYPE + "=" + "app";
        webSocketClientConfig.setServerUrl(serverUrl);
    }


}
