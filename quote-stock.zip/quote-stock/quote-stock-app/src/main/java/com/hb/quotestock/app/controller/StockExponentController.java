package com.hb.quotestock.app.controller;

import com.hb.quotestock.common.cache.QuoteCache;
import com.hb.quotestock.common.constant.GlobalCodeEnum;
import com.hb.quotestock.common.pojo.dto.ResponseMessage;
import com.hb.quotestock.common.pojo.quote.ExponentQuote;
import com.hb.quotestock.common.pojo.quote.QuoteWrapper;
import com.hb.quotestock.common.util.ResponseMessageUtil;
import com.hb.quotestock.common.util.StringUtil;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

@RestController
@Slf4j
@Api("股票指数相关")
public class StockExponentController {

    @ApiOperation(value = "")
    @RequestMapping(value = {"/getExponentList", "/exponent/all"}, method = RequestMethod.GET)
    @SuppressWarnings("unchecked")
    public ResponseMessage<List<ExponentQuote>> getExponentAll() {
        List<ExponentQuote> list = QuoteCache.EXPONENT.values()
                .stream()
                .map(QuoteWrapper::getQuoteData)
                .collect(Collectors.toList());
        return ResponseMessageUtil.success(list);
    }

    @ApiOperation(value = "根据股票指数代码查询指数信息")
    @RequestMapping(value = {"/exponent", "/exponent/find"}, method = RequestMethod.GET)
    @SuppressWarnings("unchecked")
    public ResponseMessage<List<ExponentQuote>> findExponentByCodes(@RequestParam("sds") @ApiParam(value = "指数代码，多个使用逗号分隔", example = "000001") String sds) {
        String[] stockCodes = StringUtil.splitComma(sds);
        if (stockCodes == null) {
            return ResponseMessageUtil.error(GlobalCodeEnum.ErrorCode.ERROR_1001);
        }
        List<ExponentQuote> list = Arrays.stream(stockCodes)
                .map(QuoteCache.EXPONENT::get)
                .filter(Objects::nonNull)
                .map(QuoteWrapper::getQuoteData)
                .filter(Objects::nonNull)
                .collect(Collectors.toList());
        return ResponseMessageUtil.success(list);
    }


}
