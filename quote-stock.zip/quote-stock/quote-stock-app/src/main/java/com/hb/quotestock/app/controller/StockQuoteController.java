package com.hb.quotestock.app.controller;

import com.hb.quotestock.common.cache.QuoteCache;
import com.hb.quotestock.common.constant.GlobalCodeEnum;
import com.hb.quotestock.common.pojo.dto.ResponseMessage;
import com.hb.quotestock.common.pojo.quote.QuoteWrapper;
import com.hb.quotestock.common.pojo.quote.StockQuote;
import com.hb.quotestock.common.util.ResponseMessageUtil;
import com.hb.quotestock.common.util.StringUtil;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.*;
import java.util.stream.Collectors;

@RestController
@Slf4j
@Api("股票行情相关")
public class StockQuoteController {

    @ApiOperation(value = "获取股票的所有行情信息")
    @RequestMapping(value = {"/quote", "/quote/stock"}, method = RequestMethod.GET)
    @SuppressWarnings("unchecked")
    public ResponseMessage<List<StockQuote>> quote(@RequestParam("sds") @ApiParam(value = "股票代码，多个使用逗号分隔", example = "000001") String sds) {
        String[] stockCodes = StringUtil.splitComma(sds);
        if (stockCodes == null) {
            return ResponseMessageUtil.error(GlobalCodeEnum.ErrorCode.ERROR_1001);
        }
        List<StockQuote> list = Arrays.stream(stockCodes)
                .map(QuoteCache.STOCK::get)
                .filter(Objects::nonNull)
                .map(QuoteWrapper::getQuoteData)
                .filter(Objects::nonNull)
                .collect(Collectors.toList());
        return ResponseMessageUtil.success(list);
    }

    @ApiOperation(value = "查询股票的涨跌平家数")
    @RequestMapping(value = {"/updown", "/quote/updown"}, method = RequestMethod.GET)
    public ResponseMessage quote() {
        Map<String, Long> map = new HashMap<>();
        List<StockQuote> stockList = QuoteCache.STOCK.values()
                .stream()
                .map(QuoteWrapper::getQuoteData)
                .collect(Collectors.toList());

        long up = stockList.stream().filter(e -> e.getCg() > 0).count();
        long down = stockList.stream().filter(e -> e.getCg() < 0).count();
        long flat = stockList.stream().filter(e -> e.getCg() == 0).count();
        map.put("up", up);
        map.put("down", down);
        map.put("flat", flat);
        return ResponseMessageUtil.success(map);
    }


}
