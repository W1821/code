package com.hb.quotestock.app;

import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.web.socket.config.annotation.EnableWebSocket;

import javax.annotation.PostConstruct;

@SpringBootApplication
@Slf4j
@EntityScan(basePackages = {"com.hb.quotestock.common.pojo.po"})
@ComponentScan(basePackages = {"com.hb.quotestock"})
@EnableScheduling
@EnableWebSocket
public class AppApplication {

    public static void main(String[] args) {
        SpringApplication.run(AppApplication.class, args);
    }

    @PostConstruct
    public void init() {
        log.info("应用启动");
    }
}
