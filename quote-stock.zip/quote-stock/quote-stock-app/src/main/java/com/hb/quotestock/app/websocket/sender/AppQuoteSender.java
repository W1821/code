package com.hb.quotestock.app.websocket.sender;

import com.hb.quotestock.common.constant.QuoteTypeEnum;
import com.hb.quotestock.common.pojo.quote.*;
import com.hb.quotestock.common.websocket.server.WSClientSession;
import com.hb.quotestock.common.websocket.server.WSClientSessionManager;

import javax.validation.constraints.NotNull;

public class AppQuoteSender {

    /**
     * 响应消息给所有客户端，有行情订阅判断，订阅了才发送
     */
    public static void sendMsgToAll(QuoteWrapper wrapper) {
        WSClientSessionManager.getAllWebSocketClient().forEach(clientSession -> sendMsgToClient(clientSession, wrapper));
    }

    /**
     * 响应消息给单个客户端，有行情订阅判断
     */
    private static void sendMsgToClient(@NotNull WSClientSession clientSession, QuoteWrapper wrapper) {
        if (clientSession == null || wrapper == null) {
            return;
        }
        // 判断是否订阅了
        QuoteSubscribeInfo quoteSubscribeInfo = clientSession.getQuoteSubscribeInfo();
        if (quoteSubscribeInfo == null || quoteSubscribeInfo.isNotSubscribeCode(wrapper.getQuoteType(), getSubscribeCode(wrapper))) {
            return;
        }
        WSClientSessionManager.sendMsgToClient(clientSession, wrapper.getQuoteData().toString());
    }

    /**
     * 得到当前行情的主键
     */
    private static String getSubscribeCode(QuoteWrapper wrapper) {
        QuoteTypeEnum quoteType = wrapper.getQuoteType();
        if (quoteType == null) {
            return null;
        }
        switch (quoteType) {
            case STOCK:
                StockQuote stockQuote = (StockQuote) wrapper.getQuoteData();
                return stockQuote.getSd();
            case EXPONENT:
                ExponentQuote exponentQuote = (ExponentQuote) wrapper.getQuoteData();
                return exponentQuote.getSd();
            case SINA_INDUSTRY:
                SinaIndustryQuote sinaIndustryQuote = (SinaIndustryQuote) wrapper.getQuoteData();
                return sinaIndustryQuote.getHydm();
        }
        return null;
    }

}
