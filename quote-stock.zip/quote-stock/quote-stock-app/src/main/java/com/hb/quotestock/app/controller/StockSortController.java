package com.hb.quotestock.app.controller;

import com.hb.quotestock.common.cache.QuoteCache;
import com.hb.quotestock.common.pojo.dto.ResponseMessage;
import com.hb.quotestock.common.pojo.quote.QuoteWrapper;
import com.hb.quotestock.common.pojo.quote.SinaIndustryQuote;
import com.hb.quotestock.common.pojo.quote.StockQuote;
import com.hb.quotestock.common.util.ListUtil;
import com.hb.quotestock.common.util.ResponseMessageUtil;
import com.hb.quotestock.common.util.StringUtil;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.stream.Collectors;


@RestController
@Api("股票排序相关")
public class StockSortController {

    @RequestMapping(value = {"/stock/sort/codeList", "/sort/stock"}, method = RequestMethod.GET)
    @ApiOperation(value = "按字段、排序方式排序后返回股票代码集合")
    @SuppressWarnings("unchecked")
    public ResponseMessage<List<String>> getSortedStockAll(
            @RequestParam("field") @ApiParam(value = "排序字段", example = "b1") String field,
            @RequestParam("sortType") @ApiParam(value = "正反序排序,desc或asc", example = "desc") String sortType) {

        List<StockQuote> list = QuoteCache.STOCK.values()
                .stream()
                .map(QuoteWrapper::getQuoteData)
                .collect(Collectors.toList());

        boolean isAsc = StringUtil.equals("asc", sortType);
        // 排序
        ListUtil.sort(list, field, isAsc);
        List<String> stockCodes = list.stream().map(StockQuote::getSd).collect(Collectors.toList());

        return ResponseMessageUtil.success(stockCodes);
    }

    /**
     * 重构的新接口
     */
    @RequestMapping(value = {"/sort/stock/top50"}, method = RequestMethod.GET)
    @ApiOperation(value = "按字段、排序方式排序后返回股票代码集合,只返回前50条记录")
    @SuppressWarnings("unchecked")
    public ResponseMessage<List<String>> getSortedStockTop50(
            @RequestParam("field") @ApiParam(value = "排序字段", example = "b1") String field,
            @RequestParam("sortType") @ApiParam(value = "正反序排序,desc或asc", example = "desc") String sortType) {

        List<StockQuote> list = QuoteCache.STOCK.values()
                .stream()
                .map(QuoteWrapper::getQuoteData)
                .collect(Collectors.toList());

        boolean isAsc = StringUtil.equals("asc", sortType);
        // 排序
        ListUtil.sort(list, field, isAsc);
        List<String> stockCodes = list
                .stream()
                .limit(50)
                .map(StockQuote::getSd)
                .collect(Collectors.toList());

        return ResponseMessageUtil.success(stockCodes);
    }

    @RequestMapping(value = {"/stock/sort/hangye", "/sort/industry"}, method = RequestMethod.GET)
    @ApiOperation(value = "按字段、排序方式排序后返回股票行业代码集合")
    @SuppressWarnings("unchecked")
    public ResponseMessage<List<String>> getSortedIndustryList(
            @RequestParam("field") @ApiParam(value = "排序字段", example = "b1") String field,
            @RequestParam("sortType") @ApiParam(value = "正反序排序,desc或asc", example = "desc") String sortType) {

        List<SinaIndustryQuote> list = QuoteCache.SINA_INDUSTRY.values()
                .stream()
                .map(QuoteWrapper::getQuoteData)
                .collect(Collectors.toList());
        boolean isAsc = StringUtil.equals("asc", sortType);
        // 排序
        ListUtil.sort(list, field, isAsc);
        List<String> industryCodes = list.stream().map(SinaIndustryQuote::getHydm).collect(Collectors.toList());

        return ResponseMessageUtil.success(industryCodes);
    }
}
