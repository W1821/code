package com.hb.quotestock.app.websocket.client;

import com.hb.quotestock.app.constant.ThreadPoolConstant;
import com.hb.quotestock.app.websocket.sender.AppQuoteSender;
import com.hb.quotestock.common.cache.QuoteCache;
import com.hb.quotestock.common.constant.QuoteTypeEnum;
import com.hb.quotestock.common.pojo.quote.*;
import com.hb.quotestock.common.util.FastJsonUtil;
import com.hb.quotestock.common.websocket.client.WSMessageHandler;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

/**
 * 行情消息处理器
 */
@Component
@Slf4j
public class AppWSClientMessageHandler extends WSMessageHandler {

    /**
     * app 不会发送逐笔
     * TODO server 推送的是 ServerQuoteMessage json格式
     * TODO app端需要重写此方法，如果以后连接server的程序都升级了，可以删除
     */
    @Override
    protected void handleMessage(String message) {
        ServerQuoteMessage serverQuoteMessage = FastJsonUtil.jsonToObject(message, ServerQuoteMessage.class);
        if (serverQuoteMessage == null) {
            return;
        }
        QuoteTypeEnum quoteType = QuoteTypeEnum.getByKey(serverQuoteMessage.getType());
        if (quoteType == null) {
            return;
        }
        message = serverQuoteMessage.getData();
        switch (quoteType) {
            case STOCK:
                handleStockMessage(message);
                break;
            case EXPONENT:
                handleExponentMessage(message);
                break;
            case SINA_INDUSTRY:
                handleSinaIndustryMessage(message);
                break;
            default:
        }
    }

    /**
     * 启用线程处理股票行情
     */
    public void handleStockMessage(String message) {
        ThreadPoolConstant.STOCK_HANDLE_POOL.execute(() -> {
             StockQuote quote = FastJsonUtil.jsonToObject(message, StockQuote.class);
             if (quote == null) {
                return;
            }
            QuoteWrapper<StockQuote> quoteWrapper = new QuoteWrapper<>();
            quoteWrapper.setQuoteType(QuoteTypeEnum.STOCK);
            quoteWrapper.setQuoteData(quote);
            // 放入缓存中
            QuoteCache.STOCK.put(quote.getSd(), quoteWrapper);
            // 发送给所有客户端
            AppQuoteSender.sendMsgToAll(quoteWrapper);
        });
    }

    /**
     * 启用线程处理指数行情
     */
    public void handleExponentMessage(String message) {
        ThreadPoolConstant.EXPONENT_HANDLE_POOL.execute(() -> {
            ExponentQuote quote = FastJsonUtil.jsonToObject(message, ExponentQuote.class);
            if (quote == null) {
                return;
            }
            QuoteWrapper<ExponentQuote> quoteWrapper = new QuoteWrapper<>();
            quoteWrapper.setQuoteType(QuoteTypeEnum.EXPONENT);
            quoteWrapper.setQuoteData(quote);
            // 放入缓存中
            QuoteCache.EXPONENT.put(quote.getSd(), quoteWrapper);
            // 发送给所有客户端
            AppQuoteSender.sendMsgToAll(quoteWrapper);
        });
    }

    /**
     * 启用线程处理新浪行业行情
     */
    public void handleSinaIndustryMessage(String message) {
        ThreadPoolConstant.SINA_INDUSTRY_HANDLE_POOL.execute(() -> {
            SinaIndustryQuote quote = FastJsonUtil.jsonToObject(message, SinaIndustryQuote.class);
            if (quote == null) {
                return;
            }
            QuoteWrapper<SinaIndustryQuote> quoteWrapper = new QuoteWrapper<>();
            quoteWrapper.setQuoteType(QuoteTypeEnum.SINA_INDUSTRY);
            quoteWrapper.setQuoteData(quote);
            // 放入缓存中
            QuoteCache.SINA_INDUSTRY.put(quote.getHydm(), quoteWrapper);
            // 发送给所有客户端
            AppQuoteSender.sendMsgToAll(quoteWrapper);
        });
    }


}
