package com.hb.quotestock.app.controller;


import com.hb.quotestock.common.cache.QuoteCache;
import com.hb.quotestock.common.constant.GlobalCodeEnum;
import com.hb.quotestock.common.pojo.dto.ResponseMessage;
import com.hb.quotestock.common.pojo.quote.QuoteWrapper;
import com.hb.quotestock.common.pojo.quote.SinaIndustryQuote;
import com.hb.quotestock.common.util.ResponseMessageUtil;
import com.hb.quotestock.common.util.StringUtil;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

@RestController
@Slf4j
@Api("股票行业相关")
public class SinaIndustryController {

    @ApiOperation(value = "获取股票所有的新浪行业信息")
    @RequestMapping(value = {"/getHyList", "/industry/all"}, method = RequestMethod.GET)
    @SuppressWarnings("unchecked")
    public ResponseMessage<List<SinaIndustryQuote>> getIndustryAll() {
        List<SinaIndustryQuote> list = QuoteCache.SINA_INDUSTRY.values()
                .stream()
                .map(QuoteWrapper::getQuoteData)
                .collect(Collectors.toList());
        return ResponseMessageUtil.success(list);
    }

    @ApiOperation(value = "根据新浪行业代码查询行业信息")
    @RequestMapping(value = {"/hangye", "/industry/find"}, method = RequestMethod.GET)
    @SuppressWarnings("unchecked")
    public ResponseMessage<List<SinaIndustryQuote>> findIndustryByCodes(@RequestParam("sds") @ApiParam(value = "行业代码，多个使用逗号分隔", example = "new_blhy") String sds) {
        String[] stockCodes = StringUtil.splitComma(sds);
        if (stockCodes == null) {
            return ResponseMessageUtil.error(GlobalCodeEnum.ErrorCode.ERROR_1001);
        }
        List<SinaIndustryQuote> list = Arrays.stream(stockCodes)
                .map(QuoteCache.SINA_INDUSTRY::get)
                .filter(Objects::nonNull)
                .map(QuoteWrapper::getQuoteData)
                .filter(Objects::nonNull)
                .collect(Collectors.toList());
        return ResponseMessageUtil.success(list);
    }


}
