package com.hb.quotestock.common.repository;

import com.hb.quotestock.common.pojo.po.StockStopResumptionModel;
import com.hb.quotestock.common.pojo.po.StockStopResumptionPrimaryKey;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.stereotype.Repository;

import java.util.List;


@Repository
public interface StockStopResumptionRepository
        extends JpaRepository<StockStopResumptionModel, StockStopResumptionPrimaryKey>, JpaSpecificationExecutor<StockStopResumptionModel> {

    @Modifying
    void deleteByStopResDate(String nowDate);

    @Modifying
    void deleteByStopResDateLessThan(String stopResDate);

    List<StockStopResumptionModel> findByStopResDateOrderByStockIdAsc(String date);
}
