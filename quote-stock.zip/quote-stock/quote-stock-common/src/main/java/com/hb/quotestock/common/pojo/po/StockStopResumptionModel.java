package com.hb.quotestock.common.pojo.po;


import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;

/**
 * 股票停复牌
 */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@IdClass(StockStopResumptionPrimaryKey.class)
@Table(name = "stock_stop_resumption")
public class StockStopResumptionModel {

    /**
     * 停复牌日
     */
    @Id
    private String stopResDate;

    /**
     * 股票代码
     */
    @Id
    private String stockId;

    /**
     * 交易提示描述
     */
    private String tipsDesc;

    /**
     * 交易提示类型：H--停牌，R--复牌
     */
    private String tipsTypeCode;

}
