package com.hb.quotestock.common.pojo.po;

import lombok.*;

import javax.persistence.Id;
import java.io.Serializable;
import java.time.LocalDate;

/**
 * 股票停复牌联合主键
 */
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@EqualsAndHashCode
public class StockStopResumptionPrimaryKey implements Serializable {

    /**
     * 停复牌日
     */
    @Id
    private String stopResDate;

    /**
     * 股票代码
     */
    @Id
    private String stockId;

}
