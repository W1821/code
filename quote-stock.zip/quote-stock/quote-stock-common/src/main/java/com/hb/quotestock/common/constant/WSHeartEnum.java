package com.hb.quotestock.common.constant;

import lombok.Getter;

public enum WSHeartEnum {

    PING("ping", "PING"),
    PONG("pong", "PONG");

    @Getter
    private String key;
    @Getter
    private String value;

    WSHeartEnum(String key, String value) {
        this.key = key;
        this.value = value;
    }

}
