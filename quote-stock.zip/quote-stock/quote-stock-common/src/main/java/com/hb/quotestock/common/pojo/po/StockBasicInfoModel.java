package com.hb.quotestock.common.pojo.po;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.time.LocalDate;

/**
 * 通联股票基本信息
 */
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@Entity
@Table(name = "stock_basic_info")
public class StockBasicInfoModel extends BasePO {

    /**
     * 主键
     */
    @Id
    private String stockId;

    /**
     * 股票代码
     */
    private String stockCode;

    /**
     * 股票拼音码
     */
    private String stockPinyin;

    /**
     * 证券简称
     */
    private String stockShortName;

    /**
     * 证券全称
     */
    private String stockFullName;

    /**
     * 交易所代码。例如，XSHG-上海证券交易所；XSHE-深圳证券交易所。
     */
    private String exchangeCode;

    /**
     * 交易市场所属地区代码。例如，CHN-中国大陆；HKG-香港。
     */
    private String exchangeCountryCode;

    /**
     * 上市板块编码。例如，1-主板；2-创业板；3-中小板。
     */
    private Integer listSectorCode;

    /**
     * 上市板块描述
     */
    private String listSectorDesc;

    /**
     * 上市状态。L-上市；S-暂停；DE-终止上市；UN-未上市。
     */
    private String listStatusCode;

    /**
     * 上市日期
     */
    private LocalDate listDate;

    /**
     * 摘牌日期
     */
    private LocalDate delistDate;

    /**
     * 财务报告日期
     */
    private LocalDate financialReportDate;

    /**
     * 股票分类编码。例如，A-A股；B-B股
     */
    private String stockTypeCode;

    /**
     * 股票类别名称
     */
    private String stockTypeName;

    /**
     * 总股本(最新)
     */
    private Double totalShares;

    /**
     * 公司无限售流通股份合计(最新)
     */
    private Double nonRestFloatShares;

    /**
     * 无限售流通股本(最新)。如果为A股，该列为最新无限售流通A股股本数量；如果为B股，该列为最新流通B股股本数量
     */
    @Column(name = "non_rest_float_a")
    private Double nonRestFloatA;

    /**
     * 所有者权益合计
     */
    private Double totalOwnersEquity;

    /**
     * 交易货币。例如，CNY-人民币元；USD-美元。对应getSysCode.codeTypeID=10004
     */
    private String tradeCurrencyCode;

    /**
     * 办公地址
     */
    private String officeAddress;

    /**
     * 主营业务范围
     */
    @Column(length = 10000)
    private String mainBusinessScope;


}
