package com.hb.quotestock.common.pojo.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.*;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@Builder
@ApiModel("除权除息-通联获取的信息")
public class AdjFactorInfoTLDTO extends BaseDTO {

    @ApiModelProperty(value = "股票编号", example = "000001")
    private String stockId;

    @ApiModelProperty(value = "除权除息日", example = "2018-05-13")
    private String excludeDate;

    @ApiModelProperty(value = "股票名称", example = "平安银行")
    private String stockName;

    @ApiModelProperty(value = "每股派现（分红）", example = "0.174")
    private Double perShareCash;

    @ApiModelProperty(value = "每股送股比例（送转股）", example = "0.2")
    private Double perShareRatio;

    @ApiModelProperty(value = "每股配股比例（配股）", example = "0.3")
    private Double perAllotmentRatio;

    @ApiModelProperty(value = "配股价", example = "8")
    private Double allotmentPrice;

    @ApiModelProperty(value = "交易所编码", example = "sh")
    private String exchangeCD;

    @ApiModelProperty(value = "每股转增股比例", example = "0.5")
    private Double perTransRatio;

    @ApiModelProperty(value = "复权因子", example = "0.8217317462")
    private Double adjFactor;

    @ApiModelProperty(value = "累积复权因子", example = "0.549221562")
    private Double accumAdjFactor;

    @ApiModelProperty(value = "累积复权因子截止日期", example = "2013-06-20")
    private String adjEndDate;

}
