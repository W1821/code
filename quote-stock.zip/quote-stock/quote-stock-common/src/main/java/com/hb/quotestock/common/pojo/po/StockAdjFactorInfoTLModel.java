package com.hb.quotestock.common.pojo.po;

import lombok.*;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;
import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * 除权除息，通联接口返回
 */
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@Builder
@Entity
@IdClass(StockAdjFactorInfoTLPrimaryKey.class)
@Table(name = "stock_adj_factor_info_tl")
public class StockAdjFactorInfoTLModel extends BasePO {

    /**
     * 通联编制的证券编码
     */
    private String secId;

    /**
     * 通用交易代码
     */
    @Id
    private String ticker;

    /**
     * 除权除息日，股改对应股改后首个交易日
     */
    @Id
    private LocalDate exDivDate;

    /**
     * 通联编制的交易市场编码
     */
    private String exchangeCode;

    /**
     * 证券简称
     */
    private String secShortName;

    /**
     * 证券英文简称
     */
    private String secShortNameEn;


    /**
     * 每股派现（税前）
     */
    private Double perCashDiv;

    /**
     * 每股送股比例
     */
    private Double perShareDivRatio;

    /**
     * 每股转增股比例
     */
    private Double perShareTransRatio;

    /**
     * 每股配股比例
     */
    private Double allotmentRatio;

    /**
     * 配股价
     */
    private Double allotmentPrice;

    /**
     * 单次前复权因子，对应一个除权除息日的权息修复比例
     */
    private Double adjFactor;

    /**
     * 累积前复权因子，发生在本次除权除息日（含）之后的前复权因子累乘。每当有新的前复权因子产生，该股票的所有累积前复权因子均会刷新
     */
    private Double accumAdjFactor;

    /**
     * 累积前复权因子起始生效日期，前复权价=对应交易日期在[endDate,exDivDate)区间的未复权价*累积前复权因子
     */
    private LocalDate endDate;

    /**
     * 最近一次更新时间
     */
    private LocalDateTime updateTime;

}
