package com.hb.quotestock.common.websocket.server;

import com.hb.quotestock.common.constant.WSAttributeConstant;
import com.hb.quotestock.common.util.IPUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.server.ServerHttpRequest;
import org.springframework.http.server.ServerHttpResponse;
import org.springframework.http.server.ServletServerHttpRequest;
import org.springframework.web.socket.WebSocketHandler;
import org.springframework.web.socket.server.HandshakeInterceptor;

import javax.servlet.http.HttpServletRequest;
import java.util.Map;

/**
 * web socket 握手拦截器
 */
@Slf4j
public class WSHandshakeInterceptor implements HandshakeInterceptor {

    /**
     * web socket 握手前拦截处理
     */
    @Override
    public boolean beforeHandshake(ServerHttpRequest request, ServerHttpResponse response, WebSocketHandler wsHandler, Map<String, Object> attributes) {
        addIpAttributes(request, attributes);
        return true;
    }

    @Override
    public void afterHandshake(ServerHttpRequest request, ServerHttpResponse response, WebSocketHandler wsHandler, Exception exception) {
    }

    /**
     * 添加属性
     */
    private void addIpAttributes(ServerHttpRequest request, Map<String, Object> attributes) {
        try {
            ServletServerHttpRequest servletServerHttpRequest = (ServletServerHttpRequest) request;
            HttpServletRequest httpServletRequest = servletServerHttpRequest.getServletRequest();
            String ip = IPUtil.getClientIP(httpServletRequest);
            if (ip != null) {
                attributes.put(WSAttributeConstant.IP, ip);
            }
            String clientType = httpServletRequest.getParameter(WSAttributeConstant.CLIENT_TYPE);
            if (clientType != null) {
                attributes.put(WSAttributeConstant.CLIENT_TYPE, clientType);
            }
        } catch (Exception ignored) {
        }
    }

}
