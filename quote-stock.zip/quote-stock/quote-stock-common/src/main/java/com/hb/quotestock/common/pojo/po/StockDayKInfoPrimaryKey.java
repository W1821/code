package com.hb.quotestock.common.pojo.po;

import lombok.*;

import java.io.Serializable;
import java.time.LocalDate;

/**
 * 交易所日历联合主键
 */
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@Builder
@EqualsAndHashCode
public class StockDayKInfoPrimaryKey implements Serializable {

    /**
     * 股票编码
     */
    private String stockCode;

    /**
     * 日期
     */
    private LocalDate date;

}
