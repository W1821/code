package com.hb.quotestock.common.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.socket.server.standard.ServletServerContainerFactoryBean;

@Configuration
public class WebSocketConfig {

    private final WebSocketServerConfig webSocketServerConfig;

    @Autowired
    public WebSocketConfig(WebSocketServerConfig webSocketServerConfig) {
        this.webSocketServerConfig = webSocketServerConfig;
    }

    /**
     * 配置websocket
     */
    @Bean
    public ServletServerContainerFactoryBean createServletServerContainerFactoryBean() {
        ServletServerContainerFactoryBean container = new ServletServerContainerFactoryBean();
        // 文本消息缓存大小，对于tomcat容器来说，每个链接都会有此大小的Frame对象，如果配置太大，会导致内存溢出
        container.setMaxTextMessageBufferSize(webSocketServerConfig.getBufferSize());
        container.setAsyncSendTimeout(webSocketServerConfig.getSendTimeout());
        return container;
    }

}
