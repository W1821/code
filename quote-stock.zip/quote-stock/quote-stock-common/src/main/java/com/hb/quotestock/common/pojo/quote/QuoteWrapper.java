package com.hb.quotestock.common.pojo.quote;

import com.hb.quotestock.common.constant.QuoteSourceEnum;
import com.hb.quotestock.common.constant.QuoteTypeEnum;
import lombok.*;

import java.time.LocalDate;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class QuoteWrapper<T extends BaseQuote> extends BaseQuote {

    /**
     * 行情类型
     */
    private QuoteTypeEnum quoteType;
    /**
     * 行情源, sina or tl
     */
    private QuoteSourceEnum quoteSource;
    /**
     * 本地服务器行情解析时间
     */
    private LocalDate receiveDate = LocalDate.now();

    /**
     * 行情详细数
     */
    private T quoteData;


}
