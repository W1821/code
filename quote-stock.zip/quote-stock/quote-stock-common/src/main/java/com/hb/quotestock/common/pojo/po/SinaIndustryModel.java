package com.hb.quotestock.common.pojo.po;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * 新浪行业
 */
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@Entity
@Table(name = "sina_industry")
public class SinaIndustryModel extends BasePO {

    /**
     * 行业代码
     */
    @Id
    private String sinaIndustryCode;
    /**
     * 包含的股票代码集合
     */
    @Column(length = 10000)
    private String industryStocks;

}
