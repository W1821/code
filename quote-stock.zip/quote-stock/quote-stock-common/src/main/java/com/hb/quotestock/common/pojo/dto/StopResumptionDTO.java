package com.hb.quotestock.common.pojo.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.*;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@Builder
@ApiModel("股票停复牌")
public class StopResumptionDTO extends BaseDTO {

    @ApiModelProperty(value = "股票代码", example = "000029")
    private String stockId;

    @ApiModelProperty(value = "交易提示类型：“H:停牌”，“R:复牌”", example = "H")
    private String tipsTypeCd;
}
