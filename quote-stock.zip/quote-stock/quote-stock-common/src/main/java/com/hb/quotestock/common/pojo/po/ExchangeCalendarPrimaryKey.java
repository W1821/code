package com.hb.quotestock.common.pojo.po;

import lombok.*;

import java.io.Serializable;

/**
 * 交易所日历联合主键
 */
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@EqualsAndHashCode
public class ExchangeCalendarPrimaryKey implements Serializable {

    /**
     * 证券交易所代码，sh或sz
     */
    private String exchangeCode;

    /**
     * 日期
     */
    private String calendarDate;

}