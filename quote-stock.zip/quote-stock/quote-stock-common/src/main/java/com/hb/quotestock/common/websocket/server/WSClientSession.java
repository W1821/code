package com.hb.quotestock.common.websocket.server;

import com.hb.quotestock.common.constant.WSAttributeConstant;
import com.hb.quotestock.common.pojo.quote.QuoteSubscribeInfo;
import com.hb.quotestock.common.util.ThreadPoolUtil;
import com.hb.quotestock.common.websocket.sender.WebSocketSender;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.socket.CloseStatus;
import org.springframework.web.socket.WebSocketSession;

import java.time.LocalDateTime;
import java.util.List;
import java.util.concurrent.ThreadPoolExecutor;

/**
 * websocket建立连接保存对象
 * 这里的方法都用WSClientSessionManager来调用
 */
@Slf4j
public class WSClientSession {

    protected static final String UNKNOWN = "unknown";

    /**
     * 线程池工作队列缓存大小，缓存队列太大会导致内存不足。
     * 一次采集会发送很多行情数据，缓存队列太小会导致连接被主动断开
     * <p>
     * 这个值大概是：股票的数量+指数的数量+逐笔的数量+新浪行业的数量
     * 大概就是这些：3800 + 50 + 3800 + 50 再增加一些其他的设置为10000比较合理
     * 如果网络很差，3秒钟没能处理掉这么多行情，就会导致内存已满
     * <p>
     * collector 和 server 冗余设计 15000，如果逐笔是真实的逐笔，此值还需要增大点
     * app 冗余设计 10000， 因为app不会发送逐笔
     */
    private static final int WORK_QUEUE_SIZE = 15000;

    /**
     * 用户socket session
     */
    protected WebSocketSession session;

    /**
     * 用户发送数据的线程池，使用单线程池发送数据，确保行情有序
     * 缓存队列满时的拒绝策略是默认的，抛出异常
     */
    private ThreadPoolExecutor threadPoolExecutor;

    /**
     * 心跳时间
     */
    private LocalDateTime heartbeatTime;

    /**
     * 建立连接时间，不会改变，不提供set方法
     */
    @Getter
    private LocalDateTime connectionDateTime;

    /**
     * 行情订阅信息，server端和app端需要用到此对象来判断订阅情况
     * collector暂时不用
     */
    @Getter
    protected QuoteSubscribeInfo quoteSubscribeInfo;

    /**
     * 构造方法
     */
    protected WSClientSession(WebSocketSession session) {
        init(session, WORK_QUEUE_SIZE);
    }

    /**
     * 构造方法
     */
    protected WSClientSession(WebSocketSession session, int workQueueSize) {
        init(session, workQueueSize);
    }

    /**
     * 获取客户端IP
     */
    public String getIp() {
        if (session == null) {
            return UNKNOWN;
        }
        String ip = (String) session.getAttributes().get(WSAttributeConstant.IP);
        return ip == null ? UNKNOWN : ip;
    }

    /**
     * 获取客户端类型
     */
    public String getClientType() {
        if (session == null) {
            return UNKNOWN;
        }
        String ip = (String) session.getAttributes().get(WSAttributeConstant.CLIENT_TYPE);
        return ip == null ? UNKNOWN : ip;
    }

    /**
     * 获取sessionId
     */
    public String getSessionId() {
        if (session == null) {
            return null;
        }
        return session.getId();
    }

    /* ======================================================================================================== */

    /**
     * 发送消息
     */
    void sendMessage(String message) {
        if (session == null || threadPoolExecutor == null) {
            return;
        }
        // 如果连接已经关闭，关闭线程池
        if (!session.isOpen()) {
            closeThreadPool();
            return;
        }
        threadPoolExecutor.execute(() -> WebSocketSender.serverSendMessage(session, message));
    }

    /**
     * 更新心跳时间
     */
    void updateHeartbeatDate() {
        heartbeatTime = LocalDateTime.now();
    }

    /**
     * 检测心跳是否超时
     *
     * @param seconds 超时秒数
     * @return 是否超时
     */
    boolean checkHeartbeatTimeout(long seconds) {
        return heartbeatTime.plusSeconds(seconds).isBefore(LocalDateTime.now());
    }

    /**
     * 回收资源
     */
    void destroy() {
        if (threadPoolExecutor != null) {
            closeThreadPool();
        }
        if (session != null) {
            closeWebSocket();
        }
    }

    /**
     * 关闭线程池
     */
    private void closeThreadPool() {
        if (!threadPoolExecutor.isShutdown()) {
            List<Runnable> runnableList = threadPoolExecutor.shutdownNow();
            log.info("线程池已经关闭，未执行的任务数量：{}个", runnableList.size());
        }
        threadPoolExecutor = null;
    }

    /**
     * 服务端主动关闭websocket连接
     */
    private void closeWebSocket() {
        if (session.isOpen()) {
            try {
                session.close(CloseStatus.SERVICE_RESTARTED);
                log.info("websocket已经关闭, ip={}", this.getIp());
            } catch (Exception e) {
                log.error("close web socket fail", e);
            }
        }
        session = null;
    }

    private void init(WebSocketSession session, int workQueueSize) {
        this.session = session;
        LocalDateTime now = LocalDateTime.now();
        this.heartbeatTime = now;
        this.connectionDateTime = now;
        this.threadPoolExecutor = ThreadPoolUtil.createSingleExecutor("web-socket-sender-" + this.session.getId(), workQueueSize);
    }

}
