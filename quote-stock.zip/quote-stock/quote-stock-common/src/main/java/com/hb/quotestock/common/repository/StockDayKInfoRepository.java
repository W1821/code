package com.hb.quotestock.common.repository;

import com.hb.quotestock.common.pojo.po.StockDayKInfoModel;
import com.hb.quotestock.common.pojo.po.StockDayKInfoPrimaryKey;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;

@Repository
public interface StockDayKInfoRepository
        extends JpaRepository<StockDayKInfoModel, StockDayKInfoPrimaryKey>, JpaSpecificationExecutor<StockDayKInfoModel> {

    List<StockDayKInfoModel> findByDateGreaterThanEqualAndDateLessThan(LocalDate startDate, LocalDate now);

}
