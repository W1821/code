package com.hb.quotestock.common.pojo.dto;

import lombok.*;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@Builder
public class NotifyDTO extends BaseDTO {
    /**
     * 请求校验token
     */
    private String verifyToken;

    /**
     * 通知类型：1.行情 2.TC
     */
    private int type;

    /**
     * 需要发送的通知
     */
    private String message;
}