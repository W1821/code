package com.hb.quotestock.common.util;

import com.hb.quotestock.common.constant.QuoteTypeEnum;
import com.hb.quotestock.common.log.ExponentLog;
import com.hb.quotestock.common.log.SinaIndustryLog;
import com.hb.quotestock.common.log.StockLog;
import com.hb.quotestock.common.log.TransactionLog;
import com.hb.quotestock.common.pojo.quote.BaseQuote;
import com.hb.quotestock.common.pojo.quote.QuoteWrapper;

public class QuoteUtil {

    // 开发测试默认不打印日志
    private static final boolean SHOW_LOG = false;

    /**
     * 行情日志
     */
    public static void log(QuoteWrapper wrapper) {
        if (!SHOW_LOG) {
            return;
        }
        if (wrapper == null) {
            return;
        }
        QuoteTypeEnum quoteType = wrapper.getQuoteType();
        if (quoteType == null) {
            return;
        }
        String message = wrapper.toString();
        switch (quoteType) {
            case STOCK:
                StockLog.log(message);
                break;
            case EXPONENT:
                ExponentLog.log(message);
                break;
            case TRANSACTION:
                TransactionLog.log(message);
                break;
            case SINA_INDUSTRY:
                SinaIndustryLog.log(message);
                break;
            default:
        }
    }

    /**
     * 股票编号
     */
    public static boolean stockIsKCB(String stockCode) {
        if (stockCode == null) {
            return false;
        }
        return stockCode.startsWith("688");
    }

}
