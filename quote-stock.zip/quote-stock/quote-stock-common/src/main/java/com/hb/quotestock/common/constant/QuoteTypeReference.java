package com.hb.quotestock.common.constant;

import com.alibaba.fastjson.TypeReference;
import com.hb.quotestock.common.pojo.quote.ExponentQuote;
import com.hb.quotestock.common.pojo.quote.SinaIndustryQuote;
import com.hb.quotestock.common.pojo.quote.StockQuote;
import com.hb.quotestock.common.pojo.quote.TransactionQuote;
import com.hb.quotestock.common.pojo.quote.QuoteWrapper;

/**
 * fastjson 泛型解析
 */
public class QuoteTypeReference {

    public static final StockDTOTypeReference STOCK_DTO_TYPE_REFERENCE = new StockDTOTypeReference();

    private static class StockDTOTypeReference extends TypeReference<QuoteWrapper<StockQuote>> {

    }

    public static final ExponentDTOTypeReference EXPONENT_DTO_TYPE_REFERENCE = new ExponentDTOTypeReference();

    private static class ExponentDTOTypeReference extends TypeReference<QuoteWrapper<ExponentQuote>> {

    }

    public static final TransactionDTOTypeReference TRANSACTION_DTO_TYPE_REFERENCE = new TransactionDTOTypeReference();

    private static class TransactionDTOTypeReference extends TypeReference<QuoteWrapper<TransactionQuote>> {

    }

    public static final SinaIndustryDTOTypeReference SINA_INDUSTRY_DTO_TYPE_REFERENCE = new SinaIndustryDTOTypeReference();

    private static class SinaIndustryDTOTypeReference extends TypeReference<QuoteWrapper<SinaIndustryQuote>> {

    }

}
