package com.hb.quotestock.common.pojo.dto;


import com.hb.quotestock.common.pojo.BaseBean;

/**
 * 基础的DTO
 */
public class BaseDTO extends BaseBean {

}
