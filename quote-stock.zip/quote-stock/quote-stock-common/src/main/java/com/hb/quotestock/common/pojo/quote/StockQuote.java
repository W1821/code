package com.hb.quotestock.common.pojo.quote;

import lombok.*;

/**
 * 股票统一返回类型
 */
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@Builder
public class StockQuote extends BaseQuote {

    /**
     * 交易所代码
     */
    private String ed;
    /**
     * 股票代码
     */
    private String sd;
    /**
     * 股票名称
     */
    private String sn;
    /**
     * 今日开盘价
     */
    private float tp;
    /**
     * 昨日收盘价
     */
    private float ytp;
    /**
     * 当前价格
     */
    private float cp;
    /**
     * 今日最高价
     */
    private float tmp;
    /**
     * 今日最低价
     */
    private float tip;
    /**
     * 竞买价  买一报价
     */
    private float cbp;
    /**
     * 竞卖价 卖一报价
     */
    private float csp;
    /**
     * 成交股票数    由于股票交易以一百股微基本单位，所以在使用时，通常把该值除以100
     */
    private String dsn;
    /**
     * 成交金额，单位为“元”，为了一目了然，通常以“万元”为成交金额的单位，所以通常把该值除以一万；
     */
    private String dsm;
    /**
     * 买一
     */
    private float b1;
    /**
     * 买一价
     */
    private float b1p;
    /**
     * 买二
     */
    private float b2;
    /**
     * 买二价
     */
    private float b2p;
    /**
     * 买三
     */
    private float b3;
    /**
     * 买三价
     */
    private float b3p;
    /**
     * 买四
     */
    private float b4;
    /**
     * 买四价
     */
    private float b4p;
    /**
     * 买五
     */
    private float b5;
    /**
     * 买五价
     */
    private float b5p;
    /**
     * 卖一
     */
    private float s1;
    /**
     * 卖一价
     */
    private float s1p;
    /**
     * 卖二
     */
    private float s2;
    /**
     * 卖二价
     */
    private float s2p;
    /**
     * 卖三
     */
    private float s3;
    /**
     * 卖三价
     */
    private float s3p;
    /**
     * 卖四
     */
    private float s4;
    /**
     * 卖四价
     */
    private float s4p;
    /**
     * 卖五
     */
    private float s5;
    /**
     * 卖五价
     */
    private float s5p;
    /**
     * 日期
     * 每隔3秒推送过来一次
     */
    private String date;
    /**
     * 涨停价
     */
    private double pul;
    /**
     * 跌停价
     */
    private double pdl;
    /**
     * 升跌一
     */
    private double pud1;
    /**
     * 升跌二
     */
    private double pud2;
    /**
     * 成交笔数
     */
    private long tn;
    /**
     * 今收盘价
     */
    private double clp;
    /**
     * 当前品种交易状态
     */
    private String spt;
    /**
     * 市盈率 1
     */
    private double pe1;
    /**
     * 市盈率 2
     */
    private double pe2;
    /**
     * 币种
     */
    private String cd;
    /**
     * 停牌标识
     */
    private int ssn;
    /**
     * 涨跌幅
     */
    private double cg;
    /**
     * 涨跌幅比
     */
    private double cgp;
    /**
     * 振幅
     */
    private double ap;
    /**
     * 换手率
     */
    private double tr;
    /**
     * 盘后成交股票数    由于股票交易以一百股微基本单位，所以在使用时，通常把该值除以100
     */
    private String cdsn;
    /**
     * 盘后成交金额，单位为“元”，为了一目了然，通常以“万元”为成交金额的单位，所以通常把该值除以一万；
     */
    private String cdsm;
    /**
     * 量比
     */
    private String lb;

}
