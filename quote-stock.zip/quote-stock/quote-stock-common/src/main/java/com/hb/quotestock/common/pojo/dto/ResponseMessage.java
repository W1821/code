package com.hb.quotestock.common.pojo.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.*;

/**
 * 响应消息
 */
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@Builder
@ApiModel("响应消息")
public class ResponseMessage<T> extends BaseDTO {

    @ApiModelProperty(value = "错误状态码,如果是0，表示正确", example = "0")
    private Integer retCode;

    @ApiModelProperty(value = "错误信息", example = "参数错误")
    private String message;

    @ApiModelProperty(value = "消息体，响应正确信息", example = "{}")
    private T data;

}