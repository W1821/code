package com.hb.quotestock.common.repository;

import com.hb.quotestock.common.pojo.po.SinaIndustryModel;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

@Repository
public interface SinaIndustryRepository
        extends JpaRepository<SinaIndustryModel, String>, JpaSpecificationExecutor<SinaIndustryModel> {

}
