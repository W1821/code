package com.hb.quotestock.common.pojo.po;

import lombok.*;

import java.io.Serializable;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@EqualsAndHashCode
public class StockAdjFactorInfoPrimaryKey implements Serializable {

    /**
     * 股票编号
     */
    private String stockId;

    /**
     * 除权除息日
     */
    private String excludeDate;

}
