package com.hb.quotestock.common.pojo;

import com.hb.quotestock.common.util.FastJsonUtil;

import java.io.Serializable;

/**
 * 基础的
 */
public class BaseBean implements Serializable {
    @Override
    public String toString() {
        return FastJsonUtil.objToJsonString(this);
    }
}
