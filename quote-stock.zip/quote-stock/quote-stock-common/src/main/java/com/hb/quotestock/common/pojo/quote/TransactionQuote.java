package com.hb.quotestock.common.pojo.quote;

import lombok.*;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@Builder
public class TransactionQuote extends BaseQuote {

    /**
     * 证券代码
     */
    private String sd;
    /**
     * 成交时间
     */
    private String tt;
    /**
     * 成交价格
     */
    private Double tp;
    /**
     * 成交数量 2 位有效小数位。股票为股，基金为份，债券为张
     */
    private Double tv;
    /**
     * 成交方向 买入为0, 卖出为1, 未知为2
     */
    private Integer to;

}
