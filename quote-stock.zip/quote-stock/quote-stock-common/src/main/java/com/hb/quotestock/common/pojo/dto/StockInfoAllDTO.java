package com.hb.quotestock.common.pojo.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.*;

/**
 * 兼容老版本
 */
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@Builder
@ApiModel("股票基本信息-全部信息")
public class StockInfoAllDTO {

    @ApiModelProperty(value = "证券代码", example = "000001.XSHE")
    private String secid;

    @ApiModelProperty(value = "交易代码", example = "000001")
    private String ticker;

    @ApiModelProperty(value = "交易所代码", example = "sz")
    private String exchangecd;

    @ApiModelProperty(value = "拼音码", example = "PAYH")
    private String pinyin;

    @ApiModelProperty(value = "上市板块编码", example = "1")
    private int lissectorcd;

    @ApiModelProperty(value = "上市板块", example = "主板")
    private String listsector;

    @ApiModelProperty(value = "交易货币", example = "CNY")
    private String transcurrcd;

    @ApiModelProperty(value = "证券简称", example = "平安银行")
    private String secshortname;

    @ApiModelProperty(value = "证券全称", example = "平安银行股份有限公司")
    private String secfullname;

    @ApiModelProperty(value = "上市状态", example = "L")
    private String liststatuscd;

    @ApiModelProperty(value = "上市日期", example = "1991-04-03")
    private String listdate;

    @ApiModelProperty(value = "摘牌日期", example = "null")
    private String delistdate;

    @ApiModelProperty(value = "股票分类编码", example = "A")
    private String equtypecd;

    @ApiModelProperty(value = "股票分类", example = "沪深A股")
    private String equtype;

    @ApiModelProperty(value = "交易市场所属地区", example = "CHN")
    private String excountrycd;

    @ApiModelProperty(value = "机构内部ID", example = "2")
    private int partyid;

    @ApiModelProperty(value = "总股本", example = "19405918200")
    private Double totalshares;

    @ApiModelProperty(value = "公司无限售流通股份合计", example = "19405752700")
    private Double nonrestfloatshares;

    @ApiModelProperty(value = "无限售流通股份本", example = "19405752700")
    private Double nonrestfloata;

    @ApiModelProperty(value = "办公地址", example = "广东省深圳市罗湖区深南东路5047号")
    private String officaddr;

    @ApiModelProperty(value = "主营业务范围", example = "人民币、外币存贷款;国际、国内结算;票据贴现;外汇买卖;提供担保及信用证服务;提供保管箱服务等。")
    private String primeoperating;

    @ApiModelProperty(value = "财务报告日期", example = "2019-09-30")
    private String enddate;

    @ApiModelProperty(value = "所有者权益合计", example = "288073000000")
    private Double tshequity;

}
