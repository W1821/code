package com.hb.quotestock.common.cache;

import java.time.LocalDateTime;

public class SystemCache {

    /**
     * 系统启动时间
     */
    public static final LocalDateTime SYSTEM_START_TIME = LocalDateTime.now();

}
