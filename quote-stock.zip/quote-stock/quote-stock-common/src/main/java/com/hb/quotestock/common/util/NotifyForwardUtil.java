package com.hb.quotestock.common.util;

import com.hb.quotestock.common.config.NotifyConfig;
import com.hb.quotestock.common.pojo.dto.NotifyDTO;
import lombok.extern.slf4j.Slf4j;
import okhttp3.*;

import java.util.concurrent.TimeUnit;

/**
 * 通知转发工具类
 */

@Slf4j
public class NotifyForwardUtil {

    private static final MediaType JSON = MediaType.parse("application/json; charset=utf-8");

    private static OkHttpClient client;

    static {
        // http连接池配置
        ConnectionPool pool = new ConnectionPool(1, 60 * 3, TimeUnit.SECONDS);
        client = new OkHttpClient.Builder()
                .connectTimeout(20, TimeUnit.SECONDS)
                .readTimeout(20, TimeUnit.SECONDS)
                .connectionPool(pool)
                .followRedirects(true)
                .retryOnConnectionFailure(false)
                .build();
    }

    /**
     * 通知转发（此处仅发送文本信息）
     *
     * @param message      需要发送的消息
     * @param notifyConfig 配置
     */
    public static void notify(String message, NotifyConfig notifyConfig) {
        if (!notifyConfig.isEnableNotify()) {
            return;
        }
        NotifyDTO dto = NotifyDTO
                .builder()
                .verifyToken(notifyConfig.getToken())
                .type(notifyConfig.getType())
                .message(message)
                .build();
        String json = FastJsonUtil.objToJsonString(dto);
        ResponseBody responseBody = post(notifyConfig.getForwardUrl(), json);
        log.info("发送通知消息，message={},responseBody={}", message, responseBody);
    }

    private static ResponseBody post(String url, String json) {
        try {
            RequestBody body = RequestBody.create(JSON, json);
            Request request = new Request.Builder()
                    .url(url)
                    .post(body)
                    .build();
            Response response = client.newCall(request).execute();
            if (!response.isSuccessful()) {
                log.error("通知消息失败, url={},body={} code={}", url, json, response.code());
                return null;
            }
            return response.body();
        } catch (Exception e) {
            log.error("通知消息失败, url={},body={} code={}", url, json, e);
        }
        return null;
    }

}