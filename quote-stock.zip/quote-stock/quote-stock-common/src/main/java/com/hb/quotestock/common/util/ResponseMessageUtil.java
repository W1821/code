package com.hb.quotestock.common.util;


import com.hb.quotestock.common.constant.GlobalCodeEnum;
import com.hb.quotestock.common.pojo.dto.ResponseMessage;

import javax.validation.constraints.NotNull;

/**
 * 消息工具类
 */
public class ResponseMessageUtil {

    /* ================================================================================= */

    /**
     * 系统出错
     */
    public static ResponseMessage error() {
        return ResponseMessage.builder()
                .retCode(GlobalCodeEnum.ErrorCode.ERROR_500.getKey())
                .message(GlobalCodeEnum.ErrorCode.ERROR_500.getValue())
                .build();
    }

    /**
     * 系统出错
     */
    public static ResponseMessage error(String errorMsg) {
        return ResponseMessage.builder()
                .retCode(GlobalCodeEnum.ErrorCode.ERROR_500.getKey())
                .message(errorMsg)
                .build();
    }

    /**
     * 错误提示信息
     */
    public static ResponseMessage error(@NotNull GlobalCodeEnum.ErrorCode errorCode) {
        return ResponseMessage.builder()
                .retCode(errorCode.getKey())
                .message(errorCode.getValue())
                .build();
    }

    /**
     * 返回正确信息
     */
    public static ResponseMessage success() {
        return ResponseMessage.builder()
                .retCode(GlobalCodeEnum.SuccessCode.SUCCESS.getKey())
                .message(GlobalCodeEnum.SuccessCode.SUCCESS.getValue())
                .build();
    }

    /**
     * 返回正确信息
     */
    public static ResponseMessage success(Object msg) {
        return ResponseMessage.builder()
                .retCode(GlobalCodeEnum.SuccessCode.SUCCESS.getKey())
                .message(GlobalCodeEnum.SuccessCode.SUCCESS.getValue())
                .data(msg)
                .build();
    }

    /**
     * 返回正确信息
     */
    public static ResponseMessage success(@NotNull GlobalCodeEnum.SuccessCode successCode) {
        return ResponseMessage.builder()
                .retCode(successCode.getKey())
                .message(successCode.getValue())
                .build();
    }

    /**
     * 返回正确信息
     */
    public static ResponseMessage success(GlobalCodeEnum.SuccessCode successCode, Object data) {
        return ResponseMessage.builder()
                .retCode(successCode.getKey())
                .message(successCode.getValue())
                .data(data)
                .build();
    }

}
