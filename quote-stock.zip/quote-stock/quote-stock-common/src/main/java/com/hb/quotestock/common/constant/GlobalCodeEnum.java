package com.hb.quotestock.common.constant;


import lombok.Getter;

/**
 * 公告常量类
 */
public final class GlobalCodeEnum {


    /**
     * 错误码
     */
    public enum ErrorCode {

        /**
         * 错误码
         * key 都是-1，兼容老版本
         */
        ERROR_401(401, "Unauthorized"),
        ERROR_500(500, "Internal Server Error"),
        ERROR_1001(-1, "参数错误！");

        @Getter
        private int key;
        @Getter
        private String value;

        ErrorCode(int key, String value) {
            this.key = key;
            this.value = value;
        }

    }

    /**
     * 成功码
     */
    public enum SuccessCode {

        /**
         *
         */
        SUCCESS(0, "ok");

        @Getter
        private int key;
        @Getter
        private String value;

        SuccessCode(int key, String value) {
            this.key = key;
            this.value = value;
        }

    }

}
