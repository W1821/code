package com.hb.quotestock.common.pojo.quote;

import lombok.*;

/**
 * 指数
 */
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@Builder
public class ExponentQuote extends BaseQuote {

    /**
     * 交易所代码
     */
    private String ed;
    /**
     * 指数代码
     */
    private String sd;
    /**
     * 指数名称
     */
    private String sn;
    /**
     * 今开
     */
    private String jk;
    /**
     * 昨收
     */
    private String zs;
    /**
     * 当前点数
     */
    private String cps;
    /**
     * 最高
     */
    private String zg;
    /**
     * 最低
     */
    private String zd;
    /**
     * 成交股票数    由于股票交易以一百股微基本单位，所以在使用时，通常把该值除以100
     */
    private String dsn;
    /**
     * 成交金额，单位为“元”，为了一目了然，通常以“万元”为成交金额的单位，所以通常把该值除以一万；
     */
    private String dsm;
    /**
     * 时间
     */
    private String date;

}
