package com.hb.quotestock.common.pojo.dto;


import lombok.*;

/**
 * 分页查询DTO
 */
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@Builder
public class PageDTO extends BaseDTO {

    /**
     * 第几页，从1开始。
     * 默认为第1页
     */
    private Integer index;
    /**
     * 页面容量，一页多少条。
     * 默认为10条
     */
    private Integer size;

    /**
     * 排序字段
     */
    private String sortField;

    /**
     * 排序方式
     */
    private String sortOrder;

    public Integer getIndex() {
        // 分页从0开始
        return index == null || index <= 0 ? 0 : index - 1;
    }

    public Integer getSize() {
        return size == null || size < 1 || size > 100 ? 10 : size;
    }
}
