package com.hb.quotestock.common.websocket.sender;

import lombok.extern.slf4j.Slf4j;
import org.springframework.web.socket.TextMessage;
import org.springframework.web.socket.WebSocketSession;

import javax.websocket.Session;
import java.io.IOException;

@Slf4j
public class WebSocketSender {

    /**
     * 发送消息
     */
    public static void serverSendMessage(WebSocketSession session, String message) {
        if (session == null || !session.isOpen()) {
            return;
        }
        if (message == null) {
            return;
        }
        try {
            session.sendMessage(new TextMessage(message));
        } catch (IOException e) {
            log.error("web socket send fail,id={}, message={}, error={}", session.getId(), message, e.getMessage());
        } catch (Exception e) {
            log.error("web socket send fail,id={}, message={}", session.getId(), message, e);
        }
    }

    /**
     * 发送消息
     */
    public static void clientSendMessage(Session session, String message) {
        if (session == null || !session.isOpen()) {
            return;
        }
        if (message == null) {
            return;
        }
        try {
            session.getAsyncRemote().sendText(message);
        } catch (Exception e) {
            log.error("send message error", e);
        }
    }

}
