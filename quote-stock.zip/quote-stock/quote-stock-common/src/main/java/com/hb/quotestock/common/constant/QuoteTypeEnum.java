package com.hb.quotestock.common.constant;

import lombok.Getter;

/**
 * 行情类型
 */
public enum QuoteTypeEnum {

    STOCK("1", "股票行情"),
    EXPONENT("2", "新浪指数"),
    TRANSACTION("3", "股票逐笔"),
    SINA_INDUSTRY("4", "新浪行业");

    @Getter
    private String key;
    @Getter
    private String value;

    QuoteTypeEnum(String key, String value) {
        this.key = key;
        this.value = value;
    }

    public static QuoteTypeEnum getByKey(String key) {
        if (key == null) {
            return null;
        }
        for (QuoteTypeEnum quoteTypeEnum : QuoteTypeEnum.values()) {
            if (key.equalsIgnoreCase(quoteTypeEnum.getKey())) {
                return quoteTypeEnum;
            }
        }
        return null;
    }
}
