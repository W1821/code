package com.hb.quotestock.common.pojo.quote;

import com.hb.quotestock.common.pojo.BaseBean;

public class BaseQuote extends BaseBean {
}
