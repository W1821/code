package com.hb.quotestock.common.pojo.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@ApiModel("股票日K")
public class StockDayInfoDTO extends BaseDTO {

    @ApiModelProperty(value = "收盘价", example = "10.77")
    private float close;

    @ApiModelProperty(value = "最高价", example = "10.82")
    private float high;

    @ApiModelProperty(value = "最低价", example = "10.64")
    private float low;

    @ApiModelProperty(value = "开盘价", example = "10.69")
    private float open;
}
