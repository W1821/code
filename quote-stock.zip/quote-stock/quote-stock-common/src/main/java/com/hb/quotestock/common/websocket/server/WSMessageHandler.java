package com.hb.quotestock.common.websocket.server;

import com.hb.quotestock.common.cache.QuoteCache;
import com.hb.quotestock.common.constant.QuoteSubscribeEnum;
import com.hb.quotestock.common.constant.QuoteTypeEnum;
import com.hb.quotestock.common.constant.WSHeartEnum;
import com.hb.quotestock.common.pojo.quote.ClientSubscribeMessage;
import com.hb.quotestock.common.pojo.quote.QuoteSubscribeInfo;
import com.hb.quotestock.common.pojo.quote.QuoteWrapper;
import com.hb.quotestock.common.util.FastJsonUtil;
import com.hb.quotestock.common.util.StringUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.socket.CloseStatus;
import org.springframework.web.socket.TextMessage;
import org.springframework.web.socket.WebSocketSession;
import org.springframework.web.socket.handler.TextWebSocketHandler;

import java.io.EOFException;
import java.io.IOException;
import java.net.SocketTimeoutException;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 * websocket服务端接收消息处理
 */
@Slf4j
public class WSMessageHandler extends TextWebSocketHandler {

    /**
     * socket 接收到消息
     */
    @Override
    protected void handleTextMessage(WebSocketSession session, TextMessage message) {
        String payload = message.getPayload();
        if (StringUtil.isEmpty(payload)) {
            return;
        }
        // 如果是心跳包
        if (isPing(payload)) {
            sendPong(session);
            return;
        }
        // 处理订阅消息
        handleClientMessage(session, payload);
    }

    /**
     * 把WSClientSession放入WSClientSession管理器中
     */
    protected void putWSClientSessionToManager(WebSocketSession session) {
        WSClientSession clientSession = new WSClientSession(session);
        WSClientSessionManager.put(clientSession);
    }

    /**
     * 把WSClientSession放入WSClientSession管理器中
     */
    protected void putWSClientSessionToManager(WSClientSession clientSession) {
        WSClientSessionManager.put(clientSession);
    }

    /**
     * websocket 传输数据出现错误 打印日志
     */
    @Override
    public final void handleTransportError(WebSocketSession session, Throwable exception) {
        String sessionId = session.getId();
        WSClientSession clientSession = WSClientSessionManager.getClientSessionById(sessionId);
        if (clientSession == null) {
            log.error("session transport error, session not found, id={}", sessionId);
            return;
        }
        String ip = clientSession.getIp();
        String clientType = clientSession.getClientType();
        if (exception instanceof EOFException) {
            log.error("session transport error, {}, id={}, ip={}, clientType={}", "EOFException", sessionId, ip, clientType);
            return;
        }
        if (exception instanceof SocketTimeoutException) {
            log.error("session transport error, {}, id={}, ip={}, clientType={}", "SocketTimeoutException", sessionId, ip, clientType);
            return;
        }
        if (exception instanceof IOException) {
            log.error("session transport error, {}, id={}, ip={}, clientType={}, message={}", "IOException", sessionId, ip, clientType, exception.getMessage());
            return;
        }
        log.error("session transport error, id={}, ip={}, clientType={}", sessionId, ip, clientType, exception);
    }

    /**
     * websocket 关闭处理
     */
    @Override
    public final void afterConnectionClosed(WebSocketSession session, CloseStatus status) {
        WSClientSessionManager.remove(session);
        log.info("session close, statusCode={}, statusReason={}", status.getCode(), status.getReason());
    }

    /**
     * 处理消息
     * 默认处理订阅消息
     * 如有需要，可以重写此方法
     */
    protected void handleClientMessage(WebSocketSession session, String message) {
        this.handleSubscribeMessage(session, message);
    }

    /* ================================================= 私有方法 =============================================== */

    /*
     * 判断是否是心跳包
     */
    private boolean isPing(String message) {
        return StringUtil.equalsIgnoreCase(message, WSHeartEnum.PING.getKey());
    }

    /**
     * 发送心跳响应
     */
    private void sendPong(WebSocketSession webSocketSession) {
        // 发送心跳响应回去
        WSClientSessionManager.sendPong(webSocketSession);
    }

    /**
     * 处理订阅消息
     */
    private void handleSubscribeMessage(WebSocketSession session, String message) {
        // 判断订阅信息
        ClientSubscribeMessage subscribeMessage = FastJsonUtil.jsonToObject(message, ClientSubscribeMessage.class);
        if (subscribeMessage == null) {
            return;
        }

        QuoteSubscribeEnum quoteSubscribeEnum = QuoteSubscribeEnum.getByKey(subscribeMessage.getType());
        if (quoteSubscribeEnum == null) {
            log.error("订阅信息错误，{}", message);
            return;
        }
        QuoteSubscribeInfo quoteSubscribeInfo = getQuoteSubscribeInfo(session);
        if (quoteSubscribeInfo == null) {
            return;
        }

        String[] subscribes = StringUtil.splitComma(subscribeMessage.getData());
        if (subscribes == null) {
            return;
        }
        Set<String> subscribeSets = Stream.of(subscribes).collect(Collectors.toSet());

        switch (quoteSubscribeEnum) {
            case STOCK_SUBSCRIBE:
                handleStockSubscribe(quoteSubscribeInfo, subscribeSets);
                sendStockCache(quoteSubscribeInfo, session);
                break;
            case STOCK_UNSUBSCRIBE:
                handleStockUnSubscribe(quoteSubscribeInfo, subscribeSets);
                break;
            case EXPONENT_SUBSCRIBE:
                handleExponentSubscribe(quoteSubscribeInfo, subscribeSets);
                sendExponentCache(quoteSubscribeInfo, session);
                break;
            case EXPONENT_UNSUBSCRIBE:
                handleExponentUnSubscribe(quoteSubscribeInfo, subscribeSets);
                break;
            case TRANSACTION_SUBSCRIBE:
                handleTransactionSubscribe(quoteSubscribeInfo, subscribeSets);
                sendTransactionCache(quoteSubscribeInfo, session);
                break;
            case TRANSACTION_UNSUBSCRIBE:
                handleTransactionUnSubscribe(quoteSubscribeInfo, subscribeSets);
                break;
            case SINA_INDUSTRY_SUBSCRIBE:
                handleSinaIndustrySubscribe(quoteSubscribeInfo, subscribeSets);
                sendSinaIndustryCache(quoteSubscribeInfo, session);
                break;
            case SINA_INDUSTRY_UNSUBSCRIBE:
                handleSinaIndustryUnSubscribe(quoteSubscribeInfo, subscribeSets);
                break;
            default:

        }
    }

    /**
     * 获取websocket客户的订阅行情信息
     */
    private QuoteSubscribeInfo getQuoteSubscribeInfo(WebSocketSession session) {
        if (session == null) {
            return null;
        }
        WSClientSession clientSession = WSClientSessionManager.getClientSessionById(session.getId());
        if (clientSession == null) {
            return null;
        }
        return clientSession.getQuoteSubscribeInfo();
    }


    /**
     * 股票订阅
     */
    private void handleStockSubscribe(QuoteSubscribeInfo quoteSubscribeInfo, Set<String> subscribes) {
        quoteSubscribeInfo.subscribeQuote(QuoteTypeEnum.STOCK, subscribes);
    }

    /**
     * 股票反订阅
     */
    private void handleStockUnSubscribe(QuoteSubscribeInfo quoteSubscribeInfo, Set<String> subscribes) {
        quoteSubscribeInfo.unsubscribeQuote(QuoteTypeEnum.STOCK, subscribes);
    }

    /**
     * 指数订阅
     */
    private void handleExponentSubscribe(QuoteSubscribeInfo quoteSubscribeInfo, Set<String> subscribes) {
        quoteSubscribeInfo.subscribeQuote(QuoteTypeEnum.EXPONENT, subscribes);
    }

    /**
     * 指数反订阅
     */
    private void handleExponentUnSubscribe(QuoteSubscribeInfo quoteSubscribeInfo, Set<String> subscribes) {
        quoteSubscribeInfo.unsubscribeQuote(QuoteTypeEnum.EXPONENT, subscribes);
    }

    /**
     * 逐笔订阅
     */
    private void handleTransactionSubscribe(QuoteSubscribeInfo quoteSubscribeInfo, Set<String> subscribes) {
        quoteSubscribeInfo.subscribeQuote(QuoteTypeEnum.TRANSACTION, subscribes);
    }

    /**
     * 逐笔反订阅
     */
    private void handleTransactionUnSubscribe(QuoteSubscribeInfo quoteSubscribeInfo, Set<String> subscribes) {
        quoteSubscribeInfo.unsubscribeQuote(QuoteTypeEnum.TRANSACTION, subscribes);
    }

    /**
     * 新浪行业订阅
     */
    private void handleSinaIndustrySubscribe(QuoteSubscribeInfo quoteSubscribeInfo, Set<String> subscribes) {
        quoteSubscribeInfo.subscribeQuote(QuoteTypeEnum.SINA_INDUSTRY, subscribes);
    }

    /**
     * 新浪行业反订阅
     */
    private void handleSinaIndustryUnSubscribe(QuoteSubscribeInfo quoteSubscribeInfo, Set<String> subscribes) {
        quoteSubscribeInfo.unsubscribeQuote(QuoteTypeEnum.SINA_INDUSTRY, subscribes);
    }


    /**
     * 发送股票缓存
     */
    private void sendStockCache(QuoteSubscribeInfo quoteSubscribeInfo, WebSocketSession session) {
        QuoteTypeEnum quoteTypeEnum = QuoteTypeEnum.STOCK;
        WSClientSession clientSession = WSClientSessionManager.getClientSessionById(session.getId());
        // 订阅所有
        if (quoteSubscribeInfo.isSubAll(quoteTypeEnum)) {
            QuoteCache.STOCK.values()
                    .stream()
                    .map(QuoteWrapper::getQuoteData)
                    .filter(Objects::nonNull)
                    .forEach(quote -> WSClientSessionManager.sendMsgToClient(clientSession, quote.toString()));
        } else {
            Set<String> codes = quoteSubscribeInfo.getSubscribeCodes(quoteTypeEnum);
            codes.stream()
                    .map(QuoteCache.STOCK::get)
                    .filter(Objects::nonNull)
                    .map(QuoteWrapper::getQuoteData)
                    .filter(Objects::nonNull)
                    .forEach(stockQuote -> WSClientSessionManager.sendMsgToClient(clientSession, stockQuote.toString()));
        }
    }

    private void sendExponentCache(QuoteSubscribeInfo quoteSubscribeInfo, WebSocketSession session) {
        QuoteTypeEnum quoteTypeEnum = QuoteTypeEnum.EXPONENT;
        WSClientSession clientSession = WSClientSessionManager.getClientSessionById(session.getId());
        // 订阅所有
        if (quoteSubscribeInfo.isSubAll(quoteTypeEnum)) {
            QuoteCache.EXPONENT.values()
                    .stream()
                    .map(QuoteWrapper::getQuoteData)
                    .filter(Objects::nonNull)
                    .forEach(quote -> WSClientSessionManager.sendMsgToClient(clientSession, quote.toString()));
        } else {
            Set<String> codes = quoteSubscribeInfo.getSubscribeCodes(quoteTypeEnum);
            codes.stream()
                    .map(QuoteCache.EXPONENT::get)
                    .filter(Objects::nonNull)
                    .map(QuoteWrapper::getQuoteData)
                    .filter(Objects::nonNull)
                    .forEach(quote -> WSClientSessionManager.sendMsgToClient(clientSession, quote.toString()));
        }
    }

    private void sendTransactionCache(QuoteSubscribeInfo quoteSubscribeInfo, WebSocketSession session) {
        QuoteTypeEnum quoteTypeEnum = QuoteTypeEnum.TRANSACTION;
        WSClientSession clientSession = WSClientSessionManager.getClientSessionById(session.getId());
        // 订阅所有
        if (quoteSubscribeInfo.isSubAll(quoteTypeEnum)) {
            QuoteCache.TRANSACTION.values()
                    .stream()
                    .map(QuoteWrapper::getQuoteData)
                    .filter(Objects::nonNull)
                    .forEach(quote -> WSClientSessionManager.sendMsgToClient(clientSession, quote.toString()));
        } else {
            Set<String> codes = quoteSubscribeInfo.getSubscribeCodes(quoteTypeEnum);
            codes.stream()
                    .map(QuoteCache.TRANSACTION::get)
                    .filter(Objects::nonNull)
                    .map(QuoteWrapper::getQuoteData)
                    .filter(Objects::nonNull)
                    .forEach(quote -> WSClientSessionManager.sendMsgToClient(clientSession, quote.toString()));
        }
    }

    private void sendSinaIndustryCache(QuoteSubscribeInfo quoteSubscribeInfo, WebSocketSession session) {
        QuoteTypeEnum quoteTypeEnum = QuoteTypeEnum.SINA_INDUSTRY;
        WSClientSession clientSession = WSClientSessionManager.getClientSessionById(session.getId());
        // 订阅所有
        if (quoteSubscribeInfo.isSubAll(quoteTypeEnum)) {
            QuoteCache.SINA_INDUSTRY.values()
                    .stream()
                    .map(QuoteWrapper::getQuoteData)
                    .filter(Objects::nonNull)
                    .forEach(quote -> WSClientSessionManager.sendMsgToClient(clientSession, quote.toString()));
        } else {
            Set<String> codes = quoteSubscribeInfo.getSubscribeCodes(quoteTypeEnum);
            codes.stream()
                    .map(QuoteCache.SINA_INDUSTRY::get)
                    .filter(Objects::nonNull)
                    .map(QuoteWrapper::getQuoteData)
                    .filter(Objects::nonNull)
                    .forEach(quote -> WSClientSessionManager.sendMsgToClient(clientSession, quote.toString()));
        }
    }

}