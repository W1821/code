package com.hb.quotestock.common.repository;

import com.hb.quotestock.common.pojo.po.StockAdjFactorInfoModel;
import com.hb.quotestock.common.pojo.po.StockAdjFactorInfoPrimaryKey;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;


@Repository
public interface StockAdjFactorInfoRepository
        extends JpaRepository<StockAdjFactorInfoModel, StockAdjFactorInfoPrimaryKey>, JpaSpecificationExecutor<StockAdjFactorInfoModel> {

    List<StockAdjFactorInfoModel> findByExcludeDate(String date);
}
