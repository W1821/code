package com.hb.quotestock.common.pojo.po;

import com.hb.quotestock.common.pojo.BaseBean;

class BasePO extends BaseBean {
}
