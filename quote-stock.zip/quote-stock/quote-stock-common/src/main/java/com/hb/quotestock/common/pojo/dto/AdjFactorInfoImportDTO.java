package com.hb.quotestock.common.pojo.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@ApiModel("除权除息-人工导入的信息")
public class AdjFactorInfoImportDTO extends BaseDTO {

    @ApiModelProperty(value = "股票编号", example = "000001")
    private String stockId;

    @ApiModelProperty(value = "除权除息日", example = "2018-05-13")
    private String excludeDate;

    @ApiModelProperty(value = "股票名称", example = "平安银行")
    private String stockName;

    @ApiModelProperty(value = "每股派现（分红）", example = "0.174")
    private Double perShareCash;

    @ApiModelProperty(value = "每股送股比例（送转股）", example = "0.2")
    private Double perShareRatio;

    @ApiModelProperty(value = "每股配股比例（配股）", example = "0.3")
    private Double perAllotmentRatio;

    @ApiModelProperty(value = "配股价", example = "8")
    private Double allotmentPrice;

}
