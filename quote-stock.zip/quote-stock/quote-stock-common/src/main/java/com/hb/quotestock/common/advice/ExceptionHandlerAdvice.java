package com.hb.quotestock.common.advice;

import com.hb.quotestock.common.pojo.dto.ResponseMessage;
import com.hb.quotestock.common.util.ResponseMessageUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;

/**
 * Controller异常增强处理
 */
@Slf4j
@ControllerAdvice
public class ExceptionHandlerAdvice {

    /**
     * 全局异常捕捉处理
     */
    @ResponseBody
    @ExceptionHandler(value = Exception.class)
    public ResponseMessage errorHandler(Exception ex) {
        log.error("全局异常捕捉处理", ex);
        return ResponseMessageUtil.error();
    }

    /**
     * 参数验证异常捕捉处理
     */
    @ResponseBody
    @ExceptionHandler(value = MethodArgumentNotValidException.class)
    public ResponseMessage errorHandler(MethodArgumentNotValidException ex) {
        // 参数校验失败信息
        FieldError fieldError = ex.getBindingResult().getFieldError();
        log.error("拦截捕捉参数验证异常 - message = {}", fieldError);

        if (fieldError == null) {
            return ResponseMessageUtil.error();
        } else {
            return ResponseMessageUtil.error(fieldError.getDefaultMessage());
        }
    }

}
