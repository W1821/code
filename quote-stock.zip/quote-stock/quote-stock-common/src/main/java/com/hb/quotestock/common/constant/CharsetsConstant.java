package com.hb.quotestock.common.constant;

import java.nio.charset.Charset;

public class CharsetsConstant {

    public static final Charset UTF_8 = Charset.forName("utf-8");
    public static final Charset GBK = Charset.forName("gbk");
    public static final Charset GB_2312 = Charset.forName("gb2312");

}
