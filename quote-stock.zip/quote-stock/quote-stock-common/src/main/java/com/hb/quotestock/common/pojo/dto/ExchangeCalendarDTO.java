package com.hb.quotestock.common.pojo.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.*;


/**
 * 交易所日历基本信息
 */
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@Builder
@ApiModel("交易所日历基本信息")
public class ExchangeCalendarDTO {

    @ApiModelProperty(value = "证券交易所", example = "sh")
    private String exchangeCD;

    @ApiModelProperty(value = "日期", example = "2017-12-07")
    private String calendarDate;

    @ApiModelProperty(value = "日期当天是否开市", example = "1")
    private Integer isOpen;

    @ApiModelProperty(value = "当前日期前一天交易日", example = "2017-12-06")
    private String prevTradeDate;

    @ApiModelProperty(value = "当前日期是否当周最后交易日", example = "1")
    private Integer isWeekEnd;

    @ApiModelProperty(value = "当前日期是否当月最后交易日", example = "1")
    private Integer isMonthEnd;

    @ApiModelProperty(value = "当前日期是否当季最后交易日", example = "1")
    private Integer isQuarterEnd;

    @ApiModelProperty(value = "当前日期是否当年最后交易日", example = "1")
    private Integer isYearEnd;


}
