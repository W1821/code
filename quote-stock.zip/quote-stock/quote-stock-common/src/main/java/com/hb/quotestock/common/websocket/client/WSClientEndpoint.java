package com.hb.quotestock.common.websocket.client;

import com.hb.quotestock.common.config.WebSocketClientConfig;
import com.hb.quotestock.common.constant.WSHeartEnum;
import com.hb.quotestock.common.util.ThreadPoolUtil;
import com.hb.quotestock.common.websocket.sender.WebSocketSender;
import lombok.extern.slf4j.Slf4j;

import javax.websocket.*;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.concurrent.Future;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

/**
 * websocket客户端
 */
@Slf4j
public class WSClientEndpoint extends Endpoint {

    // 心跳定时发送线程池
    private final static ScheduledExecutorService WEBSOCKET_PING_POOL = ThreadPoolUtil.creatSingleScheduledThreadPool("websocket-ping");
    private Future heartFuture = null;

    // 连接的session
    private Session session;

    private final WSMessageHandler wsMessageHandler;
    private final WebSocketClientConfig webSocketClientConfig;

    public WSClientEndpoint(WSMessageHandler wsMessageHandler, WebSocketClientConfig webSocketClientConfig) {
        this.wsMessageHandler = wsMessageHandler;
        this.webSocketClientConfig = webSocketClientConfig;
    }

    /**
     * 提供给下级执行订阅操作
     */
    protected void afterOpen() {

    }

    /**
     * 发送消息到服务端
     */
    protected final void sendMessageToServer(String sendMessage) {
        WebSocketSender.clientSendMessage(session, sendMessage);
    }

    /* ============================================= final method =========================================== */

    @Override
    public final void onOpen(Session session, EndpointConfig config) {
        log.info("websocket onOpen sessionId={}", session.getId());
        this.session = session;
        // 启动心跳包任务
        startPingTask();
        // 执行打开连接后的操作
        afterOpen();
    }

    @Override
    public final void onError(Session session, Throwable t) {
        log.error("websocket onError", t);
    }

    @Override
    public final void onClose(Session session, CloseReason closeReason) {
        log.info("websocket onClose sessionId={}", session.getId());
        // 停止心跳
        stopPingTask();
        this.session = null;
        // 重连
        connectToServer();
    }

    /**
     * 连接websocket服务端
     */
    public final void connectToServer() {
        if (session != null && session.isOpen()) {
            return;
        }
        WebSocketContainer container = ContainerProvider.getWebSocketContainer();
        ClientEndpointConfig config = ClientEndpointConfig.Builder.create().build();
        try {
            Session session = container.connectToServer(this, config, new URI(webSocketClientConfig.getServerUrl()));
            session.addMessageHandler(wsMessageHandler);
        } catch (DeploymentException | IOException e) {
            long reconnectTime = webSocketClientConfig.getReconnectTime();
            log.info("reconnect to server after {}ms...", reconnectTime);
            ThreadPoolUtil.sleep(reconnectTime);
            connectToServer();
        } catch (URISyntaxException e) {
            log.error("connect to server error，server uri error");
        } catch (Exception e) {
            log.error("unknown error", e);
        }
    }

    /* ========================================= private method ========================================== */

    /**
     * 启动心跳定时任务
     */
    private void startPingTask() {
        this.heartFuture = WEBSOCKET_PING_POOL.scheduleAtFixedRate(this::sendPing, 0, 30, TimeUnit.SECONDS);
        log.info("启动心跳包定时任务");
    }

    /**
     * 发送心跳ping
     */
    private void sendPing() {
        WebSocketSender.clientSendMessage(session, WSHeartEnum.PING.getKey());
    }

    /**
     * 停止心跳定时任务
     */
    private void stopPingTask() {
        if (heartFuture == null) {
            return;
        }
        boolean success = heartFuture.cancel(true);
        log.info("停止心跳定时任务，结果={}", success);
    }
}