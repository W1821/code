package com.hb.quotestock.common.pojo.quote;

import com.hb.quotestock.common.pojo.BaseBean;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * 客户端订阅消息
 */
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class ClientSubscribeMessage extends BaseQuote {

    /**
     * 类型
     */
    private String type;

    /**
     * 数据
     */
    private String data;


}
