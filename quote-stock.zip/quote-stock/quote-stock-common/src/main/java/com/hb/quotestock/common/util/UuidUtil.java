package com.hb.quotestock.common.util;

import java.util.UUID;

public class UuidUtil {

    /**
     * 32位uuid
     */
    public static String getUUID32() {
        return UUID.randomUUID().toString().replace("-", "");
    }

}
