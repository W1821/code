package com.hb.quotestock.common.websocket.client;


import com.hb.quotestock.common.constant.QuoteTypeEnum;
import com.hb.quotestock.common.pojo.quote.QuoteWrapper;
import com.hb.quotestock.common.util.FastJsonUtil;
import com.hb.quotestock.common.util.ThreadPoolUtil;
import lombok.extern.slf4j.Slf4j;

import javax.websocket.MessageHandler;
import java.util.concurrent.ThreadPoolExecutor;

@Slf4j
public abstract class WSMessageHandler implements MessageHandler.Whole<String> {

    /**
     * 消息处理总线程池，
     * 这个值大概是：股票的数量+指数的数量+逐笔的数量+新浪行业的数量
     * 大概就是这些：3800 + 50 + 3800 + 50 再增加一些其他的设置为10000比较合理
     * 当队列满的时候会把最先的行情抛弃不处理
     */
    private static ThreadPoolExecutor handleExecutor = ThreadPoolUtil.createSingleExecutorDiscardOldestPolicy("message-handler-thread", 10000);

    @Override
    public void onMessage(String message) {
        try {
            // 开启线程处理
            handleExecutor.execute(() -> handleMessage(message));
        } catch (Exception e) {
            log.error("websocket client handle message error", e);
        }
    }

    /**
     * 支持 collector 发送给 server端
     * 不支持 server 发送给 app端 因为兼容老版本，server发送给app的转换了格式
     */
    protected void handleMessage(String message) {
        QuoteWrapper wrapper = FastJsonUtil.jsonToObject(message, QuoteWrapper.class);
        if (wrapper == null) {
            return;
        }
        QuoteTypeEnum quoteType = wrapper.getQuoteType();
        if (quoteType == null) {
            return;
        }
        switch (quoteType) {
            case STOCK:
                handleStockMessage(message);
                break;
            case EXPONENT:
                handleExponentMessage(message);
                break;
            case TRANSACTION:
                handleTransactionMessage(message);
                break;
            case SINA_INDUSTRY:
                handleSinaIndustryMessage(message);
                break;
            default:
        }
    }

    /**
     * 处理股票行情
     */
    protected void handleStockMessage(String message) {
    }

    /**
     * 处理指数行情
     */
    protected void handleExponentMessage(String message) {
    }

    /**
     * 处理股票行情
     */
    protected void handleTransactionMessage(String message) {
    }

    /**
     * 处理新浪行业行情
     */
    protected void handleSinaIndustryMessage(String message) {
    }


}