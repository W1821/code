package com.hb.quotestock.common.pojo.po;

import lombok.*;

import java.io.Serializable;
import java.time.LocalDate;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@EqualsAndHashCode
public class StockAdjFactorInfoTLPrimaryKey implements Serializable {

    /**
     * 通用交易代码
     */
    private String ticker;

    /**
     * 除权除息日，股改对应股改后首个交易日
     */
    private LocalDate exDivDate;

}
