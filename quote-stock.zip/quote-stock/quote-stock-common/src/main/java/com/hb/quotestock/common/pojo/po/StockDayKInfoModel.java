package com.hb.quotestock.common.pojo.po;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;
import java.time.LocalDate;

/**
 * 股票日K
 */
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@Entity
@IdClass(StockDayKInfoPrimaryKey.class)
@Table(name = "stock_day_k_info")
public class StockDayKInfoModel extends BasePO {

    /**
     * 股票编码
     */
    @Id
    private String stockCode;

    /**
     * 日期
     */
    @Id
    private LocalDate date;

    /**
     * 收盘价
     */
    private Double close;

    /**
     * 最高价
     */
    private Double high;

    /**
     * 最低价
     */
    private Double low;

    /**
     * 开盘价
     */
    private Double open;

    /**
     * 成交量
     */
    private Long volume;

}