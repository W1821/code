package com.hb.quotestock.common.websocket.server;

import com.hb.quotestock.common.constant.WSHeartEnum;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.socket.WebSocketSession;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.RejectedExecutionException;
import java.util.stream.Collectors;

/**
 * websocket客户的session管理器
 */
@Slf4j
public class WSClientSessionManager {

    /**
     * 记录WebSocket链接信息
     */
    private static final Map<String, WSClientSession> CLIENT_SESSION_MAP = new ConcurrentHashMap<>(1 << 7);

    /**
     * 心跳检查
     *
     * @param seconds 超时秒数
     */
    public static void checkHeartbeat(long seconds) {
        int clientCount = WSClientSessionManager.getWsConnectionCountTotal();
        // 心跳超时的连接
        List<WSClientSession> timeoutClients = getAllWebSocketClient()
                .stream()
                .filter(session -> session.checkHeartbeatTimeout(seconds))
                .collect(Collectors.toList());

        timeoutClients.forEach(session -> {
            // 先移除缓存
            WSClientSessionManager.remove(session);
            // 断开超时的连接，释放资源
            session.destroy();
        });
        log.info("客户端连接状态检测结果：websocket总连接数={}，心跳超时连接数={}", clientCount, timeoutClients.size());
    }

    /**
     * 根据一个sessionId获取当前session绑定的用户信息
     */
    public static WSClientSession getClientSessionById(String sessionId) {
        if (!existSessionId(sessionId)) {
            return null;
        }
        return CLIENT_SESSION_MAP.get(sessionId);
    }

    /**
     * 返回所有websocket连接
     */
    public static List<WSClientSession> getAllWebSocketClient() {
        return new ArrayList<>(CLIENT_SESSION_MAP.values());
    }

    /**
     * 每个连接使用独立的一个线程池推送消息
     * 响应消息给单个客户端
     */
    public static void sendMsgToClient(WSClientSession clientSession, String message) {
        if (clientSession == null || message == null) {
            return;
        }
        try {
            // 发送消息
            clientSession.sendMessage(message);
        } catch (RejectedExecutionException e) {
            // 1.客户端接收慢，网络不好
            // 2.服务器带宽不够
            log.error("此连接推送任务队列已满,id={}", clientSession.getSessionId());
            remove(clientSession);
            clientSession.destroy();
        } catch (Exception e) {
            // 其他未知异常
            log.error("系统主动推送消息给客户端失败,id={}", clientSession.getSessionId());
        }
    }


    /* =============================================== 包级方法 ================================================= */

    /**
     * 当有一个连接建立的时候，调用此方法
     */
    static void put(WSClientSession session) {
        if (session == null) {
            return;
        }
        String sessionId = session.getSessionId();
        if (sessionId == null) {
            log.error("WSClientSession property session is null");
            return;
        }
        WSClientSession wsClientSession = getClientSessionById(sessionId);
        // 已经存在
        if (wsClientSession != null) {
            log.error("websocket connection already exists, id={},ip={},totalCount={}", session.getSessionId(), session.getIp(), getWsConnectionCountTotal());
            return;
        }

        CLIENT_SESSION_MAP.put(sessionId, session);
        log.info("websocket connect success, id={},ip={},clientType={},totalCount={}", session.getSessionId(), session.getIp(), session.getClientType(), getWsConnectionCountTotal());
    }

    /**
     * 移除
     */
    static void remove(WebSocketSession webSocketSession) {
        if (webSocketSession == null) {
            return;
        }
        WSClientSession wsClientSession = CLIENT_SESSION_MAP.remove(webSocketSession.getId());
        if (wsClientSession != null) {
            wsClientSession.destroy();
            log.info("websocket close success, id={},ip={},totalCount={}", wsClientSession.getSessionId(), wsClientSession.getIp(), getWsConnectionCountTotal());
        }
    }

    /**
     * 发送心跳响应
     * 更新WSClientSession的心跳时间
     */
    static void sendPong(WebSocketSession webSocketSession) {
        WSClientSession clientSession = getClientSessionById(webSocketSession.getId());
        if (clientSession == null) {
            return;
        }
        sendMsgToClient(clientSession, WSHeartEnum.PONG.getKey());
        clientSession.updateHeartbeatDate();
    }

    /* =============================================== 私有方法 ================================================= */

    /**
     * 判断key是否存在
     */
    private static boolean existSessionId(String sessionId) {
        return sessionId != null;
    }


    /**
     * 当有一个连接关闭或出现异常的时候，调用此方法
     */
    private static void remove(WSClientSession wsClientSession) {
        if (wsClientSession == null) {
            return;
        }
        CLIENT_SESSION_MAP.remove(wsClientSession.getSessionId());
    }

    /**
     * 获取所有客户端连接数量
     */
    private static int getWsConnectionCountTotal() {
        return CLIENT_SESSION_MAP.size();
    }

}


