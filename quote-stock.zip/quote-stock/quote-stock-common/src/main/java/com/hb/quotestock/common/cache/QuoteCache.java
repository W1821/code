package com.hb.quotestock.common.cache;


import com.hb.quotestock.common.pojo.quote.ExponentQuote;
import com.hb.quotestock.common.pojo.quote.SinaIndustryQuote;
import com.hb.quotestock.common.pojo.quote.StockQuote;
import com.hb.quotestock.common.pojo.quote.TransactionQuote;
import com.hb.quotestock.common.pojo.quote.*;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class QuoteCache {

    /**
     * 股票行情缓存
     * key格式：000001
     */
    public static final Map<String, QuoteWrapper<StockQuote>> STOCK = new ConcurrentHashMap<>();

    /**
     * 指数行情缓存
     * key格式：000001
     */
    public static final Map<String, QuoteWrapper<ExponentQuote>> EXPONENT = new ConcurrentHashMap<>();

    /**
     * 股票逐笔缓存
     * key格式：000001
     */
    public static final Map<String, QuoteWrapper<TransactionQuote>> TRANSACTION = new ConcurrentHashMap<>();

    /**
     * 新浪行业行情缓存
     * key格式：new_blhy
     */
    public static final Map<String, QuoteWrapper<SinaIndustryQuote>> SINA_INDUSTRY = new ConcurrentHashMap<>();

}
