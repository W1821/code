package com.hb.quotestock.common.pojo.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.*;

/**
 * 股票数据，包含部分字段
 */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@ApiModel("股票基本信息-部分信息")
public class StockInfoSectionDTO {

    @ApiModelProperty(value = "交易代码", example = "300267")
    private String ticker;

    @ApiModelProperty(value = "交易所代码", example = "sz")
    private String exchangeCd;

    @ApiModelProperty(value = "上市板块编码", example = "2")
    private int lisSectorCd;

    @ApiModelProperty(value = "上市板块", example = "创业板")
    private String listSector;

    @ApiModelProperty(value = "证券简称", example = "尔康制药")
    private String secShortName;

    @ApiModelProperty(value = "证券简称拼音", example = "EKZY")
    private String pinYin;

    @ApiModelProperty(value = "上市日期", example = "2011-09-27 14:00:00")
    private String listDate;

    @ApiModelProperty(value = "总股本(最新)", example = "2062604800")
    private Double totalShares;

    @ApiModelProperty(value = "是否是亏损股票,0：否，1：是", example = "0")
    private int isST;

}
