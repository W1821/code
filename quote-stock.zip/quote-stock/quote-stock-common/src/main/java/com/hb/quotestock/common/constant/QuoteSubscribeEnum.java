package com.hb.quotestock.common.constant;

import lombok.Getter;

/**
 * 行情订阅类型
 */
public enum QuoteSubscribeEnum {

    STOCK_SUBSCRIBE("1", "订阅股票"),
    STOCK_UNSUBSCRIBE("2", "订阅股票"),
    EXPONENT_SUBSCRIBE("3", "订阅股票"),
    EXPONENT_UNSUBSCRIBE("4", "订阅股票"),
    TRANSACTION_SUBSCRIBE("5", "订阅股票"),
    TRANSACTION_UNSUBSCRIBE("6", "订阅股票"),
    SINA_INDUSTRY_SUBSCRIBE("7", "订阅股票"),
    SINA_INDUSTRY_UNSUBSCRIBE("8", "订阅股票");

    @Getter
    private String key;
    @Getter
    private String value;

    QuoteSubscribeEnum(String key, String value) {
        this.key = key;
        this.value = value;
    }

    public static QuoteSubscribeEnum getByKey(String key) {
        if (key == null) {
            return null;
        }
        for (QuoteSubscribeEnum sourceEnum : QuoteSubscribeEnum.values()) {
            if (key.equalsIgnoreCase(sourceEnum.getKey())) {
                return sourceEnum;
            }
        }
        return null;
    }


}
