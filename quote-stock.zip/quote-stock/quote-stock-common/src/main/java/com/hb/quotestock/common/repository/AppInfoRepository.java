package com.hb.quotestock.common.repository;

import com.hb.quotestock.common.pojo.po.AppInfoModel;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

@Repository
public interface AppInfoRepository
        extends JpaRepository<AppInfoModel, String>, JpaSpecificationExecutor<AppInfoModel> {

}
