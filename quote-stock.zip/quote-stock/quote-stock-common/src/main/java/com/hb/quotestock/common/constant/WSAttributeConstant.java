package com.hb.quotestock.common.constant;

/**
 * 客户端的连接参数
 */
public class WSAttributeConstant {

    public static final String IP = "ip";
    public static final String CLIENT_TYPE = "clientType";
    public static final String APP_ID = "appId";
    public static final String APP_NAME = "appName";
    public static final String TYPE = "type";
    public static final String TIMESTAMP = "timestamp";
    public static final String SIGN = "sign";

}
