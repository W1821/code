package com.hb.quotestock.common.schedule;

import com.hb.quotestock.common.cache.SystemCache;
import com.hb.quotestock.common.util.LocalDateUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;

/**
 * 系统定时器
 */
@Component
@Slf4j
public class SystemLogSchedule {

    /**
     * 定时输出系统日志
     */
    @Scheduled(cron = "0 0/10 * * * ?")
    public void printSystemInfo() {
        LocalDateTime startTime = SystemCache.SYSTEM_START_TIME;
        LocalDateTime now = LocalDateTime.now();

        // 小时数
        long runTimeHours = LocalDateUtil.getHoursBetween(startTime, now);
        if (runTimeHours > 0) {
            log.info("System already running {} hours", runTimeHours);
            return;
        }
        // 分钟数
        long runTimeMinutes = LocalDateUtil.getMinutesBetween(startTime, now);
        if (runTimeMinutes > 0) {
            log.info("System already running {} minutes", runTimeMinutes);
            return;
        }
        // 秒数数
        long runTimeSeconds = LocalDateUtil.getSecondsBetween(startTime, now);
        if (runTimeSeconds > 0) {
            log.info("System already running {} seconds", runTimeSeconds);
        }

    }


}
