package com.hb.quotestock.common.config;

import com.google.common.util.concurrent.ThreadFactoryBuilder;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.SchedulingConfigurer;
import org.springframework.scheduling.concurrent.ThreadPoolTaskScheduler;
import org.springframework.scheduling.config.ScheduledTaskRegistrar;

import java.util.concurrent.ThreadFactory;

/**
 * 配置定时任务线程池数量，使用默认配置，单核心单线程池
 *
 * @EnableScheduling 启用定时任务
 * @EnableWebSocket 启用websocket
 * 上面2个同时启用会报错，增加此配置可以解决
 * 此配置改变了springboot默认的单核心线程池配置，可以配置成多核心线程池
 */
@Configuration
@Slf4j
public class SchedulerConfig implements SchedulingConfigurer {
    @Override
    public void configureTasks(ScheduledTaskRegistrar taskRegistrar) {
        log.info("配置定时任务线程池");
        ThreadPoolTaskScheduler taskScheduler = new ThreadPoolTaskScheduler();
        ThreadFactory factory = new ThreadFactoryBuilder().setNameFormat("task-scheduler-%d").build();
        taskScheduler.setThreadFactory(factory);
        // 配置核心线程数
        taskScheduler.setPoolSize(Runtime.getRuntime().availableProcessors());
        taskScheduler.initialize();
        taskRegistrar.setScheduler(taskScheduler);
    }

}


