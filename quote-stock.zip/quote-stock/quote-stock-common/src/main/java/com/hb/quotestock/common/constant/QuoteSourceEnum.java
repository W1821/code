package com.hb.quotestock.common.constant;

import lombok.Getter;

public enum QuoteSourceEnum {

    SINA("sina", "新浪"),
    TL("tl", "通联");

    @Getter
    private String key;
    @Getter
    private String value;

    QuoteSourceEnum(String key, String value) {
        this.key = key;
        this.value = value;
    }

    public static QuoteSourceEnum getByKey(String key) {
        if (key == null) {
            return SINA;
        }
        for (QuoteSourceEnum sourceEnum : QuoteSourceEnum.values()) {
            if (key.equalsIgnoreCase(sourceEnum.getKey())) {
                return sourceEnum;
            }
        }
        return SINA;
    }

}
