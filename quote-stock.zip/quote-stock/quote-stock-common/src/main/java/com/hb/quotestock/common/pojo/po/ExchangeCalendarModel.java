package com.hb.quotestock.common.pojo.po;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;


/**
 * 交易所日历基本信息
 */
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@Entity
@IdClass(ExchangeCalendarPrimaryKey.class)
@Table(name = "exchange_calendar")
public class ExchangeCalendarModel extends BasePO {

    /**
     * 证券交易所代码，sh或sz
     */
    @Id
    private String exchangeCode;

    /**
     * 日期
     */
    @Id
    private String calendarDate;

    /**
     * 日期当天是否开市
     */
    private Integer isOpen;

    /**
     * 当前日期前一天交易日
     */
    private String prevTradeDate;

    /**
     * 当前日期是否当周最后交易日
     */
    private Integer isWeekEnd;

    /**
     * 当前日期是否当月最后交易日
     */
    private Integer isMonthEnd;

    /**
     * 当前日期是否当季最后交易日
     */
    private Integer isQuarterEnd;

    /**
     * 当前日期是否当年最后交易日
     */
    private Integer isYearEnd;

}
