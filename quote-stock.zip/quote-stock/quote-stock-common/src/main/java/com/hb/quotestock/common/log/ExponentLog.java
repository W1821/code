package com.hb.quotestock.common.log;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class ExponentLog {

    /**
     * 记录日志
     *
     * @param content 日志内容
     */
    public static void log(String content) {
        log.info(content);
    }

}
