package com.hb.quotestock.common.pojo.po;

import lombok.*;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;

/**
 * 除权除息，人工导入的数据
 */
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@Builder
@Entity
@IdClass(StockAdjFactorInfoPrimaryKey.class)
@Table(name = "stock_adj_factor_info")
public class StockAdjFactorInfoModel extends BasePO {

    /**
     * 股票编号
     */
    @Id
    private String stockId;

    /**
     * 除权除息日
     */
    @Id
    private String excludeDate;

    /**
     * 股票名称
     */
    private String stockName;

    /**
     * 每股派现（分红）
     */
    private Double perShareCash;

    /**
     * 每股送股比例（送转股）
     */
    private Double perShareRatio;

    /**
     * 每股配股比例（配股）
     */
    private Double perAllotmentRatio;

    /**
     * 配股价
     */
    private Double allotmentPrice;



}
