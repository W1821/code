package com.hb.quotestock.common.pojo.quote;

import com.hb.quotestock.common.constant.QuoteTypeEnum;

import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

/**
 * 客户的订阅行情信息
 */
public class QuoteSubscribeInfo {

    public final static String SUBSCRIBE_ALL = "*";

    /**
     * 行情订阅信息
     */
    private Map<QuoteTypeEnum, Set<String>> quoteSubscribeMap = new ConcurrentHashMap<>();

    public QuoteSubscribeInfo() {
        Set<String> stockSubscribeList = new HashSet<>();
        quoteSubscribeMap.put(QuoteTypeEnum.STOCK, stockSubscribeList);

        Set<String> exponentSubscribeList = new HashSet<>();
        quoteSubscribeMap.put(QuoteTypeEnum.EXPONENT, exponentSubscribeList);

        Set<String> transactionSubscribeList = new HashSet<>();
        quoteSubscribeMap.put(QuoteTypeEnum.TRANSACTION, transactionSubscribeList);

        Set<String> sinaIndustrySubscribeList = new HashSet<>();
        quoteSubscribeMap.put(QuoteTypeEnum.SINA_INDUSTRY, sinaIndustrySubscribeList);
    }

    /**
     * 订阅行情
     */
    public void subscribeQuote(QuoteTypeEnum quoteType, Set<String> sets) {
        if (quoteType == null || sets == null) {
            return;
        }
        // 如果订阅所有
        if (isSubOrUnsubAll(sets)) {
            quoteSubscribeMap.put(quoteType, sets);
        } else {
            sets.remove(SUBSCRIBE_ALL);
            Set<String> oldSets = new HashSet<>(quoteSubscribeMap.get(quoteType));
            oldSets.addAll(sets);
            quoteSubscribeMap.put(quoteType, oldSets);
        }
    }

    /**
     * 反订阅订阅行情
     */
    public void unsubscribeQuote(QuoteTypeEnum quoteType, Set<String> sets) {
        if (quoteType == null || sets == null) {
            return;
        }
        // 如果反订阅所有
        if (isSubOrUnsubAll(sets)) {
            quoteSubscribeMap.put(quoteType, new HashSet<>());
        } else {
            sets.remove(SUBSCRIBE_ALL);
            Set<String> oldSets = new HashSet<>(quoteSubscribeMap.get(quoteType));
            oldSets.removeAll(sets);
            quoteSubscribeMap.put(quoteType, oldSets);
        }
    }

    /**
     * 是否订阅
     */
    public boolean isNotSubscribeCode(QuoteTypeEnum quoteType, String subscribeCode) {
        if (quoteType == null) {
            return true;
        }
        Set<String> subscribeSet = quoteSubscribeMap.get(quoteType);
        if (subscribeSet == null) {
            return true;
        }

        // 先判断是否订阅所有，如果是返回true
        if (subscribeSet.contains(SUBSCRIBE_ALL)) {
            return false;
        }

        // 再判断是否订阅了 subscribeCode
        if (subscribeCode == null) {
            return true;
        }
        return !subscribeSet.contains(subscribeCode);
    }

    public Set<String> getSubscribeCodes(QuoteTypeEnum quoteType) {
        return quoteSubscribeMap.get(quoteType);
    }

    public boolean isSubAll(QuoteTypeEnum quoteType) {
        Set<String> oldSets = quoteSubscribeMap.get(quoteType);
        return isSubOrUnsubAll(oldSets);
    }

    private boolean isSubOrUnsubAll(Set<String> sets) {
        if (sets == null) {
            return false;
        }
        return sets.size() == 1 && sets.contains(SUBSCRIBE_ALL);
    }

}
