package com.hb.quotestock.common.repository;

import com.hb.quotestock.common.pojo.po.ExchangeCalendarModel;
import com.hb.quotestock.common.pojo.po.ExchangeCalendarPrimaryKey;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ExchangeCalendarRepository
        extends JpaRepository<ExchangeCalendarModel, ExchangeCalendarPrimaryKey>, JpaSpecificationExecutor<ExchangeCalendarModel> {

    List<ExchangeCalendarModel> findByCalendarDateBetween(String beginDate, String endDate);

    List<ExchangeCalendarModel> findByCalendarDate(String calendarDate);
}
