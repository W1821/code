package com.hb.quotestock.common.pojo.quote;

import lombok.*;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@Builder
public class SinaIndustryQuote extends BaseQuote {

    /**
     * 行业代码
     */
    private String hydm;

    /**
     * 行业名称
     */
    private String hymc;

    /**
     * 涨跌幅
     */
    private String hyzdf;

    /**
     * 涨跌额
     */
    private String hyzde;

    /**
     * 涨股票数量
     */
    @Builder.Default
    private String hyzs = "0";

    /**
     * 跌股票数量
     */
    @Builder.Default
    private String hyds = "0";

    /**
     * 没涨没跌股票数量
     */
    @Builder.Default
    private String hyps = "0";

    /**
     * 平均价格
     */
    private String hypjjg;

    /**
     * 成交总量(股数)
     */
    private String hycjzl;

    /**
     * 成交总额（元）
     */
    private String hycjze;


    /**
     * 领涨股代码
     */
    private String lzgdm;

    /**
     * 领涨股名称
     */
    private String lzgmc;

    /**
     * 领涨股当前价
     */
    private String lzgdqj;

    /**
     * 领涨股涨跌幅
     */
    private String lzgzdf;

    /**
     * 领涨股涨跌额
     */
    private String lzgzde;

}
