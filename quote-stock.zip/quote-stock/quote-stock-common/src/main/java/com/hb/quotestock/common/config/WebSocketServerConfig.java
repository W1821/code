package com.hb.quotestock.common.config;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Configuration
@ConfigurationProperties(prefix = "ws.server")
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class WebSocketServerConfig {

    /**
     * 缓冲区大小
     * 默认是1000字符
     * 每条行情的长度不会超过这个
     * 这个值设置太大会导致内存不足，因为一个websocket就需要这么大的空间
     */
    private int bufferSize = 1000;
    /**
     * 发送超时时间
     */
    private long sendTimeout;

    /**
     * web socket URL paths
     */
    private String[] paths;

    /**
     * 系统允许的心跳间隔,单位是秒
     * 默认60秒心跳超时
     */
    private long heartbeatTimeoutSeconds = 60L;

}