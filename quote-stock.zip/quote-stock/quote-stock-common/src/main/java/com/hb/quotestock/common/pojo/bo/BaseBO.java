package com.hb.quotestock.common.pojo.bo;

import com.hb.quotestock.common.pojo.BaseBean;

public class BaseBO extends BaseBean {
}
