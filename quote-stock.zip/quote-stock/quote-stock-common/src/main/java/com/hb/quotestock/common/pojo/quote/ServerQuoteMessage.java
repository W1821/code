package com.hb.quotestock.common.pojo.quote;

import com.hb.quotestock.common.constant.QuoteTypeEnum;
import com.hb.quotestock.common.pojo.BaseBean;
import lombok.*;

/**
 * 兼容老版本的对象
 */
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@Builder
public class ServerQuoteMessage extends BaseBean {

    /**
     * 行情类型
     *
     * @see QuoteTypeEnum
     */
    private String type;

    /**
     * 1 object
     * 2 array
     * 老版本只有1,
     */
    @Builder.Default
    private String dataType = "1";

    /**
     * 行情数据
     */
    private String data;

}
