package com.hb.quotestock.common.pojo.po;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.time.LocalDateTime;

/**
 * @author Administrator
 */
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@Entity
@Table(name = "app_info")
public class AppInfoModel extends BasePO {
    /**
     * 应用key
     */
    @Id
    private String appKey;

    /**
     * 应用私钥
     */
    private String appSecret;

    /**
     * 应用类型
     */
    private String appType;

    /**
     * 过期时间
     */
    private LocalDateTime overTime;

    /**
     * appKey的简单别名
     */
    private String customerId;

    /**
     * 详细描述
     */
    private String customerDescription;

    /**
     * 在用状态：0 在用  9 删除
     */
    private String state;

    /**
     * 白名单
     */
    private String whitelist;

    /**
     * 是否监控
     */
    private int monitored;

    /**
     * 创建者
     */
    private String creater;

    /**
     * 创建时间
     */
    private LocalDateTime createTime;

    /**
     * 更新者
     */
    private String updater;

    /**
     * 更新时间
     */
    private LocalDateTime updateTime;


}