const fields = [
    {
        icon: 'key',
        key: 'roleName',
        type: 'input',
        placeholder: '请输入角色名',

    },
];

export default fields;
