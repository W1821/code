const fields = [
    {
        icon: 'user',
        key: 'userName',
        type: 'input',
        placeholder: '请输入用户名',

    },
    {
        icon: 'user',
        key: 'phoneNumber',
        type: 'input',
        placeholder: '请输入手机号码',
    },
];

export default fields;
