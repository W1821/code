import React, {Component} from 'react';

import './Welcome.css';


class Welcome extends Component {

    render() {
        return (
            <div>
                欢迎
            </div>
        );
    }
}

export default Welcome;
