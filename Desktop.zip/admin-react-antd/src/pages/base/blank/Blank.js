import React, {Component} from 'react';

import './Blank.css';


class Blank extends Component {


    render() {

        return (
            <div>
                blank
            </div>
        );
    }
}

export default Blank;
