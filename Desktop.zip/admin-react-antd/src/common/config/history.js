const createHashHistory = require('history').createHashHistory;

const history = createHashHistory();

export default history;
