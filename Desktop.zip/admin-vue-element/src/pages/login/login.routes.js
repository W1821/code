import Login from './Login';

export default [
    {path: '/login', component: Login},
    {path: '/login/:type', component: Login}
];
