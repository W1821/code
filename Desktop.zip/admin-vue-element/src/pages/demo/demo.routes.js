/**
 * 子路由配置，不能以 / 开头
 */
import Demo from './Demo';


export default [
    {path: 'demo/table', component: Demo,},

];
