<template>
    <div>Demo</div>
</template>

<script>
    export default {
        name: 'Demo'
    };
</script>

<style scoped>

</style>
