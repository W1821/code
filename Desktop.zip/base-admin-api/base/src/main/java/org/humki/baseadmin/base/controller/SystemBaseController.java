package org.humki.baseadmin.base.controller;


import org.humki.baseadmin.common.controller.BaseController;

/**
 * 基本控制器
 *
 * @author Kael
 */
public class SystemBaseController extends BaseController {


}
