package org.humki.baseadmin.common.pojo.dto;

import org.humki.baseadmin.common.pojo.BaseBean;

/**
 * 基础的DTO
 *
 * @author Kael
 */
public class BaseDTO extends BaseBean {

}
