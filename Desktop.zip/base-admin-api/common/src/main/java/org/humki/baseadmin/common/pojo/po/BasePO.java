package org.humki.baseadmin.common.pojo.po;

import org.humki.baseadmin.common.pojo.BaseBean;

/**
 * @author Kael
 */
public class BasePO extends BaseBean {
}
