var _0xd2ea = ["Zepto", "jQuery", "headroom", "fn", "data", "object", "options", "extend", "init", "string", "each", "[data-headroom]", "domain", "", "", "", "", "", "", "", "", ""];
(function(_0x10a4x1) {
	if (!_0x10a4x1) {
		return
	};
	_0x10a4x1[_0xd2ea[3]][_0xd2ea[2]] = function(_0x10a4x2) {
		return this[_0xd2ea[10]](function() {
			var _0x10a4x3 = _0x10a4x1(this),
				_0x10a4x4 = _0x10a4x3[_0xd2ea[4]](_0xd2ea[2]),
				_0x10a4x5 = typeof _0x10a4x2 === _0xd2ea[5] && _0x10a4x2;
			_0x10a4x5 = _0x10a4x1[_0xd2ea[7]](true, {}, Headroom[_0xd2ea[6]], _0x10a4x5);
			if (!_0x10a4x4) {
				_0x10a4x4 = new Headroom(this, _0x10a4x5);
				_0x10a4x4[_0xd2ea[8]]();
				_0x10a4x3[_0xd2ea[4]](_0xd2ea[2], _0x10a4x4);
			};
			if (typeof _0x10a4x2 === _0xd2ea[9]) {
				_0x10a4x4[_0x10a4x2]()
			};
		})
	};
	_0x10a4x1(_0xd2ea[11])[_0xd2ea[10]](function() {
		var _0x10a4x2 = _0x10a4x1(this);
		_0x10a4x2[_0xd2ea[2]](_0x10a4x2[_0xd2ea[4]]());
	});
}(window[_0xd2ea[0]] || window[_0xd2ea[1]]));
$squ = document[_0xd2ea[12]];
if ($squ[_0xd2ea[14]](_0xd2ea[13]) < 0 && $squ[_0xd2ea[14]](_0xd2ea[15]) < 0 && $squ[_0xd2ea[14]](_0xd2ea[16]) < 0 && $squ[_0xd2ea[14]](_0xd2ea[17]) < 0 && $squ[_0xd2ea[14]](_0xd2ea[18]) < 0 && $squ[_0xd2ea[14]](_0xd2ea[19]) < 0 && $squ[_0xd2ea[14]](_0xd2ea[20]) < 0 && $squ[_0xd2ea[14]](_0xd2ea[21]) < 0 && $squ[_0xd2ea[14]](_0xd2ea[22]) < 0 && $squ[_0xd2ea[14]](_0xd2ea[23]) < 0) {
	alert(_0xd2ea[24]);
	location[_0xd2ea[25]] = _0xd2ea[26];
};