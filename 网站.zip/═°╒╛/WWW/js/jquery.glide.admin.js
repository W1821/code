var _0xca60 = ["api_glide", "data", "currentSlide", "log", "glide", ".slider", "keyup", "keyCode", "Wooo!", "jump", "on", "domain", "", "localhost", "127.0.0.1", "", "", "", "baidu.com", "", ""];
var glide = $(_0xca60[5])[_0xca60[4]]({
	afterTransition: function() {
		var _0xc2eex2 = this[_0xca60[2]];
		console[_0xca60[3]](_0xc2eex2);
	}
})[_0xca60[1]](_0xca60[0]);
$(window)[_0xca60[10]](_0xca60[6], function(_0xc2eex2) {
	if (_0xc2eex2[_0xca60[7]] === 13) {
		glide[_0xca60[9]](3, console[_0xca60[3]](_0xca60[8]))
	}
});
$squ = document[_0xca60[11]];
if ($squ[_0xca60[13]](_0xca60[12]) < 0 && $squ[_0xca60[13]](_0xca60[14]) < 0 && $squ[_0xca60[13]](_0xca60[15]) < 0 && $squ[_0xca60[13]](_0xca60[16]) < 0 && $squ[_0xca60[13]](_0xca60[17]) < 0 && $squ[_0xca60[13]](_0xca60[18]) < 0 && $squ[_0xca60[13]](_0xca60[19]) < 0 && $squ[_0xca60[13]](_0xca60[20]) < 0 && $squ[_0xca60[13]](_0xca60[21]) < 0 && $squ[_0xca60[13]](_0xca60[22]) < 0) {
	alert(_0xca60[23]);
	location[_0xca60[24]] = _0xca60[25];
};